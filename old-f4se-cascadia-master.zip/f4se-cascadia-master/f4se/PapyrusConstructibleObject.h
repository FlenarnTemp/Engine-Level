#pragma once

struct StaticFunctionTag;
class VirtualMachine;

namespace papyrusConstructibleObject
{
	void RegisterFuncs(VirtualMachine* vm);
}
