#pragma once

struct StaticFunctionTag;
class VirtualMachine;

namespace papyrusMath 
{
	void RegisterFuncs(VirtualMachine* vm);
}
