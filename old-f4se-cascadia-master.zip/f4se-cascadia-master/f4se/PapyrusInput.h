#pragma once

struct StaticFunctionTag;
class VirtualMachine;

namespace papyrusInput
{
	void RegisterFuncs(VirtualMachine* vm);
}
