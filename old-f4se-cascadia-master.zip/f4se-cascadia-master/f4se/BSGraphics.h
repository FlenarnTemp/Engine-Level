#pragma once

#include "f4se_common/Relocation.h"
#include "f4se_common/Utilities.h"

#include "f4se/BSGeometry.h"
#include "f4se/NiTextures.h"

class BSGeometryData;

#include "f4se\NiSerialization.h"
#include "f4se\NiProperties.h"

#include <d3d11.h>
#include <DirectXMath.h>
#include <xmmintrin.h>

namespace BSGraphics
{
	enum SetRenderTargetMode
	{
		SRTM_CLEAR = 0x0,
		SRTM_CLEAR_DEPTH = 0x1,
		SRTM_CLEAR_STENCIL = 0x2,
		SRTM_NO_CLEAR = 0x3,
		SRTM_RESTORE = 0x3,
		SRTM_FORCE_COPY_RESTORE = 0x4,
		SRTM_INIT = 0x5
	};

	enum DepthStencilDepthMode
	{
		DEPTH_STENCIL_DEPTH_MODE_DISABLED = 0x0,
		DEPTH_STENCIL_DEPTH_MODE_TEST = 0x1,
		DEPTH_STENCIL_DEPTH_MODE_WRITE = 0x2,
		DEPTH_STENCIL_DEPTH_MODE_TEST_WRITE = 0x3,
		DEPTH_STENCIL_DEPTH_MODE_TESTEQUAL = 0x4,
		DEPTH_STENCIL_DEPTH_MODE_TESTGREATEREQUAL = 0x5,
		DEPTH_STENCIL_DEPTH_MODE_TESTGREATER = 0x6,
		DEPTH_STENCIL_DEPTH_MODE_COUNT = 0x7,
		DEPTH_STENCIL_DEPTH_MODE_DEFAULT = 0x3
	};

	enum DepthStencilStencilMode
	{
		DEPTH_STENCIL_STENCIL_MODE_DISABLED = 0x0,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_ALWAYS_REPLACE = 0x1,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_ALWAYS_REPLACE_WM00000001 = 0x2,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_ALWAYS_REPLACE_WM00000010 = 0x3,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_ALWAYS_REPLACE_WM00000100 = 0x4,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_ALWAYS_REPLACE_WM00001000 = 0x5,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_ALWAYS_REPLACE_WM00010000 = 0x6,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_ALWAYS_REPLACE_WM00100000 = 0x7,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_ALWAYS_REPLACE_WM01000000 = 0x8,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_ALWAYS_REPLACE_WM10000000 = 0x9,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_ALWAYS_INCREMENT = 0xA,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_GREATER_KEEP = 0xB,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_KEEP = 0xC,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_KEEP_RM00000001 = 0xD,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_KEEP_RM00000010 = 0xE,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_KEEP_RM00000100 = 0xF,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_KEEP_RM00001000 = 0x10,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_KEEP_RM00010000 = 0x11,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_KEEP_RM00100000 = 0x12,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_KEEP_RM01000000 = 0x13,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_KEEP_RM10000000 = 0x14,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_REPLACE = 0x15,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_REPLACE_RM00000010 = 0x16,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_REPLACE_RM00000100 = 0x17,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_REPLACE_RM00001000 = 0x18,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_REPLACE_RM00010000 = 0x19,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_REPLACE_RM00100000 = 0x1A,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_REPLACE_RM01000000 = 0x1B,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_REPLACE_RM10000000 = 0x1C,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_NOT_EQUAL_REPLACE_RM00000001 = 0x1D,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_INCREMENT = 0x1E,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_INCREMENT_RM00000010 = 0x1F,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_INCREMENT_RM00000100 = 0x20,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_INCREMENT_RM00001000 = 0x21,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_INCREMENT_RM00010000 = 0x22,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_INCREMENT_RM00100000 = 0x23,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_INCREMENT_RM01000000 = 0x24,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_INCREMENT_RM10000000 = 0x25,
		DEPTH_STENCIL_STENCIL_MODE_ENABLED_EQUAL_REPLACE_WM00000000 = 0x26,
		DEPTH_STENCIL_STENCIL_MODE_COUNT = 0x27,
		DEPTH_STENCIL_STENCIL_MODE_DEFAULT = 0x0
	};


	enum DepthStencilExtraMode
	{
		DEPTH_STENCIL_EX_DISABLED = 0x0,
		DEPTH_STENCIL_EX_DFLIGHT_STEP0 = 0x1,
		DEPTH_STENCIL_EX_DFLIGHT_STEP1 = 0x2,
		DEPTH_STENCIL_EX_DFLIGHT_EXCLUSIVE0 = 0x3,
		DEPTH_STENCIL_EX_DFLIGHT_EXCLUSIVE1 = 0x4,
		DEPTH_STENCIL_EX_DFLIGHT_EXCLUSIVECLEAR = 0x5,
		DEPTH_STENCIL_EX_DFDIRLIGHT_SINGLE = 0x6,
		DEPTH_STENCIL_EX_DFDIRLIGHT_STEPS = 0x7,
		DEPTH_STENCIL_EX_DFDIRLIGHT_STEPS_BLEND0 = 0x8,
		DEPTH_STENCIL_EX_DFDIRLIGHT_STEPS_BLEND1 = 0x9,
		DEPTH_STENCIL_EX_DFDIRLIGHT_FINAL = 0xA,
		DEPTH_STENCIL_EX_CHARACTER_LIGHT_TEST = 0xB,
		DEPTH_STENCIL_EX_CHARACTER_LIGHT_MASK = 0xC,
		DEPTH_STENCIL_EX_CHARACTER_LIGHT_MASK_DEPTH_TEST_ONLY = 0xD,
		DEPTH_STENCIL_EX_CLEAR_01111111 = 0xE,
		DEPTH_STENCIL_EX_COUNT = 0xF
	};

	enum RasterStateCullMode
	{
		RASTER_STATE_CULL_MODE_NONE = 0x0,
		RASTER_STATE_CULL_MODE_BACK = 0x1,
		RASTER_STATE_CULL_MODE_FRONT = 0x2,
		RASTER_STATE_CULL_MODE_COUNT = 0x3,
		RASTER_STATE_CULL_MODE_DEFAULT = 0x1
	};

	enum RasterStateDepthBiasMode
	{
		RASTER_STATE_DEPTHBIAS_MODE_NONE = 0x0,
		RASTER_STATE_DEPTHBIAS_MODE_ONE = 0x1,
		RASTER_STATE_DEPTHBIAS_MODE_TWO = 0x2,
		RASTER_STATE_DEPTHBIAS_MODE_THREE = 0x3,
		RASTER_STATE_DEPTHBIAS_MODE_AURORA = 0x4,
		RASTER_STATE_DEPTHBIAS_MODE_MOON_AND_STARS = 0x5,
		RASTER_STATE_DEPTHBIAS_MODE_WIREFRAME_BASE = 0x6,
		RASTER_STATE_DEPTHBIAS_MODE_WIREFRAME_DECAL = 0x7,
		RASTER_STATE_DEPTHBIAS_MODE_SHADOWMAP = 0x8,
		RASTER_STATE_DEPTHBIAS_MODE_COUNT = 0x9,
		RASTER_STATE_DEPTHBIAS_MODE_DEFAULT = 0x0
	};

	enum RasterStateFillMode
	{
		RASTER_STATE_FILL_MODE_SOLID = 0x0,
		RASTER_STATE_FILL_MODE_WIREFRAME = 0x1,
		RASTER_STATE_FILL_MODE_COUNT = 0x2,
		RASTER_STATE_FILL_MODE_DEFAULT = 0x0
	};

	enum RasterStatePolygonStippleMode
	{
		RASTER_STATE_POLYGON_STIPPLE_MODE_DISABLED = 0x0,
		RASTER_STATE_POLYGON_STIPPLE_MODE_ENABLED = 0x1,
		RASTER_STATE_POLYGON_STIPPLE_MODE_COUNT = 0x2,
		RASTER_STATE_POLYGON_STIPPLE_MODE_DEFAULT = 0x0
	};

	enum RasterStateScissorMode
	{
		RASTER_STATE_SCISSOR_MODE_DISABLED = 0x0,
		RASTER_STATE_SCISSOR_MODE_ENABLED = 0x1,
		RASTER_STATE_SCISSOR_MODE_COUNT = 0x2,
		RASTER_STATE_SCISSOR_MODE_DEFAULT = 0x0
	};

	enum AlphaBlendAlphaToCoverage
	{
		ALPHA_BLEND_ALPHA_TO_COVERAGE_DISABLED = 0x0,
		ALPHA_BLEND_ALPHA_TO_COVERAGE_ENABLED = 0x1,
		ALPHA_BLEND_ALPHA_TO_COVERAGE_COUNT = 0x2,
		ALPHA_BLEND_ALPHA_TO_COVERAGE_DEFAULT = 0x0
	};

	enum AlphaBlendMode
	{
		ALPHA_BLEND_MODE_DISABLED = 0x0,
		ALPHA_BLEND_MODE_SRCALPHA_INVSRCALPHA = 0x1,
		ALPHA_BLEND_MODE_SRCALPHA_ONE = 0x2,
		ALPHA_BLEND_MODE_DEST_ZERO = 0x3,
		ALPHA_BLEND_MODE_ONE_INVSRCALPHA = 0x4,
		ALPHA_BLEND_MODE_ONE_ONE = 0x5,
		ALPHA_BLEND_MODE_WEAPON_BLOOD = 0x6,
		ALPHA_BLEND_MODE_COUNT = 0x7,
		ALPHA_BLEND_MODE_DEFAULT = 0x0
	};

	enum AlphaBlendWriteMode
	{
		ALPHA_BLEND_WRITE_MODE_DISABLED = 0x0,
		ALPHA_BLEND_WRITE_MODE_RGB = 0x1,
		ALPHA_BLEND_WRITE_MODE_RGBA = 0x2,
		ALPHA_BLEND_WRITE_MODE_RG = 0x3,
		ALPHA_BLEND_WRITE_MODE_BA = 0x4,
		ALPHA_BLEND_WRITE_MODE_R = 0x5,
		ALPHA_BLEND_WRITE_MODE_G = 0x6,
		ALPHA_BLEND_WRITE_MODE_B = 0x7,
		ALPHA_BLEND_WRITE_MODE_A = 0x8,
		ALPHA_BLEND_WRITE_MODE_A_TARGET0 = 0x9,
		ALPHA_BLEND_WRITE_MODE_A_TARGET1 = 0xA,
		ALPHA_BLEND_WRITE_MODE_A_TARGET2 = 0xB,
		ALPHA_BLEND_WRITE_MODE_A_TARGET3 = 0xC,
		ALPHA_BLEND_WRITE_MODE_COUNT = 0xD,
		ALPHA_BLEND_WRITE_MODE_DEFAULT = 0x1
	};

	enum TextureAddressMode
	{
		TEXTURE_ADDRESS_MODE_CLAMP_S_CLAMP_T = 0x0,
		TEXTURE_ADDRESS_MODE_CLAMP_S_WRAP_T = 0x1,
		TEXTURE_ADDRESS_MODE_WRAP_S_CLAMP_T = 0x2,
		TEXTURE_ADDRESS_MODE_WRAP_S_WRAP_T = 0x3,
		TEXTURE_ADDRESS_MODE_COUNT = 0x4,
		TEXTURE_ADDRESS_MODE_DEFAULT = 0x0
	};

	enum TextureFileFormat
	{
		TEXTURE_FILE_FORMAT_BMP = 0x0,
		TEXTURE_FILE_FORMAT_JPG = 0x1,
		TEXTURE_FILE_FORMAT_TGA = 0x2,
		TEXTURE_FILE_FORMAT_PNG = 0x3,
		TEXTURE_FILE_FORMAT_DDS = 0x4,
		TEXTURE_FILE_FORMAT_PPM = 0x5,
		TEXTURE_FILE_FORMAT_DIB = 0x6,
		TEXTURE_FILE_FORMAT_HDR = 0x7,
		TEXTURE_FILE_FORMAT_PFM = 0x8
	};

	enum TextureFilterMode
	{
		TEXTURE_FILTER_MODE_NEAREST = 0x0,
		TEXTURE_FILTER_MODE_BILERP = 0x1,
		TEXTURE_FILTER_MODE_TRILERP = 0x2,
		TEXTURE_FILTER_MODE_ANISO = 0x3,
		TEXTURE_FILTER_MODE_COMP_BILERP = 0x4,
		TEXTURE_FILTER_MODE_COUNT = 0x5,
		TEXTURE_FILTER_MODE_DEFAULT = 0x3
	};

	enum ConstantGroupLevel
	{
		CONSTANT_GROUP_LEVEL_TECHNIQUE = 0x0,
		CONSTANT_GROUP_LEVEL_MATERIAL = 0x1,
		CONSTANT_GROUP_LEVEL_GEOMETRY = 0x2,
		CONSTANT_GROUP_LEVEL_COUNT = 0x3,
		CONSTANT_GROUP_LEVEL_CUBEMAP_INDEX = 0x8,
		CONSTANT_GROUP_LEVEL_PREVIOUS_BONES = 0x9,
		CONSTANT_GROUP_LEVEL_BONES = 0xA,
		CONSTANT_GROUP_LEVEL_SUB_INDEX = 0xB,
		CONSTANT_GROUP_LEVEL_FACE_CUSTOMIZATION = 0xC,
		CONSTANT_GROUP_LEVEL_INSTANCE = 0xD
	};

	enum ComputeMode
	{
		COMPUTE_MODE_RENDER = 0x0,
		COMPUTE_MODE_TOTAL = 0x1,
		COMPUTE_MODE_OFF = 0x1
	};

	//	18
	class ConstantGroup	//	BSGraphics::ConstantGroup
	{
	public:
		ID3D11Buffer* pBuffer;				//	00
		float* pData;				//	08
		bool			DataIsCpuWorkBuffer;	//	10
		UInt8			pad11[(0x18 - 0x11)];	//	11
	};

	//	88
	class VertexShader	//	BSGraphics::VertexShader
	{
	public:
		UInt32				uiID;					//	00
		UInt8				pad04[(0x08 - 0x04)];	//	04
		ID3D11VertexShader* pShader;				//	08
		UInt32				uiByteCodeSize;			//	10
		UInt8				pad14[(0x18 - 0x14)];	//	14
		ConstantGroup		ConstantBuffers[3];		//	18
		UInt64				uiShaderDesc;			//	60
		char				ConstantTable[32];		//	68
	};

	//	88
	class DomainShader	//	BSGraphics::DomainShader
	{
	public:
		UInt32				uiID;					//	00
		UInt8				pad04[(0x08 - 0x04)];	//	04
		ID3D11DomainShader* pShader;				//	08
		UInt32				uiByteCodeSize;			//	10
		UInt8				pad14[(0x18 - 0x14)];	//	14
		ConstantGroup		ConstantBuffers[3];		//	18
		UInt64				uiShaderDesc;			//	60
		char				ConstantTable[32];		//	68
	};

	//	88
	class HullShader	//	BSGraphics::HullShader
	{
	public:
		UInt32				uiID;					//	00
		UInt8				pad04[(0x08 - 0x04)];	//	04
		ID3D11HullShader* pShader;				//	08
		UInt32				uiByteCodeSize;			//	10
		UInt8				pad14[(0x18 - 0x14)];	//	14
		ConstantGroup		ConstantBuffers[3];		//	18
		UInt64				uiShaderDesc;			//	60
		char				ConstantTable[32];		//	68
	};

	//	78
	class PixelShader	//	BSGraphics::PixelShader
	{
	public:
		UInt32				uiID;					//	00
		UInt8				pad04[(0x08 - 0x04)];	//	04
		ID3D11PixelShader* pShader;				//	08
		ConstantGroup		ConstantBuffers[3];		//	10
		char				ConstantTable[32];		//	58
	};

	//	210
	class ViewData	//	BSGraphics::ViewData
	{
	public:
		NiRect<float>		kViewPort;					//	00
		NiPoint2			kViewDepthRange;			//	10
		UInt8				pad18[(0x20 - 0x18)];		//	18
		__m128				kViewUp;					//	20
		__m128				kViewRight;					//	30
		__m128				kViewDir;					//	40
		DirectX::XMMATRIX	kViewMat;					//	50
		DirectX::XMMATRIX	kProjMat;					//	90
		DirectX::XMMATRIX	kViewProjMat;				//	D0
		DirectX::XMMATRIX	kViewProjUnjittered;		//	110
		DirectX::XMMATRIX	kCurrentViewProjUnjittered;	//	150
		DirectX::XMMATRIX	kPreviousViewProjMat;		//	190
		DirectX::XMMATRIX	kInv1stPersonProjMat;		//	1D0
	};

	//	910
	class RendererShadowState	//	BSGraphics::RendererShadowState
	{
	public:
		int							uiDirty;							//	00
		int							uiVSTextureDirty;					//	04
		int							uiVSTextureStateDirty;				//	08
		int							uiDSTextureDirty;					//	0C
		int							uiDSTextureStateDirty;				//	10
		int							uiPSTextureDirty;					//	14
		int							uiPSTextureStateDirty;				//	18
		int							uiCSTextureDirty;					//	1C
		int							uiCSTextureStateDirty;				//	20
		int							uiCSUAVDirty;						//	24
		bool						bReadOnlyDepth;						//	28
		bool						bReadOnlyStencil;					//	29
		bool						UsesVertexIndexBuffer;				//	2A
		UInt8						pad2B;								//	2B
		int							iRenderTargets[8];					//	2C
		int							iDepthStencil;						//	4C
		int							iDepthStencilSlice;					//	50
		int							iCubeMapRenderTarget;				//	54
		int							iCubeMapRenderTargetView;			//	58
		SetRenderTargetMode			eSetRenderTargetMode[8];			//	5C
		SetRenderTargetMode			eSetDepthStencilMode;				//	7C
		SetRenderTargetMode			eSetCubeMapRenderTargetMode;		//	80
		int							CurrentRenderTargetIndex;			//	84
		int							CurrentDepthStencilTargetIndex;		//	88
		int							CurrentCubeMapRenderTargetIndex;	//	8C
		D3D11_VIEWPORT				ViewPort;							//	90
		DepthStencilDepthMode		eDepthStencilDepthMode;				//	A8
		DepthStencilStencilMode		eDepthStencilStencilMode;			//	AC
		DepthStencilExtraMode		eDepthStencilExMode;				//	B0
		UInt32						uiStencilRef;						//	B4
		RasterStateFillMode			eRasterStateFillMode;				//	B8
		RasterStateCullMode			eRasterStateCullMode;				//	BC
		RasterStateDepthBiasMode	eRasterStateDepthBiasMode;			//	C0
		RasterStateScissorMode		eRasterStateScissorMode;			//	C4
		AlphaBlendMode				eAlphaBlendMode;					//	C8
		AlphaBlendAlphaToCoverage	eAlphaBlendAlphaToCoverage;			//	CC
		AlphaBlendWriteMode			eAlphaBlendWriteMode;				//	D0
		bool						bAlphaTestEnabled;					//	D4
		UInt8						padD5[(0xD8 - 0xD5)];				//	D5
		float						fAlphaTestRef;						//	D8
		TextureAddressMode			eVSTextureAddressMode[16];			//	DC
		TextureFilterMode			eVSTextureFilterMode[16];			//	11C
		UInt8						pad15C[(0x160 - 0x15C)];			//	15C
		ID3D11ShaderResourceView* pVSTexture[16];					//	160
		UInt32						uiVSTextureMinLodMode[16];			//	1E0
		TextureAddressMode			eDSTextureAddressMode[16];			//	220
		TextureFilterMode			eDSTextureFilterMode[16];			//	260
		ID3D11ShaderResourceView* pDSTexture[16];					//	2A0
		UInt32						uiDSTextureMinLodMode[16];			//	320
		TextureAddressMode			ePSTextureAddressMode[16];			//	360
		TextureFilterMode			ePSTextureFilterMode[16];			//	3A0
		ID3D11ShaderResourceView* pPSTexture[16];					//	3E0
		UInt32						uiPSTextureMinLodMode[16];			//	460
		TextureAddressMode			eCSTextureAddressMode[16];			//	4A0
		TextureFilterMode			eCSTextureFilterMode[16];			//	4E0
		ID3D11ShaderResourceView* pCSTexture[16];					//	520
		UInt32						uiCSTextureMinLodMode[16];			//	5A0
		ID3D11UnorderedAccessView* pCSUAV[8];						//	5E0
		ID3D11Buffer* pVertexConstantBuffer[3];			//	620
		ID3D11Buffer* pPixelConstantBuffer[3];			//	638
		ID3D11Buffer* pDomainConstantBuffer[3];			//	650
		ID3D11Buffer* pHullConstantBuffer[3];			//	668
		UInt64						uiVertexDesc;						//	680
		VertexShader* pCurrentVertexShader;				//	688
		DomainShader* pCurrentDomainShader;				//	690
		HullShader* pCurrentHullShader;				//	698
		PixelShader* pCurrentPixelShader;				//	6A0
		D3D_PRIMITIVE_TOPOLOGY		eTopology;							//	6A8
		UInt8						pad6AC[(0x6B0 - 0x6AC)];			//	6AC
		NiPoint3A					PosAdjust;							//	6B0
		NiPoint3A					PreviousPosAdjust;					//	6C0
		ViewData					CameraData;							//	6D0
		float						ClearColor[4];						//	8E0
		float						PreviousClearColor[4];				//	8F0
		char						ClearStencil;						//	900
		UInt8						pad901[(0x910 - 0x901)];			//	901
	};

	//	30
	class RenderTarget	//	BSGraphics::RenderTarget
	{
	public:
		ID3D11Texture2D* pTexture;			//	00
		ID3D11Texture2D* pCopyTexture;		//	08
		ID3D11RenderTargetView* pRTView;			//	10
		ID3D11ShaderResourceView* pSRView;			//	18
		ID3D11ShaderResourceView* pCopySRView;		//	20
		ID3D11UnorderedAccessView* pUAView;			//	28
	};

	//	50
	class RendererWindow	//	BSGraphics::RendererWindow
	{
	public:
		HWND__* hWnd;					//	00
		int				iWindowX;				//	08
		int				iWindowY;				//	0C
		int				uiWindowWidth;			//	10
		int				uiWindowHeight;			//	14
		IDXGISwapChain* pSwapChain;			//	18
		RenderTarget	SwapChainRenderTarget;	//	20
	};

	//	98
	class DepthStencilTarget	//	BSGraphics::DepthStencilTarget
	{
	public:
		ID3D11Texture2D* pTexture;							//	00
		ID3D11DepthStencilView* pDSView[4];						//	08
		ID3D11DepthStencilView* pDSViewReadOnlyDepth[4];			//	28
		ID3D11DepthStencilView* pDSViewReadOnlyStencil[4];		//	48
		ID3D11DepthStencilView* pDSViewReadOnlyDepthStencil[4];	//	68
		ID3D11ShaderResourceView* pSRViewDepth;						//	88
		ID3D11ShaderResourceView* pSRViewStencil;					//	90
	};

	//	40
	class CubeMapRenderTarget	//	BSGraphics::CubeMapRenderTarget
	{
	public:
		ID3D11Texture2D* pTexture;		//	00
		ID3D11RenderTargetView* pRTView[6];	//	08
		ID3D11ShaderResourceView* pSRView;		//	38
	};

	//	08
	class TextureHeader	//	BSGraphics::TextureHeader
	{
	public:
		void* unk1;		//	00
	};

	//	08
	class TextureStreamData	//	BSGraphics::TextureStreamData
	{
	public:
		UInt32		uiRefCount;			//	00
		char		ucDataFileIndex;	//	04
		char		ucChunkCount;		//	05
		UInt16		usMinLOD;			//	06
	};

	//	50
	class Buffer	//	BSGraphics::Buffer
	{
	public:
		ID3D11Buffer* pBuffer;				//	00
		void* pData;				//	08
		Buffer* pNext;				//	10
		ID3D11ShaderResourceView* pShaderResource;		//	18
		ID3D11UnorderedAccessView* pUnorderedAccess;		//	20
		void* pRequestEventToWait;	//	20 - BSEventFlag
		UInt32						uiMaxDataSize;			//	30
		UInt32						uiDataSize;				//	34
		UInt32						uiRefCount;				//	38
		UInt32						SRAcquire;				//	3C - BSAtomicValue<unsigned int> (struct with just a single unsigned int?)
		UInt32						UAVAcquire;				//	40 - BSAtomicValue<unsigned int> (struct with just a single unsigned int?)
		UInt32						PendingRequests;		//	44 - BSAtomicValue<unsigned int> (struct with just a single unsigned int?)
		UInt32						DataOffset;				//	48
		bool						InvalidCpuData;			//	4C
		bool						HeapAllocated;			//	4D
		volatile bool				PendingCopy;			//	4E
		UInt8						pad4F;					//	4F
	};

	//	50
	class VertexBuffer	//	BSGraphics::VertexBuffer
	{
	public:
		Buffer		baseClass;	//	00
	};

	//	50
	class IndexBuffer	//	BSGraphics::IndexBuffer
	{
	public:
		Buffer		baseClass;	//	00
	};

	//	20
	class ImmutableConstantBuffer	//	BSGraphics::ImmutableConstantBuffer
	{
	public:
		ID3D11Buffer* pBuffer;				//	00
		void* pSrcData;				//	08
		void* pRequestEventToWait;	//	10 - BSEventFlag
		UInt32			PendingRequests;		//	18 - BSTAtomicValue<unsigned int> (struct with just a single unsigned int?)
		UInt32			RefCount;				//	1C
	};

	//	30
	class CommandBufferPlatform	//	BSGraphics::CommandBufferPlatform
	{
	public:
		ID3D11InputLayout* pIl;						//	00
		VertexBuffer* pVb;						//	08
		IndexBuffer* pIb;						//	10
		ImmutableConstantBuffer* pPSPerGeometryConstants;	//	18
		ID3D11BlendState* pBlend;					//	20
		UInt32					uiStride;					//	28
		UInt8					pad2C[(0x30 - 0x2C)];		//	2C
	};

	//	20
	class TriShape	//	BSGraphics::TriShape
	{
	public:
		UInt64			uiVertexDesc;			//	00
		VertexBuffer* pVB;					//	08
		IndexBuffer* pIB;					//	10
		UInt32			uiRefCount;				//	18
		UInt8			pad1C[(0x20 - 0x1C)];	//	1C
	};

	//	10
	class DynamicTriShapeData	//	BSGraphics::DynamicTriShapeData
	{
	public:
		VertexBuffer* pVB;					//	00
		UInt32			DataStride;				//	08
		UInt8			pad0C[(0x10 - 0x0C)];	//	0C
	};

	//	40
	class Texture	//	BSGraphics::Texture
	{
	public:
		ID3D11ShaderResourceView* pSRView;				//	00
		ID3D11Texture2D* pTexture2D;			//	08
		ID3D11UnorderedAccessView* pUAView;				//	10
		TextureStreamData* pStreamData;			//	18
		void* pRequestEventToWait;	//	20 - BSEventFlag
		TextureHeader				Header;					//	28
		UInt32						PendingRequests;		//	30 - BSAtomicValue<unsigned int> (struct with just a single unsigned int?)
		UInt32						uiRefCount;				//	34
		UInt32						uiCreationFrame;		//	38
		char						uiMinLOD;				//	3C
		char						uiDegradeLevel;			//	3D
		char						usDesiredDegradeLevel;	//	3E
		char						usFlags;				//	3F
	};

	//	
	class OcclusionQuery	//	BSGraphics::OcclusionQuery
	{
	public:
		ID3D11Query* pOcclusionQuery;		//	00
		UInt16			uiInUse;				//	08
		UInt8			pad0C[(0x10 - 0x0C)];	//	0C
	};

	//	25D0
	class RendererData	//	BSGraphics::RendererData
	{
	public:
		RendererShadowState* pShadowState;				//	00
		void* D3DResourceCreator;		//	08 - BSD3DResourceCreator
		UInt32						uiAdapter;					//	10
		DXGI_RATIONAL				DesiredRefreshRate;			//	14
		DXGI_RATIONAL				ActualRefreshRate;			//	1C
		DXGI_MODE_SCALING			ScaleMode;					//	24
		DXGI_MODE_SCANLINE_ORDER	ScanlineMode;				//	28
		int							bFullScreen;				//	2C
		bool						bAppFullScreen;				//	30
		bool						bBorderlessWindow;			//	31
		bool						bVSync;						//	32
		bool						bInitialized;				//	33
		bool						bRequestWindowSizeChange;	//	34
		UInt8						pad35[(0x38 - 0x35)];		//	35
		UInt32						uiNewWidth;					//	38
		UInt32						uiNewHeight;				//	3C
		UInt32						uiPresentInterval;			//	40
		UInt8						pad44[(0x48 - 0x44)];		//	44
		ID3D11Device* pDevice;					//	48
		ID3D11DeviceContext* pContext;					//	50
		RendererWindow				RenderWindowA[32];			//	58
		RenderTarget				pRenderTargetsA[101];		//	A58
		DepthStencilTarget			pDepthStencilTargets[13];	//	1D48
		CubeMapRenderTarget			pCubeMapRenderTargetsA[2];	//	2500
		CRITICAL_SECTION			RendererLock;				//	2580
		const char* pClassName;				//	25B8
		HINSTANCE__* hInstance;				//	25C0
		bool						bNVAPIEnabled;				//	25C8
		UInt8						pad25C9[(0x25D0 - 0x25C9)];	//	25C9
	};

	//	25E0
	class Renderer	//	BSGraphics::Renderer
	{
	public:
		bool					bSkipNextPresent;		//	00
		UInt8					pad01[(0x08 - 0x01)];	//	01
		void* ResetRenderTargets;	//	08
		RendererData			Data;					//	10

		MEMBER_FN_PREFIX(Renderer);
		DEFINE_MEMBER_FN(AddTextureToArray, void, 0x01D0FFC0, BSGraphics::Texture* unk1, BSGraphics::Texture* unk2, UInt32 unk3);
		DEFINE_MEMBER_FN(AlphaBlendStateSetMode, void, 0x01D1E9C0, BSGraphics::AlphaBlendMode blendMode);
		DEFINE_MEMBER_FN(AlphaBlendStateSetWriteMode, void, 0x001E0320, BSGraphics::AlphaBlendWriteMode blendWriteMode);
		DEFINE_MEMBER_FN(ApplyConstantGroupCS, void, 0x028C9080, BSGraphics::ConstantGroup* constantGroup, BSGraphics::ConstantGroupLevel constantGroupLevel);
		DEFINE_MEMBER_FN(ApplyConstantGroupDS, void, 0x02867F40, BSGraphics::ConstantGroup* constantGroup, BSGraphics::ConstantGroupLevel constantGroupLevel);
		DEFINE_MEMBER_FN(ApplyConstantGroupHS, void, 0x02867F90, BSGraphics::ConstantGroup* constantGroup, BSGraphics::ConstantGroupLevel constantGroupLevel);
		DEFINE_MEMBER_FN(ApplyConstantGroupPS, void, 0x02801A70, BSGraphics::ConstantGroup* constantGroup, BSGraphics::ConstantGroupLevel constantGroupLevel);
		DEFINE_MEMBER_FN(ApplyConstantGroupVS, void, 0x01D1EA10, BSGraphics::ConstantGroup* constantGroup, BSGraphics::ConstantGroupLevel constantGroupLevel);
		DEFINE_MEMBER_FN(ApplyConstantGroupVSPS, void, 0x02801B10, BSGraphics::ConstantGroup* constantGroup, BSGraphics::ConstantGroup* constantGroup2, BSGraphics::ConstantGroupLevel constantGroupLevel);
		DEFINE_MEMBER_FN(Begin, void, 0x00D0B420, UInt16 unk1);
		DEFINE_MEMBER_FN(BeginCompute, void, 0x025428B0, BSGraphics::ComputeMode computeMode, UInt64 unk1);
		DEFINE_MEMBER_FN(BeginOcclusionQuery, void, 0x01D11C70, BSGraphics::OcclusionQuery* occlusionQuery);
		DEFINE_MEMBER_FN(BuildDrawCommandBuffer, void, 0x01D146B0, BSGraphics::TriShape* triShape, BSGraphics::CommandBufferPlatform* cmdBufPlatform, BSGraphics::VertexShader* vertexShader, BSGraphics::AlphaBlendMode alphaBlendMode, BSGraphics::AlphaBlendWriteMode alphaBlendWriteMode, char const* unk1, UInt16 unk2, UInt16 unk3);
		DEFINE_MEMBER_FN(BuildDynamicTriShapeData, void, 0x01D149C0, BSGraphics::DynamicTriShapeData* dynTriShape, UInt32 unk1);
		//	... quite a few here, will add them if needed
		//DEFINE_MEMBER_FN(CreateDomainShaderFromStream, BSGraphics::DomainShader*, 0x01D10A30, BSIStream* stream);	//	<- this is the most important for tessellation i think, need to work out BSIStream structs
		DEFINE_MEMBER_FN(SetShaders, void, 0x01D10400, BSGraphics::VertexShader* vertexShader, BSGraphics::HullShader* hullShader, BSGraphics::DomainShader* domainShader, BSGraphics::PixelShader* pixelShader);

	};
}



/*

// ??
class BSRenderManager	//	BSGraphics::Renderer
{
public:
	UInt64				unk2588[0x2590 >> 3];	// 2588
	CRITICAL_SECTION	m_textureLock;			// 2590

	MEMBER_FN_PREFIX(BSRenderManager);
	DEFINE_MEMBER_FN(CreateBSGeometryData, BSGeometryData*, 0x01D0BD60, UInt32* blockSize, UInt8* vertexData, UInt64 vertexDesc, BSGeometryData::TriangleData* triData); // Creates a block with a vertex copy in the resource pool with a reference to the supplied triblock (partial deep copy)

	DEFINE_MEMBER_FN(ConvertTriShapeToDynamicTriShape, BSDynamicTriShape*, 0x01D0DF70, BSTriShape* triShape, UInt16 unk1);
	//DEFINE_MEMBER_FN(SetShaders, void, 0x01D10400, BSGraphics::VertexShader* vertexShader, BSGraphics::HullShader* hullShader, BSGraphics::DomainShader* domainShader, BSGraphics::PixelShader* pixelShader);	//	-	Needs a bunch of shaders decompiled, will do this later
};
STATIC_ASSERT(offsetof(BSRenderManager, m_textureLock) == 0x2590);
*/

class BSShaderResourceManager
{
public:
	BSShaderResourceManager()
	{
		CALL_MEMBER_FN(this, ctor)();
	}
	~BSShaderResourceManager()
	{
		CALL_MEMBER_FN(this, dtor)();
	}

	MEMBER_FN_PREFIX(BSShaderResourceManager);
	DEFINE_MEMBER_FN(ctor, void, 0x02536200);
	DEFINE_MEMBER_FN(dtor, void, 0x019EEC80);
	DEFINE_MEMBER_FN(ApplyMaterials, void, 0x028E0C40, NiAVObject* avObject);
	//DEFINE_MEMBER_FN(ConvertBSTriShapeToBSDynamicTriShape, void, 0x028E0B70, NiNode* node, NiDefaultAVObjectPallette* palette);	//	-	Needs NiDefaultAVObjectPallette
	DEFINE_MEMBER_FN(CreateDefaultEffectShaderProperty, NiShadeProperty, 0x028E1580, bool unk1, bool unk2);
	DEFINE_MEMBER_FN(CreateDynamicLineShape, void*, 0x028E0E40, NiStream* stream, UInt64 unk1, UInt32 unk2, UInt32 unk3);
	//DEFINE_MEMBER_FN(CreateDynamicLineShape, BSDynamicLines, 0x028E0E60, UInt32 unk1, UInt32 unk2, UInt32 unk3, NiPoint3* unk4, NiPoint2* unk5, NiColorA* unk6, void unk7);	//	-	Needs BSDynamicLines
	//	there are tons of these.... will fill in more later
};

// ??
class BSRenderTargetManager
{
public:
	struct SharedTargetInfo
	{
		UInt32	width;		// 00 - 400
		UInt32	height;		// 04 - 400
		UInt32	unk08;		// 08 - 1C
		UInt32	unk0C;		// 0C - 10000
		UInt32	unk10;		// 10 - FFFFFFFF
		UInt32	unk14;		// 14 - r13d
		UInt32	unk18;		// 18 - r12b
	};

	MEMBER_FN_PREFIX(BSRenderTargetManager);
	// D16605905EE44603E286262CE17CFC8383EABDDC+84
	DEFINE_MEMBER_FN(LockTextureType, void, 0x01D329B0, UInt32 type);
	// D16605905EE44603E286262CE17CFC8383EABDDC+32F
	DEFINE_MEMBER_FN(ReleaseTextureType, void, 0x01D32A40, UInt32 type);
	DEFINE_MEMBER_FN(GetRenderData, BSRenderData *, 0x01D32910, UInt32 type, UInt64 unk1, UInt64 unk2, UInt32 unk3); // type, 0, 1, 0
	// D16605905EE44603E286262CE17CFC8383EABDDC+1EF
	DEFINE_MEMBER_FN(Unk_01, void, 0x01D32960, UInt32 type, BSRenderData *, UInt8 unk3); // type, rendererData, 1
};

// 1B8
class BSRenderer
{
public:

};

struct ID3D11DeviceContext;
struct ID3D11Device;

extern RelocPtr <BSRenderer*>			g_renderer;
extern RelocPtr <BSGraphics::Renderer>	g_renderManager;
extern RelocPtr <BSRenderTargetManager> g_renderTargetManager;
extern RelocPtr <BSShaderResourceManager> g_shaderResourceManager;
extern RelocPtr <ID3D11Device*>			g_D3D11Device;
extern RelocPtr <ID3D11DeviceContext*>  g_D3D11DeviceContext;
