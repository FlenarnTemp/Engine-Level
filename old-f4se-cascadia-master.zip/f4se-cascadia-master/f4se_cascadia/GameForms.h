#pragma once
#include "f4se/PapyrusNativeFunctions.h"	//	NativeFunction, StaticFunctionTag

#ifndef VanillaAVStruct
#define VanillaAVStruct
struct VanillaAV_Struct {
	//	Vanilla SPECIAL Values
	ActorValueInfo* Strength;
	ActorValueInfo* Perception;
	ActorValueInfo* Endurance;
	ActorValueInfo* Charisma;
	ActorValueInfo* Intelligence;
	ActorValueInfo* Agility;
	ActorValueInfo* Luck;
};
#endif
extern VanillaAV_Struct VanillaActorValues;


#ifndef CapitalWastelandAVStruct
#define CapitalWastelandAVStruct
struct CascadiaAV_Struct {
	//	CAS Skill Values
	ActorValueInfo* Barter;
	ActorValueInfo* EnergyWeapons;
	ActorValueInfo* Explosives;
	ActorValueInfo* Lockpick;
	ActorValueInfo* Medicine;
	ActorValueInfo* MeleeWeapons;
	ActorValueInfo* Repair;
	ActorValueInfo* Science;
	ActorValueInfo* Guns;
	ActorValueInfo* Sneak;
	ActorValueInfo* Speech;
	ActorValueInfo* Unarmed;
	ActorValueInfo* Survival;

	//	CAS Resists
	ActorValueInfo* WeaponCNDResist;
};
#endif
extern CascadiaAV_Struct CASActorValues;

#ifndef CascadiaGlobalsStruct
#define CascadiaGlobalsStruct
struct CascadiaGlobals_Struct {
	//	Cascadia Globals
	TESGlobal* TutorialWPNCND;
};
#endif
extern CascadiaGlobals_Struct CWGlobals;

#ifndef CascadiaPerksStruct
#define CascadiaPerksStruct
struct CascadiaPerks_Struct {
	//	Cascadia Weapon Type Perks
	BGSPerk* WeaponTypeEnergyWeaponsPerk;
	BGSPerk* WeaponTypeExplosivesPerk;
	BGSPerk* WeaponTypeMeleeWeaponsPerk;
	BGSPerk* WeaponTypeGunsPerk;
	BGSPerk* WeaponTypeUnarmedPerk;

	//	Cascadia Handler Perks
	BGSPerk* WeaponConditionHandlerPerk;
};
#endif
extern CascadiaPerks_Struct CASPerks;

#ifndef ItemDegredationStruct
#define ItemDegredationStruct
struct ItemDegredation_Struct {

	//	these holds our weapon condition on the Weapon Form in Creation Kit
	BGSDamageType* weaponConditionHealthMaxDMGT;
	BGSDamageType* weaponConditionHealthStartingDMGT;

	//	Actor Values that hold information on Items
	ActorValueInfo* itemConditionMaxHealth;
	ActorValueInfo* itemConditionMinHealth;
	ActorValueInfo* itemConditionStartCond;
};
#endif
extern ItemDegredation_Struct ItemDegredationForms;