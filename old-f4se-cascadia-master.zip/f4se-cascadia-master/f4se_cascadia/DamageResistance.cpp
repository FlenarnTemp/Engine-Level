#include "DamageResistance.h"

ActorValueInfo* ArmorPenetration;
ActorValueInfo* UnarmedDamage;
ActorValueInfo* crRangedDmg;
BGSKeyword* AnimsUnarmed;
BGSKeyword* crRanged;
TESObjectWEAP* unarmedHuman;

std::vector<DmgTypeData> damageTypes;

ActorValueInfo* damageResist;

BGSDamageType* weaponConditionHealth;
BGSDamageType* weaponConditionStartingHealth;

RVA <_ResetArmorRating> ResetArmorRating;

//credit: kassent(https://github.com/kassent/FloatingDamage)
using _Process = void(*)(void*, HitData*);
RelocAddr<_Process>	ProcessHitData = 0x00E01630;			//	Actor::DoHitMe 48 8B C4 48 89 50 10 55 56 41 56 41 57
RelocAddr<uintptr_t> ProcessHitDataCall = 0x00D60D61;		//	E8 ? ? ? ? 48 85 FF 74 36 48 8B CF

//	settings from FalloutCascadia.ini
bool bUseClassicDR = false;
float fMaxDR = 0.85;
bool bTraceDamageCalculations = false;

namespace DamageResistance
{
	void FillSettingsFromINI()
	{
		bUseClassicDR = false;
		fMaxDR = 0.85;
		bTraceDamageCalculations = true;
	}

	void GetDamageResistanceForms()
	{
		TraceLog("Damage Resistance: Getting Damage Resistance Forms");

		ArmorPenetration = (ActorValueInfo*)LookupFormByID(0x97341);
		UnarmedDamage = (ActorValueInfo*)LookupFormByID(0x2DF);
		crRangedDmg = (ActorValueInfo*)LookupFormByID(0x1504FB);
		AnimsUnarmed = (BGSKeyword*)LookupFormByID(0x2405E);
		crRanged = (BGSKeyword*)LookupFormByID(0x189348);
		unarmedHuman = (TESObjectWEAP*)LookupFormByID(0xC2C27);

		damageResist = (ActorValueInfo*)LookupFormByID(0x2E3);

		weaponConditionHealth = reinterpret_cast<BGSDamageType*>(GetFormFromIdentifier("CapitalWasteland.esm|D26DB"));
		weaponConditionStartingHealth = reinterpret_cast<BGSDamageType*>(GetFormFromIdentifier("CapitalWasteland.esm|D3B74"));

		for (int i = 0; i < (*g_dataHandler)->arrDMGT.count; i++)
		{
			BGSDamageType* currentType = (*g_dataHandler)->arrDMGT.entries[i];
			if (currentType == weaponConditionHealth || currentType == weaponConditionStartingHealth)
			{
				//	ignore weapon codnition damage types
				continue;
			}

			DmgTypeData currentTypeData = DmgTypeData();

			currentTypeData.damageTypeID = currentType->formID;
			currentTypeData.damageResist = currentType->kData.pResistance;
			currentTypeData.damageThreshold = nullptr;
			currentTypeData.fArmorDmgResistExponent = 0.365;
			currentTypeData.fArmorDmgFactor = 0.15;
			currentTypeData.dmgTypeName = currentType->GetEditorID();

			damageTypes.push_back(currentTypeData);
		}
		_MESSAGE("Found %i Damage Types in loaded plugins", damageTypes.size());

		FillSettingsFromINI();

		if (bUseClassicDR)
		{
			_MESSAGE("Classic DR System Enabled");
			_MESSAGE("Max Damage Resistance: %i", (int)(fMaxDR * 100));
		}
		else
		{
			_MESSAGE("Classic DR System Disabled in INI");
		}

		_MESSAGE("Damage Resistance: Finished getting Damage Resistance Forms");
	}

	float CalculateDamageResist(std::vector<DmgTypeStats>& damageTypesList)
	{
		float fFinalDmg = 0.0;
		float fReducedDmg = 0.0;
		float fFinalReducedDmg = 0.0;
		float fDRFactor = 1.0;
		float fMaxDRPercent = fMaxDR;
		if (bTraceDamageCalculations)
		{
			_MESSAGE("   Damage Resistance (Fallout 3):");
		}
		for (UInt32 i = 0; i < damageTypesList.size(); i++)
		{
			fDRFactor = min(fMaxDRPercent, max(0.0, damageTypesList[i].fDRVal * damageTypesList[i].fTargetArmorMult * (1.0 - damageTypesList[i].fArmorPen) * 0.01));
			fReducedDmg = damageTypesList[i].fDmgAmount * fDRFactor;
			if (bTraceDamageCalculations)
			{
				_MESSAGE("   %i - 0x%08X: DMG In: %.4f, DMG Out: %.4f, DR: %.4f%%, AP: %.2f%%, DR Mult: %.4f, DMG Mult: %.4f", i, damageTypesList[i].damageTypeID, damageTypesList[i].fDmgAmount, (damageTypesList[i].fDmgAmount - fReducedDmg),
					damageTypesList[i].fDRVal, damageTypesList[i].fArmorPen * 100.0, damageTypesList[i].fTargetArmorMult, fDRFactor);
			}
			damageTypesList[i].fDmgAmount = (damageTypesList[i].fDmgAmount - fReducedDmg);
			fFinalDmg += damageTypesList[i].fDmgAmount;
			fFinalReducedDmg += fReducedDmg;
		}
		if (bTraceDamageCalculations)
		{
			_MESSAGE("   --> DR Out: Damage Reduced by %.4f", fFinalReducedDmg);
		}
		return fFinalDmg;
	}

	float GetWeaponDamage(TESObjectREFR* attacker, TESObjectREFR* victim, TESObjectWEAP* weapon, TESObjectWEAP::InstanceData* weaponInstance, std::vector<DmgTypeStats>& damageTypesList, float fBaseDamage = 0.0)
	{
		Actor* attackerActor = DYNAMIC_CAST(attacker, TESObjectREFR, Actor);
		Actor* victimActor = DYNAMIC_CAST(victim, TESObjectREFR, Actor);

		float fWeaponDmg = 0.0;

		if (attackerActor)
		{
			fWeaponDmg = WPNUtilities::GetWeaponDamage(attackerActor);
			//_MESSAGE("Got Weapon Damage: %f from Attacker", fWeaponDmg);
		}

		if (fWeaponDmg <= 0.0)
		{
			fWeaponDmg = weaponInstance ? (float)(int)weaponInstance->baseDamage : 0.0;
		}

		float fArmorPen = 0.0;
		float fTargetDRMult = 1.0;
		float fNumProjectiles = (weaponInstance && weaponInstance->firingData) ? (float)(int)(UInt8)((weaponInstance->firingData->numProjectiles << 12) >> 12) : 1.0;
		UInt32 iOverrideDmgType = 0;
		bool bThrown = weaponInstance && weaponInstance->equipSlot && (weaponInstance->equipSlot->formID == 0x46AAC);
		bool bHasPhysDmg = false;
		float fAddVal = 0.0;

		if (bThrown)
		{
			if (bTraceDamageCalculations)
			{
				_MESSAGE("   Source: Thrown Weapon");
			}
			fWeaponDmg = fBaseDamage;
			fArmorPen = attacker->actorValueOwner.GetValue(ArmorPenetration) * 0.01;
		}
		else
		{
			if (weapon)
			{
				if (WeaponHasKeyword(weapon, crRanged))
				{
					if (bTraceDamageCalculations)
					{
						_MESSAGE("   Source: Creature Ranged Weapon");
					}
					fWeaponDmg += attacker->actorValueOwner.GetValue(crRangedDmg);
				}
				else if (WeaponHasKeyword(weapon, AnimsUnarmed))
				{
					if (bTraceDamageCalculations)
					{
						_MESSAGE("   Source: Unarmed Weapon");
					}
					fWeaponDmg += attacker->actorValueOwner.GetValue(UnarmedDamage);
				}
			}
			else
			{
				//	failsafe, use both
				fWeaponDmg += attacker->actorValueOwner.GetValue(crRangedDmg);
				fWeaponDmg += attacker->actorValueOwner.GetValue(UnarmedDamage);
			}
			fArmorPen = attacker->actorValueOwner.GetValue(ArmorPenetration) * 0.01;
		}

		//	Recalc Armor Rating
		ResetArmorRating(victimActor);

		DmgTypeData newDmgType{};

		for (int i = 0; damageTypes.size(); i++)
		{
			if (damageTypes[i].damageTypeID == 0x60A87)
			{
				newDmgType = damageTypes[i];
				break;
			}
		}

		//	base damage
		if (fWeaponDmg > 0.0)
		{
			fWeaponDmg = fWeaponDmg / fNumProjectiles;
			DmgTypeStats newStats = DmgTypeStats();
			if (newDmgType.damageTypeID != 0)
			{
				if (newDmgType.damageResist)
				{
					newStats.fDRVal = victim->actorValueOwner.GetValue(newDmgType.damageResist);
				}
				newStats.fArmorPen = fArmorPen;
				newStats.fTargetArmorMult = fTargetDRMult;
			}
			newStats.damageTypeID = newDmgType.damageTypeID;
			newStats.fDmgAmount = fWeaponDmg;
			//_MESSAGE("Base Damage = %.4f", newStats.fDmgAmount);
			newStats.fBaseDmg = fWeaponDmg;
			newStats.fDmgFactor = newDmgType.fArmorDmgFactor;
			newStats.fDRExponent = newDmgType.fArmorDmgResistExponent;
			damageTypesList.push_back(newStats);
			bHasPhysDmg = true;
		}

		//	typed damage
		if (weaponInstance && weaponInstance->damageTypes && weaponInstance->damageTypes->count != 0)
		{
			TBO_InstanceData::DamageTypes tempDT;
			if (bHasPhysDmg && (iOverrideDmgType != 0))
			{
				for (UInt32 i = 0; i < weaponInstance->damageTypes->count; i++)
				{
					if (weaponInstance->damageTypes->GetNthItem(i, tempDT))
					{
						if (tempDT.damageType)
						{
							fAddVal = (float)(int)tempDT.value / fNumProjectiles;
							damageTypesList[0].fBaseDmg += fAddVal;
							damageTypesList[0].fDmgAmount += fAddVal;
							fWeaponDmg += fAddVal;
						}
					}
				}
			}
			else
			{
				for (UInt32 i = 0; i < weaponInstance->damageTypes->count; i++)
				{
					if (weaponInstance->damageTypes->GetNthItem(i, tempDT))
					{
						if (tempDT.damageType)
						{
							if (tempDT.damageType != weaponConditionHealth && tempDT.damageType != weaponConditionStartingHealth)
							{
								if (bHasPhysDmg && (tempDT.damageType->formID == 0x60A87))
								{
									fAddVal = (float)(int)tempDT.value / fNumProjectiles;
									damageTypesList[0].fBaseDmg += fAddVal;
									damageTypesList[0].fDmgAmount += fAddVal;
									fWeaponDmg += fAddVal;
								}
								else
								{
									DmgTypeStats newStats = DmgTypeStats();
									for (int i = 0; i < damageTypes.size(); i++)
									{
										if (damageTypes[i].damageTypeID == tempDT.damageType->formID)
										{
											newDmgType = damageTypes[i];
											break;
										}
									}

									if (newDmgType.damageTypeID == tempDT.damageType->formID)
									{
										if (newDmgType.damageResist)
										{
											if (victim->actorValueOwner.GetValue(newDmgType.damageResist) == 0)
											{
												newStats.fDRVal = victim->actorValueOwner.GetValue(damageResist);
											}
											else
											{
												newStats.fDRVal = victim->actorValueOwner.GetValue(newDmgType.damageResist);
											}
										}
										newStats.fArmorPen = fArmorPen;
										newStats.fTargetArmorMult = fTargetDRMult;
									}

									if (iOverrideDmgType != 0)
									{
										newStats.damageTypeID = iOverrideDmgType;
									}
									else
									{
										newStats.damageTypeID = tempDT.damageType->formID;
									}

									newStats.fDmgAmount = (float)(int)tempDT.value;
									//_MESSAGE("Typed Damage Type 0x%08X: Damage = %.4f", newStats.damageTypeID, newStats.fDmgAmount);
									newStats.fBaseDmg = (float)(int)tempDT.value;
									newStats.fDmgFactor = newDmgType.fArmorDmgFactor;
									newStats.fDRExponent = newDmgType.fArmorDmgResistExponent;
									fWeaponDmg += newStats.fDmgAmount;
									damageTypesList.push_back(newStats);
								}
							}
						}
					}
				}
			}
		}

		return fWeaponDmg;
	}

	float CalculateIncomingDamage(TESObjectREFR* attacker, TESObjectREFR* victim, TESObjectWEAP* weapon, TESObjectWEAP::InstanceData* weaponInstance, float fBaseDmg, float fFinalDmgMult)
	{
		//_MESSAGE("\n\nCalculating Damage - starting damage: %.4f", fBaseDmg);
		std::vector<DmgTypeStats> damageTypesList{};
		float fFinalDmg = 0.0;
		UInt8 iArmorRoll = 0;

		//	Get Weapon Damage
		fFinalDmg = GetWeaponDamage(attacker, victim, weapon, weaponInstance, damageTypesList, fBaseDmg);
		if (bTraceDamageCalculations)
		{
			_MESSAGE("\n\nCalculating Damage - starting damage: %.4f", fFinalDmg);
		}
		if (damageTypesList.size() == 0)
		{
			if (bTraceDamageCalculations)
			{
				_MESSAGE("   ERROR: Empty damageTypesList!");
			}
			return fBaseDmg * fFinalDmgMult;
		}

		//	Distance Multiplier - this doesnt work as expected, commented out for now
		/*
		float fDistDmgMult = (fFinalDmg > 0.0) ? fBaseDmg / fFinalDmg : 1.0;
		for (UInt32 i = 0; i < damageTypesList.size(); i++)
		{
			damageTypesList[i].fDmgAmount *= fDistDmgMult;
			damageTypesList[i].fBaseDmg *= fDistDmgMult;
		}
		*/

		fFinalDmg = CalculateDamageResist(damageTypesList);

		if (fFinalDmg > 0.0)
		{
			//fFinalDmg = fBaseDmg - fFinalDmg;
			fFinalDmg = fFinalDmg * fFinalDmgMult;
		}
		else
		{
			fFinalDmg = fBaseDmg * fFinalDmgMult;
		}

		if (bTraceDamageCalculations)
		{
			_MESSAGE("   Calculating Damage Complete - final damage: %.4f", fFinalDmg);
		}

		return fFinalDmg;
	}

	void DumpHitData(HitData* hitData)
	{
		if (hitData)
		{
			_MESSAGE("HitData Dump Started:");
			_MESSAGE("   Aggressor: 0x%08X", hitData->hAggressor);
			_MESSAGE("   Target: 0x%08X", hitData->hTarget);
			_MESSAGE("   Physical Damage: %.4f\n   Total Damage: %.4f\n   Health Damage: %.4f", hitData->fPhysicalDamage, hitData->fTotalDamage, hitData->fHealthDamage);
			if (hitData->Weapon.object)
			{
				_MESSAGE("   Damage Source: %s", hitData->Weapon.object->GetFullName());
			}
			else
			{
				_MESSAGE("   Damage Source: NULL");
			}

			if (hitData->pAmmo)
			{
				_MESSAGE("   Ammo: %s", hitData->pAmmo->fullName.name.c_str());
			}
			else
			{
				_MESSAGE("   Ammo: NULL");
			}

			if (hitData->spAttackData.m_pObject)
			{
				if (hitData->Weapon.object)
				{
					TESObjectWEAP* weapon = reinterpret_cast<TESObjectWEAP*>(hitData->Weapon.object);
					if (weapon && weapon->weapData.ammo)
					{
						_MESSAGE("   Source is a Gun Bash Attack");
					}
					else if (weapon == unarmedHuman)
					{
						_MESSAGE("   Source is a Unarmed attack");
					}
					else
					{
						_MESSAGE("   Source is a Melee Weapon");
					}
				}
			}
			else
			{
				_MESSAGE("   Source is a Ranged Weapon");
			}

			if (hitData->Weapon.instanceData)
			{
				_MESSAGE("   Source has instance data");
			}
			else
			{
				_MESSAGE("   Source has NO instance data");
			}

			_MESSAGE("   Hit Location: X = %.4f, Y = %.4f, Z = %.4f", hitData->ImpactData.kLocation.x, hitData->ImpactData.kLocation.y, hitData->ImpactData.kLocation.z);
			_MESSAGE("   Hit Normal: X = %.4f, Y = %.4f, Z = %.4f", hitData->ImpactData.kNormal.x, hitData->ImpactData.kNormal.y, hitData->ImpactData.kNormal.z);
			_MESSAGE("   Hit Velocity: X = %.4f, Y = %.4f, Z = %.4f", hitData->ImpactData.kVelocity.x, hitData->ImpactData.kVelocity.y, hitData->ImpactData.kVelocity.z);
		}
		else
		{
			_MESSAGE("No HitData!");
		}
	}

	void InitAddresses()
	{
		ResetArmorRating = RVA <_ResetArmorRating>(
			"Actor::ResetArmorRating", {
				{ RUNTIME_VERSION_1_10_163, 0x00D8EDD0 },
			}, "E8 ? ? ? ? 48 8B 5D 9F 8B 75 CF", 0, 1, 5);
	}
}

SimpleLock globalDamageLock;
class ActorEx : public Actor
{
public:
	static void ProcessHitData_Hook(Actor* pActor, HitData* pHitData)
	{
		//_MESSAGE("Actor::DoHitMe");

		IncomingDamageType currentDamageType = kDamage_Unknown;

		if (bUseClassicDR)
		{
			if (pHitData && (pHitData->fTotalDamage > 0.0))
			{
				globalDamageLock.Lock();

				//_MESSAGE("Dumping Fallout 4 HitData Stats");
				//DamageResistance::DumpHitData(pHitData);

				TESObjectREFR* victim = nullptr;
				TESObjectREFR* attacker = nullptr;

				TESObjectWEAP* weapon = nullptr;
				TESObjectWEAP::InstanceData* weaponInstance = nullptr;

				float fBaseDmg = pHitData->fTotalDamage;
				bool bEditedDamage = false;

				UInt8 iSourceType = 0;
				float fFinalDmg = 0.0;
				float fTmpDmg1 = pHitData->fPhysicalDamage; //(damage)
				float fTmpDmg2 = pHitData->fHealthDamage;	//(damage2)
				//float fFinalDmgMult = (fTmpDmg1 > 0.0 && fTmpDmg2 > 0.0) ? fTmpDmg2 / fTmpDmg1 : 1.0;
				float fFinalDmgMult = 1.0;

				if (pHitData->spAttackData.m_pObject)
				{
					if (pHitData->Weapon.object)
					{
						TESObjectWEAP* weap = reinterpret_cast<TESObjectWEAP*>(pHitData->Weapon.object);
						if (weap && weap->weapData.ammo)
						{
							//	Gun Bash Attack
							currentDamageType = kDamage_Melee;
						}
						else if (weap == unarmedHuman)
						{
							//	Unarmed Attack
							currentDamageType = kDamage_Unarmed;
						}
						else
						{
							//	Normal Melee Attack
							currentDamageType = kDamage_Melee;
						}
					}
				}
				else
				{
					//	Ranged Weapon
					currentDamageType = kDamage_Ranged;
				}

				if ((LookupREFRByHandle(&pHitData->hTarget, &victim), victim != nullptr) && victim->formType == FormType::kFormType_ACHR)
				{
					if ((LookupREFRByHandle(&pHitData->hAggressor, &attacker), attacker != nullptr) && attacker->formType == FormType::kFormType_ACHR)
					{
						if (pHitData->Weapon.object)
						{
							if (pHitData->Weapon.object->formType == kFormType_WEAP)
							{
								weapon = reinterpret_cast<TESObjectWEAP*>(pHitData->Weapon.object);
							}
						}

						if (pHitData->Weapon.instanceData)
						{
							weaponInstance = reinterpret_cast<TESObjectWEAP::InstanceData*>(pHitData->Weapon.instanceData);
						}
						else if (weapon)
						{
							weaponInstance = &weapon->weapData;
						}

						if (weaponInstance)
						{
							//	Regular Weapon
							fFinalDmg = DamageResistance::CalculateIncomingDamage(attacker, victim, weapon, weaponInstance, fBaseDmg, fFinalDmgMult);
							pHitData->fPhysicalDamage = (pHitData->fPhysicalDamage > 0.0) ? fFinalDmg / fFinalDmgMult : 0.0;
							pHitData->fHealthDamage = fFinalDmg;
							bEditedDamage = true;
							//_MESSAGE("\n   %s hit %s for %.4f damage.", attacker->baseForm->GetFullName(), victim->baseForm->GetFullName(), fFinalDmg);
						}
						else
						{
							if (pHitData->spAttackData.m_pObject)
							{
								fFinalDmg = DamageResistance::CalculateIncomingDamage(attacker, victim, weapon, nullptr, fBaseDmg, fFinalDmgMult);
								pHitData->fPhysicalDamage = (pHitData->fPhysicalDamage > 0.0) ? fFinalDmg / fFinalDmgMult : 0.0;
								pHitData->fHealthDamage = fFinalDmg;
								bEditedDamage = true;
								//_MESSAGE("\n   %s hit %s for %.4f damage.", attacker->baseForm->GetFullName(), victim->baseForm->GetFullName(), fFinalDmg);
							}
						}
					}
				}

				if (!bEditedDamage)
				{
					if (bTraceDamageCalculations)
					{
						DamageResistance::DumpHitData(pHitData);
					}
					pHitData->fPhysicalDamage = (pHitData->fPhysicalDamage > 0.0) ? pHitData->fTotalDamage : 0.0;
					pHitData->fHealthDamage = pHitData->fTotalDamage;
				}

				//_MESSAGE("Dumping updated Fallout 3 HitData stats");
				//DamageResistance::DumpHitData(pHitData);

				ARMOUtilities::UpdateArmorStatsOnHit(pActor, pHitData->eDamageLimb, currentDamageType, pHitData->fHealthDamage);

				globalDamageLock.Release();
				ProcessHitData(pActor, pHitData);

				if (victim != nullptr)
				{
					victim->handleRefObject.DecRefHandle();
				}

				if (attacker != nullptr)
				{
					attacker->handleRefObject.DecRefHandle();
				}
			}
			else
			{
				if (bTraceDamageCalculations)
				{
					_MESSAGE("No HitData or damage <= 0.0");
				}
				ARMOUtilities::UpdateArmorStatsOnHit(pActor, pHitData->eDamageLimb, currentDamageType, pHitData->fHealthDamage);
				ProcessHitData(pActor, pHitData);
			}
		}
		else
		{
			//	ignoring Classic DR, pass through Fallout 4 calculation
			ARMOUtilities::UpdateArmorStatsOnHit(pActor, pHitData->eDamageLimb, currentDamageType, pHitData->fHealthDamage);
			ProcessHitData(pActor, pHitData);
		}
	}

	static void InitHooks()
	{
		g_branchTrampoline.Write5Call(ProcessHitDataCall.GetUIntPtr(), (uintptr_t)ProcessHitData_Hook);
	}
};

void InitDRHooks()
{
	ActorEx::InitHooks();
}