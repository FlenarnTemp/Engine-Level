#pragma once

struct StaticFunctionTag;
class VirtualMachine;

namespace papyrusWaterType
{
	void RegisterFuncs(VirtualMachine* vm);
}
