#include "f4se/GameUtilities.h"

RelocAddr <_CalculateCRC32_64> CalculateCRC32_64(0x01B10830);
RelocAddr <_CalculateCRC32_32> CalculateCRC32_32(0x01B107A0);
