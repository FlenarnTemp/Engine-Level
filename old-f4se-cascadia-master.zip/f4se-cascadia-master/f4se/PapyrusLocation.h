#pragma once
 
class VirtualMachine;

namespace papyrusLocation
{
	void RegisterFuncs(VirtualMachine* vm);
}
