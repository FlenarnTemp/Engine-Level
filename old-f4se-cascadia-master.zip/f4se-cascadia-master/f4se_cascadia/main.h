#pragma once
//Windows Includes
#include <ShlObj.h>  // CSIDL_MYDOCUMENTS
#include <iomanip>
#include <sstream>

//F4SE Includes
#include "common/IDebugLog.h"               //	IDebugLog
#include "f4se_common/f4se_version.h"       //  RUNTIME_VERSION
#include "f4se/PapyrusNativeFunctions.h"	//	NativeFunction, StaticFunctionTag
#include "f4se/PapyrusVM.h"	                //  VMClassRegistry
#include "f4se/PapyrusEvents.h"	            //  Papyrus Events
#include "f4se/PluginAPI.h"                 //  F4SEInterface, PluginInfo
#include "f4se/GameEvents.h"	            //  Game Events

//Internal Includes
#include "version.h"                        //  VERSION_VERSTRING, VERSION_MAJOR;
#include "HookUtil.h"                       //  Hook Utilites from Neanka's PRKF
#include "ObScript.h"						//	ObScript Logic
#include "Serialization.h"	                //	Serialization
#include "ConsoleCommands.h"	            //	Console Commands for use in Papyrus
#include "Skills.h"	                        //	SPECIAL & Skills Linking
#include "SharedFunctions.h"	            //  Shared Functions
#include "ItemDegredation.h"	            //	Item Degredation
#include "LevelUpMenu.h"		            //	Level Up Menu
#include "AmmoSwitch.h"                     //  Ammo Switch

//Variables
#define CURRENT_RUNTIME_VERSION CURRENT_RELEASE_RUNTIME
#define ESM_NAME	"FalloutCascadia.esm"	//  Cascadia ESM Name