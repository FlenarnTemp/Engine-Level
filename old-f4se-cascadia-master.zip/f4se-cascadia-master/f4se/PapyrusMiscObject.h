#pragma once

struct StaticFunctionTag;
class VirtualMachine;

namespace papyrusMiscObject
{
	void RegisterFuncs(VirtualMachine* vm);
}
