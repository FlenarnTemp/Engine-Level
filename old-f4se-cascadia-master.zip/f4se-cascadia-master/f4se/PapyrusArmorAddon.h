#pragma once

class VirtualMachine;

namespace papyrusArmorAddon
{
	void RegisterFuncs(VirtualMachine* vm);
}
