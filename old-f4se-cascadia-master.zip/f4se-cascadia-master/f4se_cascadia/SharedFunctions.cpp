#include "SharedFunctions.h"

#include <random>
#include <sstream>

RVA <_HasPerk> HasPerk;
RVA <_AddPerk> AddPerk;
RVA <_GetLevel> GetLevel;
RVA <_GetItemCount> GetItemCount;
RVA <_EquipItem_int> EquipItem_int;
RVA <_UnEquipItem_int> UnEquipItem_int;
RVA <void*> unk_itemManager;
RVA <_UnequipItem> UnequipItem_Internal;
RVA <_SetQuestStage> SetQuestStage;
RVA <_IsQuestStageDone> IsQuestStageDone;
RVA <_WornHasKeyword> WornHasKeyword;
RVA <_HasKeyword> HasKeyword;
RVA <_RemovePipboyItem>	RemovePipboyItem;
RVA <_HasKeywordHelper>	HasKeywordHelper;
RVA <_BGSObjectInstanceCtor>	BGSObjectInstanceCtor;
RVA <_IsDamaged> IsDamaged;
RVA <_RemoveNonRefItem> RemoveItem;
RVA <_FindRecipe>	FindRecipe;
RVA <_IsGodMode>	IsGodMode;

RVA			<void*>									g_EquipManager;
RelocPtr    <void*>									EquipManager_Address(0x059D75C8);		//	RUNTIME_VERSION_1_10_163

RelocAddr   <_Notification>                 Notification_internal(0x00AE1E90);
RelocAddr   <uintptr_t>                     ExtraObjectInstanceVtbl(0x02C4BE10);
RelocAddr   <uintptr_t>                     ExtraChargeVtbl(0x02C52228);
RelocAddr   <uintptr_t>                     ExtraObjectHealthVtbl(0x02C524C8);		
RelocAddr	<_PerformAction>				PerformAction(0x00E04FB0);
RelocAddr	<_IsAttackReady>				IsAttackReady(0x00E03F90);
RelocAddr	<_IsFalling>					IsFalling(0x00D729F0);
RelocAddr	<_RepopulateItemCardsOnSection_internal>	RepopulateItemCardsOnSection_internal(0xC105B0);
RelocAddr	<_RemoveStack>					RemoveStack(0x001A78D0);
RelocAddr	<_AddNonRefItem>				AddItem(0x013FBBE0);
RelocAddr	<_AttachMod>					AttachMod(0x01403B10);
RelocAddr	<_RemoveMod>					RemoveMod(0x0140D9C0);
RelocAddr	<_GetCurrentAmmoCount>			GetCurrentAmmoCount(0x00D8EA40);

BGSObjectInstance::BGSObjectInstance(TESForm* form, TBO_InstanceData* instance) {
	BGSObjectInstanceCtor(this, form, instance);
};

template <typename T>
BGSObjectInstanceT<T>::BGSObjectInstanceT(T form, TBO_InstanceData* instance) {
	BGSObjectInstanceCtor(this, form, instance);
};

ExtraCharge* ExtraCharge::Create(float value) {
	ExtraCharge* pCharge = (ExtraCharge*)BSExtraData::Create(sizeof(ExtraCharge), ExtraChargeVtbl.GetUIntPtr());
	pCharge->type = kExtraData_Charge;
	pCharge->charge = value;
	return pCharge;
}

ExtraObjectHealth* ExtraObjectHealth::Create(float value) {
	ExtraObjectHealth* pObjectHealth = (ExtraObjectHealth*)BSExtraData::Create(sizeof(ExtraObjectHealth), ExtraObjectHealthVtbl.GetUIntPtr());
	pObjectHealth->type = kExtraData_ObjectHealth;
	pObjectHealth->health = value;
	return pObjectHealth;
}


// Shared Global Functions
//=========================================================================================================================

//	Papyrus Native MessageBox and Notification Functions
void ShowMessageBox(std::string s_MessageText)
{
	CallGlobalFunctionNoWait1<BSFixedString>("Debug", "Messagebox", BSFixedString(s_MessageText.c_str()));
}

void ShowNotification(std::string s_NotificationText)
{
	CallGlobalFunctionNoWait1<BSFixedString>("Debug", "Notification", BSFixedString(s_NotificationText.c_str()));
}

//	Trace to F4SE Log
void TraceLog(std::string s_TraceText)
{
	_MESSAGE("=============================================================");
	_MESSAGE(s_TraceText.c_str());
}

//	Returns True if FormID string is base game OR dynamically placed (FF index)
//	Assumes all DLC is installed
bool IsFormIDStringBaseGame(std::string formIDString)
{
	std::string formIndex = formIDString.substr(0, 2);

	if (formIndex == "00" || formIndex == "01" || formIndex == "02" || formIndex == "03" || formIndex == "04" || formIndex == "05" || formIndex == "06" || formIndex == "ff")
	{
		return true;
	}

	return false;
}

//	Returns FormID as hex string
std::string GetFormIDAsString(UInt32 formID)
{
	std::string result{};
	std::stringstream formIDStream;
	formIDStream << std::hex << formID;
	result = formIDStream.str();
	if (result.length() < 8)
	{
		std::string temp;
		for (int i = 0; i < (8 - result.length()); i++)
		{
			temp.append("0");
		}
		temp.append(result);
		result = temp;
	}
	return result;
}

void RepopulateItemCardsOnSection(FormType section) 
{
	RepopulateItemCardsOnSection_internal(&(*g_PipboyDataManager)->inventoryData, section);
}

tArray<RepairComponent> GetAllRepairComponents(tArray<BGSConstructibleObject*> constArray)
{
	tArray<RepairComponent> requiredComponents;

	tArray<UInt32>	countArray;
	tArray<TESForm*> formArray;

	_MESSAGE("Const array size: %i", constArray.count);

	for (UInt32 i = 0; i < constArray.count; i++)
	{
		BGSConstructibleObject* bgsObject = constArray.entries[i];

		for (UInt32 j = 0; j < bgsObject->components->count; j++)
		{
			if (formArray.count != 0)
			{

				bool existsInArray = false;

				for (UInt32 h = 0; h < formArray.count; h++)
				{
					if (formArray.entries[h]->formID == bgsObject->components->entries[j].component->formID)
					{
						existsInArray = true;
						countArray.entries[h] = countArray.entries[h] + bgsObject->components->entries[j].count;
					}
				}

				if (!existsInArray)
				{
					formArray.Push(bgsObject->components->entries[j].component);
					countArray.Push(bgsObject->components->entries[j].count);
				}
			}
			else {
				formArray.Push(bgsObject->components->entries[j].component);
				countArray.Push(bgsObject->components->entries[j].count);
			}
		}
	}

	for (UInt32 i = 0; i < formArray.count; i++)
	{
		RepairComponent requiredComponent{};
		requiredComponent.form = formArray.entries[i];
		requiredComponent.count = countArray.entries[i];
		requiredComponents.Push(requiredComponent);
	}

	for (UInt32 i = 0; i < requiredComponents.count; i++)
	{
		_MESSAGE(requiredComponents.entries[i].form->GetFullName());
		_MESSAGE("Component count, pre-repair discount: %i", requiredComponents.entries[i].count);
	}

	return requiredComponents;
}

tArray<RepairComponent>AdjustComponentsBasedOnRepair(tArray<RepairComponent> repairComponents)
{
	float dynamicRepairValue = GetPlayerAVValue(CASActorValues.Repair);
	_MESSAGE("Repair skill, dynamic: %f", dynamicRepairValue);

	tArray<RepairComponent> returnComponents = repairComponents;

	float repairDiscount = 1.0 - ((dynamicRepairValue / 4) / 100);
	_MESSAGE("Discount: %f", repairDiscount);
	_MESSAGE("=== DISCOUNT STARTED ===");
	for (UInt32 i = 0; i < repairComponents.count; i++)
	{
		float countAsFloat = static_cast<float>(repairComponents.entries[i].count);
		countAsFloat = countAsFloat * repairDiscount;
		_MESSAGE("Count as float update: %f", countAsFloat);

		UInt32 newValue = static_cast<UInt32>(ceilf(countAsFloat));

		returnComponents.entries[i].count = newValue;
		_MESSAGE(returnComponents.entries[i].form->GetFullName());
		_MESSAGE("Component count, post-repair discount: %i", returnComponents.entries[i].count);
	}

	return returnComponents;
}

BGSEquipSlot* GetEquipType(TESForm* thisForm)
{
	if (!thisForm)
		return nullptr;

	BGSEquipType* pEquipType = DYNAMIC_CAST(thisForm, TESForm, BGSEquipType);
	if (pEquipType) {
		return pEquipType->GetEquipSlot();
	}

	// Invalid EquipSlot
	return nullptr;
}

TESForm* GetFormFromPlugin(const char* pluginName, UInt32 formID)
{
	const ModInfo* mod = (*g_dataHandler)->LookupModByName(pluginName);
	if (mod && mod->modIndex != 0xFF) {
		UInt32 flags = GetOffset<UInt32>(mod, 0x334);
		if (flags & (1 << 9)) {
			// ESL
			formID &= 0xFFF;
			formID |= 0xFE << 24;
			formID |= GetOffset<UInt16>(mod, 0x372) << 12;	// ESL load order
		}
		else {
			formID |= (mod->modIndex) << 24;
		}
		return LookupFormByID(formID);
	}
	return nullptr;
}

//Returns Indexed FormID from given Mod
TESForm* GetFormFromIdentifier(const std::string& myIdentifier)
{
	auto myMod = myIdentifier.find('|');
	if (myMod != std::string::npos)
	{
		std::string myModName = myIdentifier.substr(0, myMod);
		std::string myModForm = myIdentifier.substr(myMod + 1);

		const ModInfo* myModInfo = (*g_dataHandler)->LookupLoadedModByName(myModName.c_str());
		if (myModInfo && myModInfo->modIndex != 1)
		{
			UInt32 myFormID = std::stoul(myModForm, nullptr, 16) & 0xFFFFFF;
			UInt32 myFlags = GetOffset<UInt32>(myModInfo, 0x334);

			if (myFlags & (1 << 9))
			{
				//ESL File
				myFormID &= 0xFFF;
				myFormID |= 0XFE << 24;
				myFormID |= GetOffset<UInt16>(myModInfo, 0x372) << 12;
			}
			else
			{
				myFormID |= (myModInfo->modIndex) << 24;
			}
			return LookupFormByID(myFormID);
		}
		else
		{
			return NULL;
		}
	}
	else
	{
		return NULL;
	}
}

void EquipWeapon(WeaponToEquip weapon, Actor* actor)
{
	EquipItem_int(*unk_itemManager, actor, &weapon, 0, 1, nullptr, 1, false, 1, 0, false);
}

void UnEquipWeapon(WeaponToEquip weapon, Actor* actor)
{
	UnEquipItem_int(*unk_itemManager, actor, &weapon, 1, nullptr, -1, 1, true, 1, 0, nullptr);
}

void NotificationInternal(const char* Message, va_list args, const char* Sound) 
{
	char messageBuf[8192];
	vsprintf_s(messageBuf, sizeof(messageBuf), Message, args);
	Notification_internal(messageBuf, Sound, 0, 1, 1);
}

void NotificationSound(const char* Message, const char* Sound, ...) 
{
	va_list args; va_start(args, Message);
	NotificationInternal(Message, args, Sound);
	va_end(args);
}

bool PlayerGiveCapsToActor(Actor* actorToGiveCaps, UInt32 iAmount)
{
	CallGlobalFunctionNoWait2<Actor*, UInt32>("TCW:F4CW", "GiveCapsToVendor", actorToGiveCaps, iAmount);

	return true;
}

void UnequipItem(Actor* actor, TESForm* Form, bool PreventReEquip)
{
	BGSObjectInstance Data(Form, nullptr);
	UnequipItem_Internal((*g_EquipManager), actor, &Data, 1, nullptr, -1, 1, PreventReEquip, 1, 0, nullptr);
}

//	Returns given Actor's Sex as int
//	0 = male, 1 = female
UInt8 GetActorSex(Actor* myActor)
{
	UInt8 myGender = 0;
	TESNPC* myActorBase = DYNAMIC_CAST(myActor->baseForm, TESForm, TESNPC);
	if (myActorBase) {
		myGender = CALL_MEMBER_FN(myActorBase, GetSex)();
	}
	return myGender;
}

//	Returns Player as Actor
Actor* GetPlayer()
{
	return DYNAMIC_CAST((*g_player), TESForm, Actor);
}

//	Returns Player Level
UInt16 GetPlayerLevel()
{
	return GetLevel(GetPlayer());
}

//	Returns Player's Sex as int
//	0 = male, 1 = female
UInt8 GetPlayerSex()
{
	return GetActorSex(GetPlayer());
}

//	Returns true if given actor has given perk
bool HasPerkInternal(Actor* myActor, BGSPerk* myPerk)
{
	return HasPerk(myActor, myPerk);
}

// Gets passed Form's Name as BSFixedString
BSFixedString GetName(TESForm* myForm)
{
	if (!myForm)
		return BSFixedString();

	TESFullName* pFullName = DYNAMIC_CAST(myForm, TESForm, TESFullName);
	if (pFullName)
		return pFullName->name;

	return BSFixedString();
}

//	Gets passed Form's Description as BSFixedString
BSFixedString GetDescription(TESForm* myForm)
{
	if (!myForm)
		return BSFixedString();

	TESDescription* pDescription = DYNAMIC_CAST(myForm, TESForm, TESDescription);
	if (pDescription) {
		BSString str;
		CALL_MEMBER_FN(pDescription, Get)(&str, nullptr);
		return str.Get();
	}

	return BSFixedString();
}

//	Takes a Float and converts it to a Precise string
//	eg. FloatToPreciseString(3.141592, 2) would return "3.14"
std::string FloatToPreciseString(float myFloat, int myPrecision)
{
	std::stringstream stream;
	stream << std::fixed << std::setprecision(myPrecision) << myFloat;
	return stream.str();
}

//	Converts passed string to all lowercase
std::string StrToLower(std::string str)
{
	std::string result = str;

	for (auto& c : result)
	{
		c = tolower(c);
	}

	return result;
}

//	Get BGSInventoryItem from given form.
BGSInventoryItem GetFormBGSInventoryItem(TESForm* form)
{
	BGSInventoryItem result;

	Actor* player = GetPlayer();

	auto inventory = player->inventoryList;
	if (inventory)
	{
		inventory->inventoryLock.LockForReadAndWrite();

		for (int i = 0; i < inventory->items.count; i++)
		{
			BGSInventoryItem iter;
			inventory->items.GetNthItem(i, iter);

			if (iter.form == form) {
				result = iter;
				break;
			}
		}
	}

	inventory->inventoryLock.Unlock();

	return result;
}

//	Generates an ACTUAL random number between min and max
int RNG(int min, int max)
{
	std::random_device dev;
	std::mt19937 rng(dev());
	std::uniform_int_distribution<std::mt19937::result_type> dist(min, max);

	return dist(rng);
}

float RNG(float min, float max)
{
	std::random_device dev;
	std::mt19937 rng(dev());
	std::uniform_real_distribution<float> dist(min, max);

	return dist(rng);
}

bool IsPlayerGodMode()
{
	return IsGodMode((*g_player));
}

bool WeaponHasKeyword(TESObjectWEAP* weapon, BGSKeyword* keyword)
{
	if (weapon)
	{
		for (int i = 0; i < weapon->keyword.numKeywords; i++)
		{
			if (weapon->keyword.keywords[i] == keyword)
			{
				return true;
			}
		}
	}

	return false;
}

bool ArmorHasKeyword(TESObjectARMO* armor, BGSKeyword* keyword)
{
	if (armor)
	{
		for (int i = 0; i < armor->keywordForm.numKeywords; i++)
		{
			if (armor->keywordForm.keywords[i] == keyword)
			{
				return true;
			}
		}
	}

	return false;
}

bool ReferenceHasKeyword(TESObjectREFR* ref, BGSKeyword* keyword)
{
	if (ref)
	{
		TBO_InstanceData* myInstanceData = nullptr;
		BSExtraData* myExtraData = ref->extraDataList->GetByType(kExtraData_InstanceData);

		if (myExtraData)
		{
			ExtraInstanceData* myExtraInstanceData = DYNAMIC_CAST(myExtraData, BSExtraData, ExtraInstanceData);
			if (myExtraInstanceData)
			{
				myInstanceData = myExtraInstanceData->instanceData;
			}
		}

		if (myInstanceData)
		{
			return HasKeyword(ref, keyword, myInstanceData);
		}
	}

	return false;
}

bool ActorHasKeyword(Actor* actor, BGSKeyword* keyword)
{
	if (actor)
	{
		TBO_InstanceData* myInstanceData = nullptr;
		BSExtraData* myExtraData = actor->extraDataList->GetByType(kExtraData_InstanceData);

		if (myExtraData)
		{
			ExtraInstanceData* myExtraInstanceData = DYNAMIC_CAST(myExtraData, BSExtraData, ExtraInstanceData);
			if (myExtraInstanceData)
			{
				myInstanceData = myExtraInstanceData->instanceData;
			}
		}

		if (myInstanceData)
		{
			return HasKeywordHelper(actor, keyword, myInstanceData);
		}
	}

	return false;
}

bool NPCHasKeyword(TESNPC* npc, BGSKeyword* keyword)
{
	if (npc)
	{
		for (int i = 0; i < npc->keywords.numKeywords; i++)
		{
			if (npc->keywords.keywords[i] == keyword)
			{
				return true;
			}
		}
	}

	//	if still false, check if race has keyword (doesnt seem to be found on the NPC check if exists on race?)
	TESRace* npcRace = npc->race.race;

	if (npcRace)
	{
		for (int i = 0; i < npcRace->keywordForm.numKeywords; i++)
		{
			if (npcRace->keywordForm.keywords[i] == keyword)
			{
				return true;
			}
		}
	}

	return false;
}

const char* GetItemDisplayName(ExtraDataList* myExtraData, TESForm* baseForm)
{
	BSExtraData* extraData = myExtraData->GetByType(ExtraDataType::kExtraData_TextDisplayData);
	ExtraTextDisplayData* displayText = DYNAMIC_CAST(extraData, BSExtraData, ExtraTextDisplayData);
	if (displayText)
	{
		return (*CALL_MEMBER_FN(displayText, GetReferenceName)(baseForm)).c_str();
	}
	else
	{
		return baseForm->GetFullName();
	}
}

void RemovePipboyInventoryItem(BGSInventoryItem* item, bool bSilent)
{
	if (!bSilent)
	{
		std::string itemName = GetItemDisplayName(item->stack->extraData, item->form);
		itemName.append(" ");
		itemName.append(GetGameSetting("sRemoveItemfromInventory")->data.s);

		NotificationSound(itemName.c_str(), "ITMGenericDown");
	}

	RemovePipboyItem(&(*g_PipboyDataManager)->inventoryData, item);
}

//	Returns True if Game is in Menu Mode
bool IsInMenuMode()
{
	return (
		((*g_ui)->numPauseGame >= 1)
		|| (*g_ui)->IsMenuOpen(BSFixedString("CookingMenu"))
		|| (*g_ui)->IsMenuOpen(BSFixedString("FaderMenu"))
		|| (*g_ui)->IsMenuOpen(BSFixedString("FavoritesMenu"))
		|| (*g_ui)->IsMenuOpen(BSFixedString("PowerArmorModMenu"))
		|| (*g_ui)->IsMenuOpen(BSFixedString("RobotModMenu"))
		|| (*g_ui)->IsMenuOpen(BSFixedString("VATSMenu"))
		|| (*g_ui)->IsMenuOpen(BSFixedString("WorkshopMenu"))
		|| (*g_ui)->IsMenuOpen(BSFixedString("DialogueMenu"))
		);
}

//	Returns True if Player is currently in scene
bool IsPlayerInScene()
{
	//	Need to fill this in once i work out how to get this to work
	return false;
}

// Get Index  in FormList
UInt32 PositionInFormList(TESForm* form, BGSListForm* list) 
{
	if (list->forms.count != 0) {
		for (int i = 0; i <= list->forms.count - 1; i++)
		{
			if (list->forms.entries[i] == form)
			{
				return i;
			}
		}
	}
	return 0;
}


// Gets and return next form player has a count higher than 0 of in list, from current index to start of array
UInt32 GetNextAvailableFormInInventoryFromList(UInt32 startingIndex, BGSListForm* list) {
	if (list->forms.count != 0) {
		for (int a = startingIndex + 1; a <= list->forms.count - 1; a++) {
			if (GetItemCount(GetPlayer(), list->forms.entries[a]) != 0) {
				return a;
			} 
		}

		for (int b = 0; b <= startingIndex; b++) {
			if (GetItemCount(GetPlayer(), list->forms.entries[b]) != 0) {
				return b;
			}
		}
	}
	
	return -1;
}


//	Returns True if Form is in FormList
bool IsFormInList(TESForm* form, BGSListForm* list)
{
	if (list->forms.count != 0) {
		for (int i = 0; i <= list->forms.count - 1; i++)
		{
			if (list->forms.entries[i] == form)
			{
				return true;
			}
		}
	}
	return false;
}

// INI Functions
//=========================================================================================================================

//	Gets Int INI Setting - Internal
UInt32 GetINISettingInt(const char* myINISetting)
{
	Setting* mySetting = GetINISetting(myINISetting);

	return mySetting->data.u32;
}

//	Gets Float INI Setting - Internal
float GetINISettingFloat(const char* myINISetting)
{
	Setting* mySetting = GetINISetting(myINISetting);

	return mySetting->data.f32;
}

//	Gets Bool INI Setting - Internal
bool GetINISettingBool(const char* myINISetting)
{
	Setting* mySetting = GetINISetting(myINISetting);

	return mySetting->data.u8;
}

//	Gets String INI Setting - Internal
const char* GetINISettingString(const char* myINISetting)
{
	Setting* mySetting = GetINISetting(myINISetting);

	return mySetting->data.s;
}

// Functions Exposed to Papyrus
//=========================================================================================================================

//	Gets Int INI Setting - Papyrus
UInt32 GetINISettingInt_Papyrus(StaticFunctionTag*, BSFixedString myINISetting)
{
	const char* myINI = myINISetting;

	return GetINISettingInt(myINI);
}

//	Gets Float INI Setting - Papyrus
float GetINISettingFloat_Papyrus(StaticFunctionTag*, BSFixedString myINISetting)
{
	const char* myINI = myINISetting;

	return GetINISettingFloat(myINI);
}

//	Gets Bool INI Setting - Papyrus
bool GetINISettingBool_Papyrus(StaticFunctionTag*, BSFixedString myINISetting)
{
	const char* myINI = myINISetting;

	return GetINISettingBool(myINI);
}

//	Gets String INI Setting - Papyrus
BSFixedString GetINISettingString_Papyrus(StaticFunctionTag*, BSFixedString myINISetting)
{
	const char* myINI = myINISetting;

	return GetINISettingString(myINI);
}

// VM Functions
//=========================================================================================================================
bool RegisterSharedFunctions(VirtualMachine* vm)
{
	vm->RegisterFunction(new NativeFunction1<StaticFunctionTag, UInt32, BSFixedString>("GetINISettingInt", "FOC:Cascadia", GetINISettingInt_Papyrus, vm));
	vm->RegisterFunction(new NativeFunction1<StaticFunctionTag, float, BSFixedString>("GetINISettingFloat", "FOC:Cascadia", GetINISettingFloat_Papyrus, vm));
	vm->RegisterFunction(new NativeFunction1<StaticFunctionTag, bool, BSFixedString>("GetINISettingBool", "FOC:Cascadia", GetINISettingBool_Papyrus, vm));
	vm->RegisterFunction(new NativeFunction1<StaticFunctionTag, BSFixedString, BSFixedString>("GetINISettingString", "FOC:Cascadia", GetINISettingString_Papyrus, vm));
	return true;
}

//=========================================================================================================================

//	Initialises all Shared RVA addresses
void InitSharedAddresses()
{
	IsDamaged = RVA <_IsDamaged>(
		"IsDamaged", {
			{ RUNTIME_VERSION_1_10_163, 0x0008B270 },
		}, "E8 ? ? ? ? 84 C0 74 1E 48 8B 07");

	EquipItem_int = RVA <_EquipItem_int>(
		"EquipItem_int", {
			{ RUNTIME_VERSION_1_10_130, 0x00E1BBB0 },
			{ RUNTIME_VERSION_1_10_120, 0x00E1BBB0 },
			{ RUNTIME_VERSION_1_10_114, 0x00E1BBB0 },
			{ RUNTIME_VERSION_1_10_111, 0x00E1BBB0 },
			{ RUNTIME_VERSION_1_10_106, 0x00E1BBB0 },
			{ RUNTIME_VERSION_1_10_98, 0x00E1BBB0 },
			{ RUNTIME_VERSION_1_10_89, 0x00E1BB70 },
			{ RUNTIME_VERSION_1_10_82, 0x00E1BB10 },
			{ RUNTIME_VERSION_1_10_75, 0x00E1BB10 },
			{ RUNTIME_VERSION_1_10_50, 0x00E1B730 },
		}, "4C 8B DC 49 89 53 10 55 56 41 54 41 57");
	UnEquipItem_int = RVA <_UnEquipItem_int>(
		"UnEquipItem_int", {
			{ RUNTIME_VERSION_1_10_130, 0x00E1BF90 },
			{ RUNTIME_VERSION_1_10_120, 0x00E1BF90 },
			{ RUNTIME_VERSION_1_10_114, 0x00E1BF90 },
			{ RUNTIME_VERSION_1_10_111, 0x00E1BF90 },
			{ RUNTIME_VERSION_1_10_106, 0x00E1BF90 },
			{ RUNTIME_VERSION_1_10_98, 0x00E1BF90 },
			{ RUNTIME_VERSION_1_10_89, 0x00E1BF50 },
			{ RUNTIME_VERSION_1_10_82, 0x00E1BEF0 },
			{ RUNTIME_VERSION_1_10_75, 0x00E1BEF0 },
			{ RUNTIME_VERSION_1_10_50, 0x00E1BB10 },
		}, "48 8B C4 48 89 58 18 55 57 41 56 48 83 EC 70");
	unk_itemManager = RVA <void*>(
		"unk_itemManager", {
			{ RUNTIME_VERSION_1_10_130, 0x059D7598 },
			{ RUNTIME_VERSION_1_10_120, 0x05A10618 },
			{ RUNTIME_VERSION_1_10_114, 0x05A10618 },
			{ RUNTIME_VERSION_1_10_111, 0x05A10618 },
			{ RUNTIME_VERSION_1_10_106, 0x05A10618 },
			{ RUNTIME_VERSION_1_10_98, 0x05A10618 },
			{ RUNTIME_VERSION_1_10_89, 0x05A10618 },
			{ RUNTIME_VERSION_1_10_82, 0x05A0F618 },
			{ RUNTIME_VERSION_1_10_75, 0x05A0F618 },
			{ RUNTIME_VERSION_1_10_50, 0x05A0F618 },
		}, "48 8B 0D ? ? ? ? 4C 89 7C 24 50 44 88 7C 24 48 C6 44 24 40 01 44 88 7C 24 38 44 88 7C 24 30 89 44 24 28", 0, 3, 7);

	RemoveItem = RVA <_RemoveNonRefItem>(
		"RemoveItem", {
			{ RUNTIME_VERSION_1_10_163, 0x013FCB30 },
		}, "48 8B C4 44 89 40 18 55 53 48 8D 68 B8");

	HasPerk = RVA <_HasPerk>(
		"HasPerk", {
			{ RUNTIME_VERSION_1_10_130, 0x00DA64E0 },
			{ RUNTIME_VERSION_1_10_120, 0x00DA64E0 },
			{ RUNTIME_VERSION_1_10_114, 0x00DA64E0 },
			{ RUNTIME_VERSION_1_10_111, 0x00DA64E0 },
			{ RUNTIME_VERSION_1_10_106, 0x00DA64E0 },
			{ RUNTIME_VERSION_1_10_98, 0x00DA64E0 },
			{ RUNTIME_VERSION_1_10_89, 0x00DA64A0 },
			{ RUNTIME_VERSION_1_10_82, 0x00DA6440 },
			{ RUNTIME_VERSION_1_10_75, 0x00DA6440 },
			{ RUNTIME_VERSION_1_10_64, 0x00DA6480 },
			{ RUNTIME_VERSION_1_10_50, 0x00DA6060 },
			{ RUNTIME_VERSION_1_10_40, 0x00DA5FA0 },
			{ RUNTIME_VERSION_1_10_26, 0x0DA4650 },
			{ RUNTIME_VERSION_1_10_20, 0x0DA45C0 },
			{ RUNTIME_VERSION_1_9_4,   0x0D8C810 },
		}, "48 83 EC 28 48 8B 81 00 03 00 00 48 85 C0 74 ? 4C 8B C2");
	AddPerk = RVA <_AddPerk>(
		"AddPerk", {
			{ RUNTIME_VERSION_1_10_130, 0x00DA60E0 },
			{ RUNTIME_VERSION_1_10_120, 0x00DA60E0 },
			{ RUNTIME_VERSION_1_10_114, 0x00DA60E0 },
			{ RUNTIME_VERSION_1_10_111, 0x00DA60E0 },
			{ RUNTIME_VERSION_1_10_106, 0x00DA60E0 },
			{ RUNTIME_VERSION_1_10_98, 0x00DA60E0 },
			{ RUNTIME_VERSION_1_10_89, 0x00DA60A0 },
			{ RUNTIME_VERSION_1_10_82, 0x00DA6040 },
			{ RUNTIME_VERSION_1_10_75, 0x00DA6040 },
			{ RUNTIME_VERSION_1_10_64, 0x00DA6080 },
			{ RUNTIME_VERSION_1_10_50, 0x00DA5C60 },
			{ RUNTIME_VERSION_1_10_40, 0x00DA5BA0 },
			{ RUNTIME_VERSION_1_10_26, 0x0DA4250 },
			{ RUNTIME_VERSION_1_10_20, 0x0DA41C0 },
			{ RUNTIME_VERSION_1_9_4,   0x0D8C410 },
		}, "48 89 5C 24 08 48 89 6C 24 10 56 57 41 56 48 83 EC 40 48 8D 99 34 04 00 00");
	GetLevel = RVA <_GetLevel>(
		"GetLevel", {
			{ RUNTIME_VERSION_1_10_130, 0x00D79D70 },
			{ RUNTIME_VERSION_1_10_120, 0x00D79D70 },
			{ RUNTIME_VERSION_1_10_114, 0x00D79D70 },
			{ RUNTIME_VERSION_1_10_111, 0x00D79D70 },
			{ RUNTIME_VERSION_1_10_106, 0x00D79D70 },
			{ RUNTIME_VERSION_1_10_98, 0x00D79D70 },
			{ RUNTIME_VERSION_1_10_89, 0x00D79D30 },
			{ RUNTIME_VERSION_1_10_82, 0x00D79CD0 },
			{ RUNTIME_VERSION_1_10_75, 0x00D79CD0 },
			{ RUNTIME_VERSION_1_10_64, 0x00D79D10 },
			{ RUNTIME_VERSION_1_10_50, 0x00D798F0 },
			{ RUNTIME_VERSION_1_10_40, 0x00D79830 },
			{ RUNTIME_VERSION_1_10_26, 0x0D77EE0 },
			{ RUNTIME_VERSION_1_10_20, 0x0D77E50 },
			{ RUNTIME_VERSION_1_9_4,   0x0D600A0 },
		}, "48 8B 89 E0 00 00 00 48 83 C1 68 E9 ? ? ? ?");
	GetItemCount = RVA <_GetItemCount>(
		"GetItemCount", {
			{ RUNTIME_VERSION_1_10_130, 0x013FB5E0 },
			{ RUNTIME_VERSION_1_10_120, 0x013FB5E0 },
			{ RUNTIME_VERSION_1_10_114, 0x013FB5E0 },
			{ RUNTIME_VERSION_1_10_111, 0x013FB5E0 },
			{ RUNTIME_VERSION_1_10_106, 0x013FB5E0 },
			{ RUNTIME_VERSION_1_10_98, 0x013FB5E0 },
			{ RUNTIME_VERSION_1_10_89, 0x013FB5A0 },
			{ RUNTIME_VERSION_1_10_82, 0x013FB540 },
			{ RUNTIME_VERSION_1_10_75, 0x013FB540 },
			{ RUNTIME_VERSION_1_10_64, 0x013FB580 },
			{ RUNTIME_VERSION_1_10_50, 0x013FB160 },
			{ RUNTIME_VERSION_1_10_40, 0x013FB0A0 },
			{ RUNTIME_VERSION_1_10_26, 0x13F9740 },
			{ RUNTIME_VERSION_1_10_20, 0x13F9680 },
			{ RUNTIME_VERSION_1_9_4,   0x13DDAF0 },
		}, "48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 48 83 EC 40 49 8B F9 41 0F B6 E8");

	UnequipItem_Internal = RVA <_UnequipItem>(
		"UnequipItem", {
			{ RUNTIME_VERSION_1_10_163, 0x00E1C0B0 },
		}, "48 8B C4 48 89 58 18 55 57 41 56 48 83");

	g_EquipManager = RVA <void*>(GET_RVA(EquipManager_Address), "48 8B 0D ? ? ? ? 4C 89 7C 24 ?", 0, 3, 7);

	SetQuestStage = RVA <_SetQuestStage>(
		"SetStage", {
			{ RUNTIME_VERSION_1_10_163, 0x005D71E0 },
		}, "48 89 5C 24 ? 57 48 83 EC 30 F6 81 ? ? ? ? ? 0F B7 FA 48 8B D9 0F 84 ? ? ? ? 44 8B 81 ? ? ? ? 0F B7 C2 4C 23 C0 48 8B 81 ? ? ? ? 42 8B 0C 80 8B C1 25 ? ? ? ? 3D ? ? ? ? 0F 84 ? ? ? ? 4C 8B 8B ? ? ? ? 8B C1 44 8B C1 48 C1 E8 10 49 8B 04 C1 66 39 50 18 0F 94 C2 84 D2 75 36");

	IsQuestStageDone = RVA <_IsQuestStageDone>(
		"IsStageDone", {
			{ RUNTIME_VERSION_1_10_163, 0x005D7370 },
		}, "48 8B 81 ? ? ? ? 44 8B 81 ? ? ? ? 44 0F B7 DA 4D 23 C3 4C 8B D1 46 8B 0C 80 41 8B C1 25 ? ? ? ? 3D ? ? ? ? 74 72 4C 8B 81 ? ? ? ? 41 8B C1 41 8B D1 48 C1 E8 10 49 8B 04 C0 66 44 39 58 ? 0F 94 C1 84 C9 75 3D 0F 1F 40 00");
	WornHasKeyword = RVA <_WornHasKeyword>(
		"TESObjectREFR::WornHasKeyword", {
			{ RUNTIME_VERSION_1_10_163, 0x00400050 },
		}, "40 53 48 83 EC 30 33 DB 41 B1 01 45 33 C0 48 89 5C 24 ? E8 ? ? ? ? 85 C0 0F 95 C0 48 83 C4 30 5B C3");

	HasKeyword = RVA <_HasKeyword>(
		"TESObjectREFR::HasKeyword", {
			{ RUNTIME_VERSION_1_10_163, 0x003F6DB0 },
		}, "48 89 5C 24 ? 57 48 83 EC 20 48 8B 41 B0");

	RemovePipboyItem = RVA <_RemovePipboyItem>(
		"PipboyInventoryData::RemoveItem", {
			{ RUNTIME_VERSION_1_10_163, 0x00C11300 },
		}, "48 89 54 24 ? 55 56 41 54 41 55 41 56 48 83 EC 50 45 33 E4 4C 8B F1 48 8B EA 44 89 A4 24 ? ? ? ?");

	HasKeywordHelper = RVA <_HasKeywordHelper>(
		"Actor::HasKeywordHelper", {
			{ RUNTIME_VERSION_1_10_163, 0x00DBA8B0 },
		}, "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC 20 49 8B F8 48 8B EA 48 8B F1 4D 85 C0 75 0F");

	BGSObjectInstanceCtor = RVA <_BGSObjectInstanceCtor>(
		"BGSObjectInstanceCtor", {
			{ RUNTIME_VERSION_1_10_163, 0x002F7B50 },
		}, "48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC 20 48 89 11 49");

	FindRecipe = RVA <_FindRecipe>(
		"FindRecipe", {
			{ RUNTIME_VERSION_1_10_163, 0x002E8480 },
		}, "E8 ? ? ? ? 44 8B 45 D0 48 8D 05 ? ? ? ?", 0, 1, 5);

	IsGodMode = RVA <_IsGodMode>(
		"IsGodMode", {
			{ RUNTIME_VERSION_1_10_163, 0x00EA3BA0 },
		}, "80 3D ? ? ? ? ? 74 34 48 83 3D ? ? ? ? ? 74 27 8B 05 ? ? ? ? 83 F8 06 7F 09 85 C0 78 18 83 F8 05 7C 0E");

}