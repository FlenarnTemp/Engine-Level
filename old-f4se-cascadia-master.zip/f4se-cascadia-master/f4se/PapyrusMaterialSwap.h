#pragma once

struct StaticFunctionTag;
class VirtualMachine;

namespace papyrusMaterialSwap
{
	void RegisterFuncs(VirtualMachine* vm);
}
