#pragma once

struct StaticFunctionTag;
class VirtualMachine;

namespace papyrusUI
{
	void RegisterFuncs(VirtualMachine* vm);
}
