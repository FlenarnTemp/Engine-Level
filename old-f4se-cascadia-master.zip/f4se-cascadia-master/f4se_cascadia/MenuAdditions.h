#pragma once
#include "Scaleform.h"

namespace HUD {
	void UpdateMenus(GFxMovieRoot* myMovieRoot);
}

namespace Examine {
	void RegisterForInput(bool bRegister);
}

namespace Pipboy {
	void GetINIOptions();

	bool CheckWorkshopTab();

	void UpdateMenus(GFxMovieRoot* myMovieRoot);

	void UpdateItemCardsOnSection(UInt32 section);
}

enum PageTypes {
	PipboyPage_Skills = 0,
};