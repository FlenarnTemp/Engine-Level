#pragma once

// Internal Includes
#include "main.h"

namespace AmmoSwitch {
	void ProcessUserEvent(const char* controlName, bool isDown, int deviceType, UInt32 keyCode);

	void RegisterForInput(bool bRegister);

	void AmmoSwitch(TESAmmo* newAmmo);

	TESAmmo*	GetCoreAmmo();
	TESAmmo*	GetNextAvailableAmmo();
	void		ResetToCoreAmmo();

	#ifndef AmmoSwitchValuesstruct
	#define AmmoSwitchValuesstruct
	struct AmmoSwitchValues_Struct {
		bool isCurrentlySwitching = false;
	};
	#endif
	extern AmmoSwitchValues_Struct AmmoSwitchValues;

}