#pragma once
 
class VirtualMachine;

namespace papyrusEncounterZone
{
	void RegisterFuncs(VirtualMachine* vm);
}
