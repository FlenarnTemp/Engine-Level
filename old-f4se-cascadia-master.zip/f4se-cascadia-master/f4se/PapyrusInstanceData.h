#pragma once

struct StaticFunctionTag;
class VirtualMachine;

namespace papyrusInstanceData
{
	void RegisterFuncs(VirtualMachine* vm);
}
