#include "main.h"

//	Event Handlers
//=========================================================================================================================

RVA <BSTEventDispatcher<LevelIncrease::Event>*> LevelIncreaseEvent_Address;
RVA <uintptr_t> TESCellFullyLoadedEvent_Address;
RVA <uintptr_t> TESCellAttachDetachEvent_Address;
RVA <uintptr_t> TESEquipEvent_Address;
RVA <uintptr_t> TESHitEvent_Address;
RVA <uintptr_t> TESContainerChangedEvent_Address;

//  Level Increase
EventResult	LevelIncreaseEventHandler::ReceiveEvent(LevelIncrease::Event* event, void* dispatcher)
{
	LevelUpMenu::HandleLevelUp(event);
	return kEvent_Continue;
}
LevelIncreaseEventHandler g_LevelIncreaseEventHandler;

//	Object Loaded
EventResult TESObjectLoadedEventHandler::ReceiveEvent(TESObjectLoadedEvent* evn, void* dispatcher)
{
	if (evn)
	{
		if (evn->loaded)
		{
			TESForm* myEventItem = LookupFormByID(evn->formId);

		}
	}
	return kEvent_Continue;
}
TESObjectLoadedEventHandler g_TESObjectLoadedEventHandler;

//	Init Script
EventResult TESInitScriptEventHandler::ReceiveEvent(TESInitScriptEvent* evn, void* dispatcher)
{
	if (evn)
	{
		if (evn->reference)
		{
			switch (evn->reference->baseForm->formType)
			{
			case kFormType_ACHR:
			case kFormType_NPC_:
			case kFormType_REFR:
				CheckForNPCWeaponConditionPerk(evn->reference);
				break;

			case kFormType_CONT:
				InitializeInventoryCondition(evn->reference);
				break;

			case kFormType_AMMO:
				break;

			case kFormType_ARMO:
				InitializeArmorCondition(evn->reference);
				break;

			case kFormType_WEAP:
				InitializeWeaponCondition(evn->reference);
				break;

			case kFormType_ACTI:
			case kFormType_ALCH:
			case kFormType_ASPC:
			case kFormType_BOOK:
			case kFormType_BNDS:
			case kFormType_DOOR:
			case kFormType_EXPL:
			case kFormType_FLOR:
				break;
			case kFormType_FURN:
				InitializePowerArmorFrameInventoryCondition(evn->reference);
				break;

			case kFormType_HAZD:
			case kFormType_IDLM:
			case kFormType_LIGH:
			case kFormType_KEYM:
			case kFormType_MISC:
			case kFormType_MSTT:
			case kFormType_NOTE:
			case kFormType_PGRE:
			case kFormType_SCOL:
			case kFormType_SOUN:
			case kFormType_STAT:
			case kFormType_TACT:
			case kFormType_TERM:
				break;

			default:
				break;
			}
		}
	}

	return kEvent_Continue;
}
TESInitScriptEventHandler g_TESInitScriptEventHandler;

//	Item Equipped (Any NPC including Player)
EventResult TESEquipEventHandler::ReceiveEvent(TESEquipEvent* evn, void* dispatcher)
{
	if (evn)
	{
		ItemDegredation_ItemEquipped(evn);
	}

	return kEvent_Continue;
}
TESEquipEventHandler g_TESEquipEventHandler;

/*
class TESEquipEventHandler : public BSTEventSink<TESEquipEvent>
{
public:
	virtual	EventResult	ReceiveEvent(TESEquipEvent* evn, void* dispatcher) override
	{
		ItemEquipped(evn);
		return kEvent_Continue;
	}
};
TESEquipEventHandler g_TESEquipEventHandler;
*/

class TESLoadGameHandler : public BSTEventSink<TESLoadGameEvent>
{
public:
	virtual ~TESLoadGameHandler() { };
	virtual    EventResult    ReceiveEvent(TESLoadGameEvent* evn, void* dispatcher) override
	{
		//_MESSAGE("TESLoadGameHandler");

		LevelUpMenu::CheckForLevelUp();
		//Scaleform::RemoveHUDDropShadow();
		//CallGlobalFunctionNoWait1<BSFixedString>("TCW:F4CW", "RegisterCustomMenus", BSFixedString(""));

		return kEvent_Continue;
	}
};

//	Cell Fully Loaded
EventResult TESCellFullyLoadedEventHandler::ReceiveEvent(TESCellFullyLoadedEvent* evn, void* dispatcher)
{
	if (evn)
	{
		TESObjectCELL* currentCell = evn->pCell;

	}
	return kEvent_Continue;
}
TESCellFullyLoadedEventHandler g_TESCellFullyLoadedEventHandler;

//	Cell Attach/Detach
EventResult TESCellAttachDetachEventHandler::ReceiveEvent(TESCellAttachDetachEvent* evn, void* dispatcher)
{
	if (evn)
	{
		if (evn->bAttached)
		{
			TESObjectREFR* ref = evn->pRef.m_pObject;

			if (ref)
			{
				switch (ref->baseForm->formType)
				{
				case kFormType_CONT:
					//_MESSAGE("Initialising Container %s during TESCellAttachDetachEvent", ref->baseForm->GetFullName());
					InitializeInventoryCondition(ref);
					break;
				case FormType::kFormType_WEAP:
					//_MESSAGE("Initialising Weapon %s during TESCellAttachDetachEvent", ref->baseForm->GetFullName());
					InitializeWeaponCondition(ref);
					break;

				case FormType::kFormType_ARMO:
					//_MESSAGE("Initialising Armor %s during TESCellAttachDetachEvent", ref->baseForm->GetFullName());
					InitializeArmorCondition(ref);
					break;
				case FormType::kFormType_FURN:
					//_MESSAGE("Initialising Furniture %s during TESCellAttachDetachEvent", ref->baseForm->GetFullName());
					InitializePowerArmorFrameInventoryCondition(ref);
					break;

				default:
					break;
				}
			}
		}
	}
	return kEvent_Continue;
}
TESCellAttachDetachEventHandler g_TESCellAttachDetachEventHandler;

EventResult MenuOpenCloseEventHandler::ReceiveEvent(MenuOpenCloseEvent* evn, void* dispatcher)
{
	if (evn)
	{
		if (evn->isOpen)
		{
			//	Menu Opened
		}
		else
		{
			//	Menu Closed
			if (evn->menuName == BSFixedString("PipboyMenu"))
			{
				if (WPNUtilities::GetEquippedWeaponForm(GetPlayer()))
				{
					WeaponConditionData Data(GetPlayer());

					WPNUtilities::UpdateHUDCondition(Data);
				}
			} else if (evn->menuName == BSFixedString("ExamineMenu")) {
				Examine::RegisterForInput(false);
			}
		}
	}

	return kEvent_Continue;
}
MenuOpenCloseEventHandler g_MenuOpenCloseEventHandler;

EventResult TESHitEvent2Handler::ReceiveEvent(TESHitEvent2* evn, void* dispatcher)
{
	if (evn)
	{
		TraceLog("TESHitEvent:");
		if (evn->bUsesHitData)
		{
			if (evn->hitData.hTarget)
			{
				_MESSAGE("Target = %s", evn->hitData.hTarget->GetFullName());
			}
			if (evn->hitData.hAggressor)
			{
				_MESSAGE("Aggressor = %s", evn->hitData.hAggressor->GetFullName());
			}
			if (evn->hitData.hSourceRef)
			{
				_MESSAGE("Source = %s", evn->hitData.hSourceRef->GetFullName());
			}
			if (LookupFormByID(evn->uiProjectileFormID))
			{
				_MESSAGE("Projectile = %s", LookupFormByID(evn->uiProjectileFormID)->GetFullName());
			}
			if (evn->hitData.fTotalDamage)
			{
				_MESSAGE("Damage = %f", evn->hitData.fTotalDamage);
			}
		}
		else
		{
			_MESSAGE("No HitData");
		}
	}

	return kEvent_Continue;
}
TESHitEvent2Handler g_TESHitEventHandler;

namespace Events
{
	void RegisterForEvents()
	{
		REGISTER_EVENT(LevelIncrease::Event, g_LevelIncreaseEventHandler);
		REGISTER_EVENT(TESInitScriptEvent, g_TESInitScriptEventHandler);
		REGISTER_EVENT(TESEquipEvent, g_TESEquipEventHandler);
		//REGISTER_EVENT(TESCellFullyLoadedEvent, g_TESCellFullyLoadedEventHandler);
		//REGISTER_EVENT(TESObjectLoadedEvent, g_TESObjectLoadedEventHandler);
		REGISTER_EVENT(TESCellAttachDetachEvent, g_TESCellAttachDetachEventHandler);
		//REGISTER_EVENT(TESHitEvent2, g_TESHitEventHandler);	//	Disabled for now due to crashing, although will likely need it for Armor Condition

		if ((*g_ui) != nullptr)
		{
			(*g_ui)->menuOpenCloseEventSource.AddEventSink(&g_MenuOpenCloseEventHandler);
		}
	}

	void InitAddresses()
	{
		LevelIncreaseEvent_Address = RVA <BSTEventDispatcher<LevelIncrease::Event>*>(
			"LevelIncreaseEvent", {
				{ RUNTIME_VERSION_1_10_163, 0x00EC3140 },
				{ RUNTIME_VERSION_1_10_130, 0x00EC3020 },
				{ RUNTIME_VERSION_1_10_120, 0x00EC3020 },
				{ RUNTIME_VERSION_1_10_114, 0x00EC3020 },
				{ RUNTIME_VERSION_1_10_111, 0x00EC3020 },
				{ RUNTIME_VERSION_1_10_106, 0x00EC3020 },
				{ RUNTIME_VERSION_1_10_98, 0x00EC3020 },
				{ RUNTIME_VERSION_1_10_89, 0x00EC2FE0 },
				{ RUNTIME_VERSION_1_10_82, 0x00EC2F80 },
				{ RUNTIME_VERSION_1_10_75, 0x00EC2F80 },
				{ RUNTIME_VERSION_1_10_64, 0x00EC2FC0 },
				{ RUNTIME_VERSION_1_10_50, 0x00EC2BA0 },
			}, "E8 ? ? ? ? 48 8D 54 24 38 48 8B C8 E8 ? ? ? ? 48 8B CE", 0, 1, 5);
		TESCellFullyLoadedEvent_Address = RVA <uintptr_t>(
			"TESCellFullyLoadedEvent", {
				{ RUNTIME_VERSION_1_10_163, 0x00441FB0 },
			}, "E8 ? ? ? ? 48 8D 54 24 ? 48 8B C8 E8 ? ? ? ? 48 83 C4 28 C3 CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC 48 89 5C 24 ?", 0, 1, 5);
		TESCellAttachDetachEvent_Address = RVA <uintptr_t>(
			"TESCellAttachDetachEvent", {
				{ RUNTIME_VERSION_1_10_163, 0x00441F10 },
			}, "E8 ? ? ? ? 48 8D 54 24 ? 48 8B C8 E8 ? ? ? ? 48 8B 4C 24 ? 48 85 C9 74 1B 48 83 C1 20 83 C8 FF F0 0F C1 41 ? FF C8 A9 ? ? ? ? 75 06 48 8B 01 FF 50 08 48 83 C4 38 C3 CC CC CC CC CC CC 48 89 5C 24 ?", 0, 1, 5);
		TESEquipEvent_Address = RVA <uintptr_t>(
			"TESEquipEvent", {
				{ RUNTIME_VERSION_1_10_163, 0x00442870 },
			}, "E8 ? ? ? ? 48 8B D3 48 8B C8 48 83 C4 20 5B E9 ? ? ? ? CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC 48 83 EC 48 48 8B 01 48 89 44 24 ? 48 85 C0 74 04 F0 FF 40 28 48 89 44 24 ? 0F B6 44 24 ?", 0, 1, 5);
		TESHitEvent_Address = RVA <uintptr_t>(
			"TESHitEvent", {
				{ RUNTIME_VERSION_1_10_163, 0x00444670 },
			}, "E8 ? ? ? ? 48 8B D3 48 8B C8 48 83 C4 20 5B E9 ? ? ? ? CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC 48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 81 EC ? ? ? ?", 0, 1, 5);
		TESContainerChangedEvent_Address = RVA <uintptr_t>(
			"TESContainerChangedEvent", {
				{ RUNTIME_VERSION_1_10_163, 0x004424B0 },
			}, "E8 ? ? ? ? 48 8D 54 24 ? 48 8B C8 E8 ? ? ? ? 48 83 C4 48 C3 CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC 40 53", 0, 1, 5);
	}
}