#pragma once
#include "main.h"
#include "f4se/PapyrusInput.h"
#include "f4se/InputMap.h"
#include "f4se/GameReferences.h"
#include "f4se/PapyrusStruct.h"
#include "f4se/GameMenus.h"
#include "xbyak/xbyak.h"
#include "f4se_common/BranchTrampoline.h"
#include "f4se/bhkWorld.h"

#include "MenuAdditions.h"
#include "EventDefinitions.h"
#include "MenuDefinitions.h"
#include "ItemDegredation.h"

#include <fstream>

typedef void                (*_PopulateItemCard)            (GFxValue* InfoObj, BGSInventoryItem* Item, UInt16 StackID, InvItemStackList CompareList);
typedef void                (*_PipboyMenuInvoke)            (PipboyMenu* menu, GFxFunctionHandler::Args* args);
typedef BGSInventoryItem*   (*_GetItemByHandleID)           (InventoryInterface* invInterface, UInt32* handleID);
typedef TESForm*            (*_GetFormByHandleID)           (InventoryInterface* invInterface, UInt32* handleID);
typedef BGSInventoryItem*   (*_RequestInventoryItem)        (InventoryInterface* invInterface, UInt32* indexID);

extern RVA <_GetItemByHandleID> GetItemByHandleID_Internal;

extern RVA  <PipboyDataManager*>    g_PipboyDataManager;
extern RVA  <InventoryInterface*>   g_InventoryInterface;

#define GetTableItem(Index, Name)\
    ((*g_PipboyDataManager)->inventoryData.inventoryObjects[Index]->table.Find(&BSFixedString(Name)))

#define GetTableValue(Type, Index, Name)\
    ((PipboyPrimitiveValue<Type>*)(GetTableItem(Index, Name)->value))->value

#define GetTableArray(Index, Name)\
    ((PipboyArray*)GetTableItem(Index, Name)->value)

#define GetTableArrayValue(Type, Index, Array)\
    ((PipboyPrimitiveValue<Type>*)Array->value[Index])->value

#define PipboyInventoryObjects (*g_PipboyDataManager)->inventoryData.inventoryObjects

#define DECLARE_EVENT_CLASS(Event)\
class Event##Handler : public BSTEventSink<Event> {\
public:\
    virtual ~Event##Handler() { };\
    virtual	EventResult	ReceiveEvent(Event* evn, void* dispatcher) override;\
};\
extern Event##Handler g_##Event##Handler

#define DECLARE_CUSTOM_MENU(MenuName)\
class MenuName## : public GameMenuBase {\
public:\
    MenuName##();\
    virtual ~##MenuName##();\
    static const char* sMenuName;\
    static void OpenMenu() {\
        BSFixedString MenuName(sMenuName);\
        CALL_MEMBER_FN((*g_uiMessageManager), SendUIMessage)(MenuName, kMessage_Open);\
    }\
    static void CloseMenu() {\
        BSFixedString MenuName(sMenuName);\
        CALL_MEMBER_FN((*g_uiMessageManager), SendUIMessage)(MenuName, kMessage_Close);\
    }\
    virtual void DrawNextFrame(float unk0, void* unk1) override final;\
    virtual void RegisterFunctions() override final;\
    DEFINE_STATIC_HEAP(ScaleformHeap_Allocate, ScaleformHeap_Free)\
}

namespace Menus  {
	DECLARE_CUSTOM_MENU(CASLevelUpMenu);
    DECLARE_CUSTOM_MENU(CWHUDAdditions);
}

namespace GFxUtilities {
    void RegisterArray(GFxValue* destination, GFxMovieRoot* root, const char* name, GFxValue* myArray);
	void RegisterString(GFxValue* destination, GFxMovieRoot* root, const char* name, const char* str);
	void RegisterNumber(GFxValue* destination, const char* name, double value);
	void RegisterInt(GFxValue* destination, const char* name, int value);
    void RegisterUInt(GFxValue* destination, const char* name, UInt32 value);
	void RegisterBool(GFxValue* destination, const char* name, bool value);
}

namespace Scaleform {
	bool OpenMenu_Internal(std::string myMenu);
	bool CloseMenu_Internal(std::string myMenu);
    bool IsMenuOpen_Internal(std::string myMenu);
    GFxMovieRoot* GetMovieRootByName(const char* menuName);
	void GetSkillForms();
	void RemoveHUDDropShadow();
    bool RegisterCustomMenus();
	bool RegisterScaleform(GFxMovieView* movieView, GFxValue* f4se_root);
    void InitAddresses();
}

namespace InventoryUtils {
    UInt32 GetPipboyInventoryObjectCount();
    std::string GetInventoryDisplayName(UInt32 index);
    UInt32 GetHandleIDByIndex(UInt32 index);
    UInt32 GetStackIDByIndex(UInt32 index);
    TESForm* GetInventoryFormByHandleID(UInt32 HandleID);
    TESForm* GetInventoryFormByIndex(UInt32 index);
    BGSInventoryItem* GetInventoryItemByHandleID(UInt32 HandleID);
    BGSInventoryItem* GetInventoryItemByIndex(UInt32 index);
    UInt32 GetIndexByInventoryItem(BGSInventoryItem* item);
    BGSInventoryItem::Stack* GetStackByStackID(BGSInventoryItem* Item, int StackID);
    ExtraDataList* GetExtraDataListByStackID(BGSInventoryItem* Item, int StackID);
    ExtraDataList* GetExtraDataListByIndex(UInt32 index);
}

enum PipboyInvPages
{
    kPage_Weapons = 0,
    kPage_Apparel,
    kPage_Aid,
    kPage_Misc,
    kPage_Junk,
    kPage_Mods,
    kPage_Ammo
};

extern _PipboyMenuInvoke PipboyMenuInvoke_Original;
void HookPipboyMenuInvoke(void (*hookFunc)(PipboyMenu*, GFxFunctionHandler::Args*));
void PipboyMenuInvoke_Hook(PipboyMenu* menu, GFxFunctionHandler::Args* args);

void PopulateItemCard_Custom(GFxValue* InfoObj, BGSInventoryItem* Item, UInt16 StackID, InvItemStackList CompareList);
extern _PopulateItemCard PopulateItemCard_Original;
void HookPopulateItemCard(void (*hookFunc)(GFxValue*, BGSInventoryItem*, UInt16, InvItemStackList));

void PopulateItemCard_Hook(GFxValue* InfoObj, BGSInventoryItem* Item, UInt16 StackID, InvItemStackList CompareList);