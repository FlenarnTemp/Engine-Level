#include "AmmoSwitch.h"
#include "ConsoleCommands.h"

namespace AmmoSwitch {
	AmmoSwitchValues_Struct AmmoSwitchValues;

	//	Input Handling Start
	//	================================================================================

	class F4SEInputHandler : public BSInputEventUser
	{
	public:
		F4SEInputHandler() : BSInputEventUser(true) { }

		virtual void OnButtonEvent(ButtonEvent* inputEvent)
		{
			UInt32	keyCode;
			UInt32	deviceType = inputEvent->deviceType;
			UInt32	keyMask = inputEvent->keyMask;

			if (deviceType == InputEvent::kDeviceType_Mouse)
			{
				keyCode = InputMap::kMacro_MouseButtonOffset + keyMask;
			}
			else if (deviceType == InputEvent::kDeviceType_Gamepad)
			{
				keyCode = InputMap::GamepadMaskToKeycode(keyMask);
			}
			else
			{
				keyCode = keyMask;
			}

			float timer = inputEvent->timer;
			bool isDown = inputEvent->isDown == 1.0f && timer == 0.0f;
			bool isUp = inputEvent->isDown == 0.0f && timer != 0.0f;

			BSFixedString* control = inputEvent->GetControlID();

			if (isDown)
			{
				ProcessUserEvent(control->c_str(), true, deviceType, keyCode);
			}
			else if (isUp)
			{
				ProcessUserEvent(control->c_str(), false, deviceType, keyCode);
			}

		}
	};

	F4SEInputHandler g_ammoSwitchInputHandler;

	void ProcessUserEvent(const char* controlName, bool isDown, int deviceType, UInt32 keyCode)
	{
		if (keyCode == 50) {
			if (!AmmoSwitchValues.isCurrentlySwitching) {
				if (!IsInMenuMode() && !IsFalling(GetPlayer()) && IsAttackReady(GetPlayer())) {
					TESObjectWEAP* equippedWeapon = DYNAMIC_CAST(WPNUtilities::GetEquippedWeaponForm(GetPlayer()), TESForm, TESObjectWEAP);
					TESObjectWEAP::InstanceData* equippedWeaponInstanceData = WPNUtilities::GetEquippedWeaponInstanceData(GetPlayer());

					if (equippedWeapon != nullptr && equippedWeapon->weapData.unk137 == kWeaponType_Gun) {
						TESAmmo* ammoToSwapTo = GetNextAvailableAmmo();
						if (ammoToSwapTo != equippedWeaponInstanceData->ammo) {
							AmmoSwitch(ammoToSwapTo);
						}
					}
				}
			}
		}
	}

	void RegisterForInput(bool bRegister)
	{
		if (bRegister)
		{
			g_ammoSwitchInputHandler.enabled = true;
			tArray<BSInputEventUser*>* inputEvents = &((*g_menuControls)->inputEvents);
			BSInputEventUser* inputHandler = &g_ammoSwitchInputHandler;
			int idx = inputEvents->GetItemIndex(inputHandler);
			if (idx == -1)
			{
				inputEvents->Push(&g_ammoSwitchInputHandler);
			}
		}
		else
		{
			g_ammoSwitchInputHandler.enabled = false;
		}
	}

	void ResetToCoreAmmo() {
		TESObjectWEAP::InstanceData* myEquippedWeaponInstanceData = WPNUtilities::GetEquippedWeaponInstanceData(GetPlayer());
		myEquippedWeaponInstanceData->ammo = GetCoreAmmo();
	}

	TESAmmo* GetCoreAmmo() {
		TESObjectWEAP* equippedWeapon = DYNAMIC_CAST(WPNUtilities::GetEquippedWeaponForm(GetPlayer()), TESForm, TESObjectWEAP);
		return equippedWeapon->weapData.ammo;
	}

	TESAmmo* GetNextAvailableAmmo() {

		BGSListForm* masterListAmmoSwitches = reinterpret_cast<BGSListForm*>(GetFormFromIdentifier("FalloutCascadia.esm|1FB3B5"));

		TESAmmo* coreAmmo = GetCoreAmmo();

		bool hasSwaps = false;

		BGSListForm* relevantAmmoList = masterListAmmoSwitches;

		for (int i = 0; i <= masterListAmmoSwitches->forms.count - 1; i++) {
			BGSListForm* tempList = DYNAMIC_CAST(masterListAmmoSwitches->forms.entries[i], TESForm, BGSListForm);
			if (IsFormInList(coreAmmo, tempList)) {
				hasSwaps = true;
				relevantAmmoList = tempList;
				continue;
			} 
		}

		TESObjectWEAP::InstanceData* myEquippedWeaponInstanceData = WPNUtilities::GetEquippedWeaponInstanceData(GetPlayer());
			
		if (!hasSwaps)
		{
			ShowNotification("There are no ammunition swaps for this weapon.");
			return myEquippedWeaponInstanceData->ammo;
		}

		UInt32 nextAvailable = GetNextAvailableFormInInventoryFromList(PositionInFormList(myEquippedWeaponInstanceData->ammo, relevantAmmoList), relevantAmmoList);

		if (nextAvailable != PositionInFormList(myEquippedWeaponInstanceData->ammo, relevantAmmoList) && nextAvailable != -1)
		{
			TESAmmo* nextAvailableAmmo = DYNAMIC_CAST(relevantAmmoList->forms.entries[nextAvailable], TESForm, TESAmmo);
			return nextAvailableAmmo;
		}
		else 
		{
			ShowNotification("You have no alternative ammunition to swap to.");
		}
		
		return myEquippedWeaponInstanceData->ammo;
	}

	bool AmmoHasKeyword(TESAmmo* ammo, BGSKeyword* keyword)
	{
		if (ammo->keywordForm.numKeywords != 0)
		{
			for (int i = 0; i < ammo->keywordForm.numKeywords; i++)
			{
				if (ammo->keywordForm.keywords[i] == keyword)
				{
					return true;
				}
			}
		}

		return false;
	}

	void AmmoOMODSwitch(TESAmmo* newAmmo) {

		BGSKeyword* apKeyword	= reinterpret_cast<BGSKeyword*>(GetFormFromIdentifier("FOC_Flen.esp|A89")); // TODO - update to for in FalloutCascadia.esm
		BGSKeyword* hpKeyword	= reinterpret_cast<BGSKeyword*>(GetFormFromIdentifier("FOC_Flen.esp|A8A")); // TODO - update to for in FalloutCascadia.esm
		BGSKeyword* incKeyword	= reinterpret_cast<BGSKeyword*>(GetFormFromIdentifier("FOC_Flen.esp|A8B")); // TODO - update to for in FalloutCascadia.esm
		BGSKeyword* heKeyword	= reinterpret_cast<BGSKeyword*>(GetFormFromIdentifier("FOC_Flen.esp|A8D")); // TODO - update to for in FalloutCascadia.esm

		BGSMod* hpOMOD = reinterpret_cast<BGSMod*>(GetFormFromIdentifier("FOC_Flen.esp|D9C")); // TODO - update to for in FalloutCascadia.esm

		TESObjectREFR* myEquippedWeapon = DYNAMIC_CAST(WPNUtilities::GetEquippedWeaponForm(GetPlayer()), TESForm, TESObjectREFR);
		TESObjectWEAP::InstanceData* myEquippedWeaponInstanceData = WPNUtilities::GetEquippedWeaponInstanceData(GetPlayer());
		TESAmmo* currentAmmo = myEquippedWeaponInstanceData->ammo;

		// Get keyword on current ammo, remove OMOD attatchment, then add back OMOD matching new ammo.
		if (currentAmmo != GetCoreAmmo()) { // No need to check current ammo to remove OMOD on core ammo type.
			if (AmmoHasKeyword(currentAmmo, apKeyword)) {
				ShowNotification("Found AP keyword on current ammo!");
			} else if (AmmoHasKeyword(currentAmmo, hpKeyword)) {
				ShowNotification("Found HP keyword on current ammo!");
				RemoveMod(myEquippedWeapon, hpOMOD);
			} else if (AmmoHasKeyword(currentAmmo, incKeyword)) {
				ShowNotification("Found INC keyword on current ammo!");
			} else if (AmmoHasKeyword(currentAmmo, heKeyword)) {
				ShowNotification("Found HE keyword on current ammo!");
			}
		}

		if (newAmmo != GetCoreAmmo()) { // No need to check new ammo to add OMOD on core ammo type.
			if (AmmoHasKeyword(newAmmo, apKeyword)) {
				ShowNotification("Found AP keyword on new ammo!");
			}
			else if (AmmoHasKeyword(newAmmo, hpKeyword)) {
				ShowNotification("Found HP keyword on new ammo!");
				AttachMod(myEquippedWeapon, hpOMOD, 0);
			}
			else if (AmmoHasKeyword(newAmmo, incKeyword)) {
				ShowNotification("Found INC keyword on new ammo!");
			}
			else if (AmmoHasKeyword(newAmmo, heKeyword)) {
				ShowNotification("Found HE keyword on new ammo!");
			}
		}
	}

	void AmmoSwitch(TESAmmo* newAmmo) {
		AmmoSwitchValues.isCurrentlySwitching = true;
		AmmoOMODSwitch(newAmmo);

		Actor* player = GetPlayer();

		TESObjectWEAP::InstanceData* myEquippedWeaponInstanceData = WPNUtilities::GetEquippedWeaponInstanceData(GetPlayer());

		TESAmmo* coreAmmo = GetCoreAmmo();
		TESAmmo* currentAmmo = myEquippedWeaponInstanceData->ammo;

		bool coreAndNewSame = false;
		bool coreAndCurrentSame = false;

		UInt32 coreAmmoCount = GetItemCount(player, coreAmmo);
		UInt32 currentAmmoCount = GetItemCount(player, currentAmmo);
		UInt32 newAmmoCount = GetItemCount(player, newAmmo);


		if (coreAmmo == newAmmo) {
			coreAndNewSame = true;
		} else if (coreAmmo == currentAmmo) {
			coreAndCurrentSame = true;
		}

		if (coreAndCurrentSame)
		{
			coreAmmoCount = GetItemCount(player, coreAmmo);
			newAmmoCount = GetItemCount(player, newAmmo);

			if (coreAmmoCount != 0)
			{
				RemoveItem(player, coreAmmo, -1, true, nullptr);
			}
			RemoveItem(player, newAmmo, -1, true, nullptr);
		} 
		else if (coreAndNewSame)
		{
			coreAmmoCount = GetItemCount(player, coreAmmo);
			currentAmmoCount = GetItemCount(player, currentAmmo);

			RemoveItem(player, coreAmmo, -1, true, nullptr);
			if (currentAmmoCount != 0)
			{
				RemoveItem(player, currentAmmo, -1, true, nullptr);
			}
		}
		else {
			coreAmmoCount = GetItemCount(player, coreAmmo);
			currentAmmoCount = GetItemCount(player, currentAmmo);
			newAmmoCount = GetItemCount(player, newAmmo);
			if (coreAmmoCount != 0)
			{
				RemoveItem(player, coreAmmo, -1, true, nullptr);
			}
			if (currentAmmoCount != 0) {
				RemoveItem(player, currentAmmo, -1, true, nullptr);
			}
			RemoveItem(player, newAmmo, -1, true, nullptr);
		}

		myEquippedWeaponInstanceData->ammo = newAmmo;

		if (coreAndNewSame) {
			AddItem(player, coreAmmo, coreAmmoCount, true);
		} else {
			AddItem(player, newAmmo, newAmmoCount, true);
		}

		//Reload Action - triggers even if current amagazine is full. Not 100% consistent, check completion state and call again if needed, currently called 5 times.
		if (!PerformAction(GetPlayer(), reinterpret_cast<BGSAction*>(GetFormFromIdentifier("Fallout4.esm|4A56")), nullptr)) {
			ShowNotification("Reload animation failed.");
			AmmoSwitchValues.isCurrentlySwitching = false;
		}

		if (!coreAndNewSame && !coreAndCurrentSame) {
			AddItem(player, coreAmmo, coreAmmoCount, true);
		}
		AddItem(player, currentAmmo, currentAmmoCount, true);
	}
}