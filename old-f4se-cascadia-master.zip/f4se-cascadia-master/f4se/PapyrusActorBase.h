#pragma once

#include "f4se/GameTypes.h"
 
class VirtualMachine;
 
namespace papyrusActorBase
{
	void RegisterFuncs(VirtualMachine* vm);
};
