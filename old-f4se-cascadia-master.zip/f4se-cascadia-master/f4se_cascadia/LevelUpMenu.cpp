#include "LevelUpMenu.h"

RVA <BSTEventDispatcher<LevelIncrease::Event>*> LevelIncrease__Event_Dispatcher_address;

UInt32 playerLevel;
UInt8 playerSex;
float perkPoints;

int menuModeType = 0;

int tagPointsValue = 0;
bool allowRetag = false;

namespace InitialValues
{
	int Barter;
	int EnergyWeapons;
	int Explosives;
	int Guns;
	int Lockpick;
	int Medicine;
	int MeleeWeapons;
	int Repair;
	int Science;
	int Sneak;
	int Speech;
	int Survival;
	int Unarmed;
}

namespace TempModValues
{
	int Barter;
	int EnergyWeapons;
	int Explosives;
	int Guns;
	int Lockpick;
	int Medicine;
	int MeleeWeapons;
	int Repair;
	int Science;
	int Sneak;
	int Speech;
	int Survival;
	int Unarmed;
}

tArray<BGSPerk*> CascadiaPerks;
tArray<ActorValueInfo*> CascadiaSkills;

std::string myMenuName = "CASLevelUpMenu";

RVA <_SetPerkPoints_int> SetPerkPoints;

bool bForceLevelUp = true;

namespace LevelUpMenu
{
	//	Gets Level Up Menu related INI settings from FalloutCascadia.ini
	void GetINIOptions()
	{
		std::string myINI = "./Data/FalloutCascadia.ini";
		bool forceLevelUp;
		forceLevelUp = GetPrivateProfileInt("Gameplay", "bForceLevelUp", 1, myINI.c_str());

		bForceLevelUp = forceLevelUp;
	}

	//	Returns true if forced level up is enabled
	bool GetForcedLevelUp()
	{
		return bForceLevelUp;
	}

	//	Gets Skills and Perks from Cascadia
	void GetLevelUpFormsFromGame()
	{
		TraceLog("Getting Level Up related forms from FalloutCascadia.esm");
	
		auto perksListCAS = DYNAMIC_CAST(GetFormFromIdentifier("FalloutCascadia.esm|21F9DFA"), TESForm, BGSListForm);
		for (int p = 0; p < perksListCAS->forms.count; p++)
		{
			BGSPerk* myPerk = DYNAMIC_CAST(perksListCAS->forms.entries[p], TESForm, BGSPerk);
			if (myPerk == nullptr)
			{
				//Item is not a perk
				continue;
			}
			CascadiaPerks.Push(myPerk);
		}
		_DMESSAGE("Found %i Perks from Cascadia", CascadiaPerks.count);
	
		
		auto skillsListCAS = DYNAMIC_CAST(GetFormFromIdentifier("FalloutCascadia.esm|21F9DF1"), TESForm, BGSListForm);
		for (int s = 0; s < skillsListCAS->forms.count; s++)
		{
			ActorValueInfo* mySkill = DYNAMIC_CAST(skillsListCAS->forms.entries[s], TESForm, ActorValueInfo);
			if (mySkill == nullptr)
			{
				//Item is not an ActorValue
				continue;
			}
			CascadiaSkills.Push(mySkill);
		}
		Scaleform::GetSkillForms();
		_DMESSAGE("Found %i Skills from Cascadia", CascadiaSkills.count);
		
	}
	
	//	Updates Perks from Cascadia Perk List
	//	In case of any newly added forms
	void UpdateLevelUpFormsFromGame()
	{
		CascadiaPerks.Clear();
	
		auto perksListCAS = DYNAMIC_CAST(GetFormFromIdentifier("FalloutCascadia.esm|21F9DFA"), TESForm, BGSListForm);
		for (int p = 0; p < perksListCAS->forms.count; p++)
		{
			BGSPerk* myPerk = DYNAMIC_CAST(perksListCAS->forms.entries[p], TESForm, BGSPerk);
			if (myPerk == nullptr)
			{
				//Item is not a perk
				continue;
			}
			CascadiaPerks.Push(myPerk);
		}
	}
	
	//	Returns the amount of Skill Points the Player should be given
	float GetSkillPointsToAdd()
	{
		//	Fallout 3 Formula is 10 + Base Intelligence
		//	Extra 3 points if Player has "Educated" Perk
		//	Using Global from FalloutCascadia.esm to check how many to use as a base
	
		TESGlobal* baseSkillPointsGlobal = reinterpret_cast<TESGlobal*>(GetFormFromIdentifier("FalloutCascadia.esm|21F9DFD"));
		float skillPointsValue = 0;
	
		if (baseSkillPointsGlobal)
		{
			skillPointsValue = baseSkillPointsGlobal->value;
		}
		else
		{
			skillPointsValue = 10;
		}
	
		float playerIntelligence = GetPlayerBaseAVValue(VanillaActorValues.Intelligence);
	
		skillPointsValue = (skillPointsValue + playerIntelligence);
	
		//	Check "Educated" Perk
		BGSPerk* educatedPerk = reinterpret_cast<BGSPerk*>(GetFormFromIdentifier("FalloutCascadia.esm|F399E"));
	
		if (educatedPerk)
		{
			if (HasPerkInternal(GetPlayer(), educatedPerk))
			{
				skillPointsValue = (skillPointsValue + 3);
			}
		}
	
		return skillPointsValue;
	}
	
	void SetSkillTagged(ActorValueInfo* mySkill, bool bTag)
	{
		UInt32 myFormID = mySkill->formID;
	
		if (bTag)
		{
			if (!CASSerialization::IsSkillTagged(myFormID))
			{
				CASSerialization::SetSkillTagged(myFormID);
				(*g_player)->actorValueOwner.Mod(1, mySkill, 15);
			}
		}
		else
		{
			if (CASSerialization::IsSkillTagged(myFormID))
			{
				CASSerialization::RemoveSkillTagged(myFormID);
				(*g_player)->actorValueOwner.Mod(1, mySkill, -15);
			}
		}
	}
	
	//	Returns true if XP meter is visible on screen
	bool IsXPMeterVisible()
	{
		bool result;
	
		IMenu* myMenu = (*g_ui)->GetMenu(BSFixedString("HUDMenu"));
		GFxMovieRoot* myMovieRoot = myMenu->movie->movieRoot;
		GFxValue openVal;
		myMovieRoot->GetVariable(&openVal, "root.HUDNotificationsGroup_mc.XPMeter_mc.visible");
	
		result = openVal.GetBool();
	
		return result;
	}
	
	//	Sends Initial data to AS3 for Level Up
	void OnLevelUpStart(GFxMovieRoot* myMovieRoot)
	{
		ProcessSkillsList(myMovieRoot);
	}
	
	//	Sends Initial data to AS3 for Tag Skills
	void OnTagSkillsStart(GFxMovieRoot* myMovieRoot)
	{
		ProcessTagSkillsList(myMovieRoot, tagPointsValue, allowRetag);
	}
	
	//	Sends Initial data to AS3 for SPECIAL Respec (leaving vault)
	void OnSpecialRespecStart(GFxMovieRoot* myMovieRoot)
	{
		ProcessSpecialList(myMovieRoot);
	}
	
	//	Sends Initial data to AS3 for Intense Training
	void OnIntenseTrainingStart(GFxMovieRoot* myMovieRoot)
	{
		ProcessSpecialList(myMovieRoot);
	}
	
	//	Called when CW Level Up Menu is opened
	void HandleLevelUpMenuOpen(GFxMovieRoot* myMovieRoot)
	{
		switch (menuModeType)
		{
		case kType_LevelUp:
			OnLevelUpStart(myMovieRoot);
			break;
		case kType_TagSkills:
			OnTagSkillsStart(myMovieRoot);
			break;
		case kType_SpecialRespec:
			OnSpecialRespecStart(myMovieRoot);
			break;
		case kType_IntenseTraining:
			OnIntenseTrainingStart(myMovieRoot);
			break;
		default:
			break;
		}
	}
	
	void InitialiseValues()
	{
		InitialValues::Barter = GetPermanentValue((*g_player), CASActorValues.Barter);
		InitialValues::EnergyWeapons = GetPermanentValue((*g_player), CASActorValues.EnergyWeapons);
		InitialValues::Explosives = GetPermanentValue((*g_player), CASActorValues.Explosives);
		InitialValues::Guns = GetPermanentValue((*g_player), CASActorValues.Guns);
		InitialValues::Lockpick = GetPermanentValue((*g_player), CASActorValues.Lockpick);
		InitialValues::Medicine = GetPermanentValue((*g_player), CASActorValues.Medicine);
		InitialValues::MeleeWeapons = GetPermanentValue((*g_player), CASActorValues.MeleeWeapons);
		InitialValues::Repair = GetPermanentValue((*g_player), CASActorValues.Repair);
		InitialValues::Science = GetPermanentValue((*g_player), CASActorValues.Science);
		InitialValues::Sneak = GetPermanentValue((*g_player), CASActorValues.Sneak);
		InitialValues::Speech = GetPermanentValue((*g_player), CASActorValues.Speech);
		InitialValues::Survival = GetPermanentValue((*g_player), CASActorValues.Survival);
		InitialValues::Unarmed = GetPermanentValue((*g_player), CASActorValues.Unarmed);
	}
	
	float GetInitialValueBySkillName(std::string skillName)
{
	std::string skillNameStr = skillName;
	skillNameStr.erase(std::remove_if(skillNameStr.begin(), skillNameStr.end(), isspace), skillNameStr.end());

	ActorValueInfo* mySkill = Skills::GetSkillByName(skillNameStr);

	if (mySkill == CASActorValues.Barter)
	{
		return InitialValues::Barter;
	}
	else if (mySkill == CASActorValues.EnergyWeapons)
	{
		return InitialValues::EnergyWeapons;
	}
	else if (mySkill == CASActorValues.Explosives)
	{
		return InitialValues::Explosives;
	}
	else if (mySkill == CASActorValues.Guns)
	{
		return InitialValues::Guns;
	}
	else if (mySkill == CASActorValues.Lockpick)
	{
		return InitialValues::Lockpick;
	}
	else if (mySkill == CASActorValues.Medicine)
	{
		return InitialValues::Medicine;
	}
	else if (mySkill == CASActorValues.MeleeWeapons)
	{
		return InitialValues::MeleeWeapons;
	}
	else if (mySkill == CASActorValues.Repair)
	{
		return InitialValues::Repair;
	}
	else if (mySkill == CASActorValues.Science)
	{
		return InitialValues::Science;
	}
	else if (mySkill == CASActorValues.Sneak)
	{
		return InitialValues::Sneak;
	}
	else if (mySkill == CASActorValues.Speech)
	{
		return InitialValues::Speech;
	}
	else if (mySkill == CASActorValues.Survival)
	{
		return InitialValues::Survival;
	}
	else if (mySkill == CASActorValues.Unarmed)
	{
		return InitialValues::Unarmed;
	}
	else
	{
		return -1;
	}
}
	
	//	Gets Skill Index based on Name
	int GetSkillArrayIndexByEditorID(const char* myEditorID)
{
	if (myEditorID == "CAS_Barter")
	{
		return CASSkillArray::Barter;
	}
	else if (myEditorID == "CAS_EnergyWeapons")
	{
		return CASSkillArray::EnergyWeapons;
	}
	else if (myEditorID == "CAS_Explosives")
	{
		return CASSkillArray::Explosives;
	}
	else if (myEditorID == "CAS_Guns")
	{
		return CASSkillArray::Guns;
	}
	else if (myEditorID == "CAS_Lockpick")
	{
		return CASSkillArray::Lockpick;
	}
	else if (myEditorID == "CAS_Medicine")
	{
		return CASSkillArray::Medicine;
	}
	else if (myEditorID == "CAS_MeleeWeapons")
	{
		return CASSkillArray::MeleeWeapons;
	}
	else if (myEditorID == "CAS_Repair")
	{
		return CASSkillArray::Repair;
	}
	else if (myEditorID == "CAS_Science")
	{
		return CASSkillArray::Science;
	}
	else if (myEditorID == "CAS_Sneak")
	{
		return CASSkillArray::Sneak;
	}
	else if (myEditorID == "CAS_Speech")
	{
		return CASSkillArray::Speech;
	}
	else if (myEditorID == "CAS_Survival")
	{
		return CASSkillArray::Survival;
	}
	else if (myEditorID == "CAS_Unarmed")
	{
		return CASSkillArray::Unarmed;
	}
	else
	{
		return -1;
	}
}
	
	//	Populates Skill Entry
	void PopulateSkillEntry(GFxValue* myDestination, GFxMovieRoot* myMovieRoot, ActorValueInfo* mySkill)
	{
		GFxValue skillEntry;
		myMovieRoot->CreateObject(&skillEntry);
	
		GFxUtilities::RegisterString(&skillEntry, myMovieRoot, "text", mySkill->fullName.name);
		GFxUtilities::RegisterString(&skillEntry, myMovieRoot, "editorID", mySkill->GetEditorID());
		GFxUtilities::RegisterString(&skillEntry, myMovieRoot, "description", GetDescription(mySkill).c_str());
		GFxUtilities::RegisterInt(&skillEntry, "formid", mySkill->formID);
		
		float myBaseValue = GetInitialValueBySkillName(mySkill->fullName.name.c_str());
		float myValue = GetPermanentValue((*g_player), mySkill);
	
		GFxUtilities::RegisterInt(&skillEntry, "value", (int)myBaseValue);
		GFxUtilities::RegisterInt(&skillEntry, "baseValue", (int)myBaseValue);
		GFxUtilities::RegisterInt(&skillEntry, "buffedValue", (int)myValue);
	
		GFxUtilities::RegisterBool(&skillEntry, "alreadyTagged", CASSerialization::IsSkillTagged(mySkill->formID));
		GFxUtilities::RegisterBool(&skillEntry, "tagged", CASSerialization::IsSkillTagged(mySkill->formID));
		myDestination->PushBack(&skillEntry);
	}
	
	bool ProcessSkillsList(GFxMovieRoot* myMovieRoot)
	{
		GFxValue arrArgs[3];
		myMovieRoot->CreateArray(&arrArgs[0]);
	
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Barter);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.EnergyWeapons);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Explosives);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Guns);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Lockpick);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Medicine);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.MeleeWeapons);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Repair);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Science);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Sneak);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Speech);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Survival);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Unarmed);
	
		std::string trace = "Sending ";
		trace.append(std::to_string(arrArgs[0].GetArraySize()));
		trace.append(" skills to Skill Menu.");
		TraceLog(trace);
	
		arrArgs[1].SetInt((int)CASSerialization::GetSkillPoints());
		arrArgs[2].SetInt((int)playerLevel);
		TraceLog("LevelUpMenu: Skills Ready, Sending to AS3");
	
		myMovieRoot->Invoke("root.Menu_mc.onLevelUpStart", nullptr, arrArgs, 3);
	
		return true;
	}

	bool ProcessTagSkillsList(GFxMovieRoot* myMovieRoot, int tagSkills, bool bRetag)
	{
		GFxValue arrArgs[3];
		myMovieRoot->CreateArray(&arrArgs[0]);

		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Barter);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.EnergyWeapons);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Explosives);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Guns);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Lockpick);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Medicine);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.MeleeWeapons);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Repair);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Science);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Sneak);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Speech);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Survival);
		PopulateSkillEntry(&arrArgs[0], myMovieRoot, CASActorValues.Unarmed);

		std::string trace = "Sending ";
		trace.append(std::to_string(arrArgs[0].GetArraySize()));
		trace.append(" skills to Tag Skill Menu.");
		TraceLog(trace);

		arrArgs[1].SetInt(tagSkills);
		arrArgs[2].SetBool(bRetag);
		TraceLog("LevelUpMenu: Tag Skills Ready, Sending to AS3");

		myMovieRoot->Invoke("root.Menu_mc.onTagSkillsStart", nullptr, arrArgs, 3);

		return true;
	}

	void PopulateSpecialEntry(GFxValue* myDestination, GFxMovieRoot* myMovieRoot, ActorValueInfo* mySkill)
	{
		GFxValue skillEntry;
		myMovieRoot->CreateObject(&skillEntry);

		GFxUtilities::RegisterString(&skillEntry, myMovieRoot, "text", mySkill->fullName.name);
		GFxUtilities::RegisterString(&skillEntry, myMovieRoot, "editorID", mySkill->GetEditorID());
		GFxUtilities::RegisterString(&skillEntry, myMovieRoot, "description", GetDescription(mySkill).c_str());
		GFxUtilities::RegisterInt(&skillEntry, "formid", mySkill->formID);

		float myBaseValue = GetBaseAVValue((*g_player), mySkill);
		float myValue = GetAVValue((*g_player), mySkill);

		GFxUtilities::RegisterInt(&skillEntry, "value", (int)myBaseValue);
		GFxUtilities::RegisterInt(&skillEntry, "baseValue", (int)myBaseValue);
		GFxUtilities::RegisterInt(&skillEntry, "buffedValue", (int)myValue);

		myDestination->PushBack(&skillEntry);
	}

	bool ProcessSpecialList(GFxMovieRoot* myMovieRoot)
	{
		GFxValue arrArgs[1];
		myMovieRoot->CreateArray(&arrArgs[0]);

		PopulateSpecialEntry(&arrArgs[0], myMovieRoot, VanillaActorValues.Strength);
		PopulateSpecialEntry(&arrArgs[0], myMovieRoot, VanillaActorValues.Perception);
		PopulateSpecialEntry(&arrArgs[0], myMovieRoot, VanillaActorValues.Endurance);
		PopulateSpecialEntry(&arrArgs[0], myMovieRoot, VanillaActorValues.Charisma);
		PopulateSpecialEntry(&arrArgs[0], myMovieRoot, VanillaActorValues.Intelligence);
		PopulateSpecialEntry(&arrArgs[0], myMovieRoot, VanillaActorValues.Agility);
		PopulateSpecialEntry(&arrArgs[0], myMovieRoot, VanillaActorValues.Luck);

		std::string trace = "Sending ";
		trace.append(std::to_string(arrArgs[0].GetArraySize()));
		trace.append(" Special Stats to Special Menu.");
		TraceLog(trace);

		TraceLog("LevelUpMenu: Special Stats Ready, Sending to AS3");

		switch (menuModeType)
		{
		case kType_SpecialRespec:
			myMovieRoot->Invoke("root.Menu_mc.onSpecialRespecStart", nullptr, arrArgs, 1);
			break;
		case kType_IntenseTraining:
			myMovieRoot->Invoke("root.Menu_mc.onIntenseTrainingStart", nullptr, arrArgs, 1);
			break;
		default:
			break;
		}

		return true;
	}
	
	//	Input Handling Start
	//	================================================================================
	
	class F4SEInputHandler : public BSInputEventUser
	{
	public:
		F4SEInputHandler()	:	BSInputEventUser(true){ }
	
		virtual void OnButtonEvent(ButtonEvent* inputEvent)
		{
			UInt32	keyCode;
			UInt32	deviceType = inputEvent->deviceType;
			UInt32	keyMask = inputEvent->keyMask;
	
			if (deviceType == InputEvent::kDeviceType_Mouse)
			{
				keyCode = InputMap::kMacro_MouseButtonOffset + keyMask;
			}
			else if (deviceType == InputEvent::kDeviceType_Gamepad)
			{
				keyCode = InputMap::GamepadMaskToKeycode(keyMask);
			}
			else
			{
				keyCode = keyMask;
			}
	
			float timer = inputEvent->timer;
			bool isDown = inputEvent->isDown == 1.0f && timer == 0.0f;
			bool isUp = inputEvent->isDown == 0.0f && timer != 0.0f;
	
			BSFixedString* control = inputEvent->GetControlID();
	
			if (isDown)
			{
				ProcessUserEvent(control->c_str(), true, deviceType, keyCode);
			}
			else if (isUp)
			{
				ProcessUserEvent(control->c_str(), false, deviceType, keyCode);
			}
	
		}
	};
	
	F4SEInputHandler g_levelUpMenuInputHandler;
	
	void ProcessUserEvent(const char* controlName, bool isDown, int deviceType, UInt32 keyCode)
	{
		BSFixedString levelUpMenuStr("CASLevelUpMenu");
		if ((*g_ui)->IsMenuOpen("CASLevelUpMenu"))
		{
			IMenu* menu = (*g_ui)->GetMenu(levelUpMenuStr);
			GFxMovieRoot* movieRoot = menu->movie->movieRoot;
			GFxValue args[4];
			args[0].SetString(controlName);
			args[1].SetBool(isDown);
			args[2].SetInt(deviceType);
			args[3].SetInt(keyCode);
	
			movieRoot->Invoke("root.Menu_mc.ProcessUserEventExternal", nullptr, args, 4);
		}
	}
	
	void RegisterForInput(bool bRegister)
	{
		if (bRegister)
		{
			g_levelUpMenuInputHandler.enabled = true;
			tArray<BSInputEventUser*>* inputEvents = &((*g_menuControls)->inputEvents);
			BSInputEventUser* inputHandler = &g_levelUpMenuInputHandler;
			int idx = inputEvents->GetItemIndex(inputHandler);
			if (idx == -1)
			{
				inputEvents->Push(&g_levelUpMenuInputHandler);
			}
		}
		else
		{
			g_levelUpMenuInputHandler.enabled = false;
		}
	}
	
	//	Input Handling End
	//	================================================================================
	
	//	Used when Player loads game in case they save in the middle of a level up
	void CheckForLevelUp()
	{
		if (CASSerialization::IsReadyToLevelUp())
		{
			if (bForceLevelUp)
			{
				std::thread LevelUpWait(WaitForLevelUpReady);
				LevelUpWait.detach();
			}
		}
	}
	
	//	Checks if the Level Up Menu can be shown
	bool CanLevelUpMenuBeShown()
	{
		//	Combat Check
		if ((*g_player)->IsInCombat())
		{
			return false;
		}
	
		//	Menu Mode Check
		if (IsInMenuMode())
		{
			return false;
		}
	
		//	Dialogue Scene Check
		if (IsPlayerInScene())
		{
			return false;
		}
	
		//	Level Up Text Visible
		if (IsXPMeterVisible())
		{
			return false;
		}
	
		return true;
	}
	
	// Waits for Level Up to be ready and then shows menu
	void WaitForLevelUpReady()
	{
		std::this_thread::sleep_for(std::chrono::milliseconds(500));
	
		//	Check if menu should be opened
		if (!CanLevelUpMenuBeShown())
		{
			std::this_thread::sleep_for(std::chrono::seconds(1));
			std::async(std::launch::async, WaitForLevelUpReady);
			return;
		}
		else
		{
			Scaleform::OpenMenu_Internal("LevelUpMenu");
		}
	}
	
	//	Gets Called when Player Levels Up
	void HandleLevelUp(LevelIncrease::Event* myEvent)
	{
		float pointsToAdd = GetSkillPointsToAdd();
	
		CASSerialization::ModSkillPoints(pointsToAdd);
	
		UpdateLevelUpFormsFromGame();
	
		CASSerialization::SetReadyToLevelUp(true);
	
		//Trace Level Up
		std::string myTraceMessage = "Level Up Handler: Player has Levelled up. Adding ";
		myTraceMessage.append(std::to_string((int)pointsToAdd));
		myTraceMessage.append(" skill points.");
		TraceLog(myTraceMessage);

		if (bForceLevelUp)
		{
			std::thread LevelUpWait(WaitForLevelUpReady);
			LevelUpWait.detach();
		}
	}
	
	//	Retuns the amount of Perk Points the Player has
	UInt8 GetPerkPoints()
	{
		UInt8 perkPoints = GetOffset<UInt8>(*g_player, 0xCF1);
		return perkPoints;
	}
	
	//	Modifies the amount of Perk Points the Player has
	void ModPerkPoints(SInt8 count)
	{
		UInt8 result = GetPerkPoints();
		if (count < -result)
		{
			result = 0;
		}
		else
		{
			result = result + count;
			if (result > 255)
			{
				result = 255;
			}
		}
		SetPerkPoints(*g_player, result);
	}
	
	//	Gets Available Perk
	AvailablePerk GetAvailablePerk(BGSPerk* myPerk)
	{
		AvailablePerk result;
	
		result.Level = 0;
		result.Perk = nullptr;
		result.ranksInfo = BSFixedString("");
		result.NumRanks = myPerk->numRanks;
		std::string tempRanksInfo = "";
		BGSPerk* tempPerk;
	
		bool bGotResult = false;
		bool bLearned = false;
		tempPerk = myPerk;
		if (myPerk->numRanks > 1 && (myPerk->nextPerk == myPerk || myPerk->nextPerk == nullptr))
		{
			int iHasRank = HasPerk(GetPlayer(), tempPerk);
			if (iHasRank < myPerk->numRanks)
			{
				result.Level = iHasRank + 1;
				result.Perk = myPerk;
				return result;
			}
			else
			{
				return result;
			}
		}
		else
		{
			int counter = 0;
			while (true)
			{
				tempPerk = tempPerk->nextPerk;
				counter++;
				if (tempPerk == myPerk || tempPerk == nullptr)
				{
					break;
				}
			}
			if (counter != myPerk->numRanks)
			{
				result.NumRanks = counter;
			}
		}
		tempPerk = myPerk;
	
		for (int i = 0; i < result.NumRanks; i++)
		{
			if (!HasPerk(*g_player, tempPerk))
			{
				if (!bGotResult)
				{
					bGotResult = true;
					result.Perk = tempPerk;
					result.Level = i + 1;
				}
			}
			else
			{
				if (!bLearned)
				{
					bLearned = true;
				}
			}
			tempPerk = tempPerk->nextPerk;
		}
		result.ranksInfo = BSFixedString(tempRanksInfo.c_str());
		return result;
	}
	
	//	Gets Perk Requirements
	perkData GetPerkRequirements(BGSPerk* myPerk)
	{
		perkData result;
		PlayerCharacter* player = (*g_player);
		bool bIsAllowable = true;
		bool bIsHighLevel = myPerk->perkLevel > playerLevel;
		bool bIsEligible = !bIsHighLevel;
		int filterFlag = 0;
		result.reqlevel = myPerk->perkLevel;
		std::string str = "";
		Condition* tempCondition = myPerk->condition;
		bool lastFlag = false;
		while (tempCondition)
		{
			UInt32 functionID = tempCondition->functionId;
			float compareValue = tempCondition->compareValue;
			TESForm* form = tempCondition->param1.form;
			UInt32 u321 = tempCondition->param1.u32;
			UInt8 op = tempCondition->comparisonType.op;
			UInt8 flag = tempCondition->comparisonType.flags;
			ActorValueInfo* tempAV;
			bool bIsElig = true;
			switch (functionID)
			{
			case kFunction_GetPermanentValue:
			case kFunction_GetBaseValue:
			case kFunction_GetValue:
				tempAV = DYNAMIC_CAST(form, TESForm, ActorValueInfo);
	
				switch (op)
				{
				case kCompareOp_Equal:
					bIsElig = GetPermanentValue((*g_player), tempAV) == compareValue;
					break;
				case kCompareOp_NotEqual:
					bIsElig = GetPermanentValue((*g_player), tempAV) != compareValue;
					break;
				case kCompareOp_Greater:
					bIsElig = GetPermanentValue((*g_player), tempAV) > compareValue;
					break;
				case kCompareOp_GreaterEqual:
					bIsElig = GetPermanentValue((*g_player), tempAV) >= compareValue;
					break;
				case kCompareOp_Less:
					bIsElig = GetPermanentValue((*g_player), tempAV) < compareValue;
					break;
				case kCompareOp_LessEqual:
					bIsElig = GetPermanentValue((*g_player), tempAV) <= compareValue;
					break;
				default:
					break;
				}
	
				filterFlag |= filterFlag_NonSpecial;
	
				if (!bIsElig)
					str += "<font color=\'#838383\'>";
	
				switch (tempAV->formID)
				{
				case StrengthID:
					str += "$F4CW_STR";
					break;
				case PerceptionID:
					str += "$F4CW_PER";
					break;
				case EnduranceID:
					str += "$F4CW_END";
					break;
				case CharismaID:
					str += "$F4CW_CHA";
					break;
				case IntelligenceID:
					str += "$F4CW_INT";
					break;
				case AgilityID:
					str += "$F4CW_AGI";
					break;
				case LuckID:
					str += "$F4CW_LCK";
					break;
				default:
					if (tempAV->fullName.name == BSFixedString(""))
					{
						str += tempAV->avName;
					}
					else
					{
						str += GetName(tempAV).c_str();
					}
					break;
				}
	
				str += " " + std::to_string((int)compareValue);
				if (!bIsElig)
					str += "</font>";
				break;
			case kFunction_GetIsSex:
				bIsAllowable = bIsAllowable && (playerSex != (u321 ^ (int)compareValue ^ (op != kCompareOp_Equal)));
				break;
			case kFunction_HasPerk:
				break;
			default:
				break;
			}
	
			lastFlag = ((flag & 1) == 0);
			tempCondition = tempCondition->next;
			if (tempCondition)
			{
				if (functionID == kFunction_GetIsSex)
				{
					str += "";
				}
				else if (lastFlag)
				{
					str += ", ";
				}
				else
				{
					str += " $F4CW_or ";
				}
			}
	
		}
		result.isEligible = bIsEligible && EvaluationConditions((&myPerk->condition), player, player);
		result.isAllowable = bIsAllowable;
		result.isHighLevel = bIsHighLevel;
		if (filterFlag == 0) filterFlag |= filterFlag_Other;
		result.filterFlag = filterFlag | (result.isEligible ? 1 : 2);
		result.reqs = str;
		result.SWFPath = myPerk->swfPath;
		result.isTagged = false;
	
		return result;
	}
	
	//	Populates Perk Entry on Menu
	void PopulatePerkEntry(GFxValue* myDestination, GFxMovieRoot* myMovieRoot, BGSPerk* myPerk, bool bOnlyEligible)
	{
		AvailablePerk currentPerk = GetAvailablePerk(myPerk);
	
		if (currentPerk.Perk != nullptr)
		{
			perkData tempPerkData = GetPerkRequirements(currentPerk.Perk);
			GFxValue arrArg;
			myMovieRoot->CreateObject(&arrArg);
	
			GFxUtilities::RegisterString(&arrArg, myMovieRoot, "text", currentPerk.Perk->fullName.name);
			GFxUtilities::RegisterString(&arrArg, myMovieRoot, "reqs", tempPerkData.reqs.c_str());
			GFxUtilities::RegisterInt(&arrArg, "filterFlag", tempPerkData.filterFlag);
			GFxUtilities::RegisterBool(&arrArg, "iselig", tempPerkData.isEligible);
			GFxUtilities::RegisterBool(&arrArg, "isHighLevel", tempPerkData.isHighLevel);
			GFxUtilities::RegisterInt(&arrArg, "reqLevel", tempPerkData.reqlevel);
			GFxUtilities::RegisterInt(&arrArg, "qname", myPerk->formID);
			GFxUtilities::RegisterInt(&arrArg, "formid", currentPerk.Perk->formID);
			GFxUtilities::RegisterInt(&arrArg, "level", currentPerk.Level);
			GFxUtilities::RegisterString(&arrArg, myMovieRoot, "SWFPath", tempPerkData.SWFPath.c_str());
			GFxUtilities::RegisterInt(&arrArg, "numranks", currentPerk.NumRanks);
			GFxUtilities::RegisterInt(&arrArg, "type", Type_Default);
			GFxUtilities::RegisterString(&arrArg, myMovieRoot, "ranksinfo", currentPerk.ranksInfo);
			GFxUtilities::RegisterString(&arrArg, myMovieRoot, "description", GetDescription(currentPerk.Perk).c_str());
			GFxUtilities::RegisterBool(&arrArg, "isTagged", tempPerkData.isTagged);
	
			if (bOnlyEligible)
			{
				if (tempPerkData.isEligible && tempPerkData.isAllowable)
				{
					myDestination->PushBack(&arrArg);
				}
			}
			else
			{
				if (!tempPerkData.isEligible && tempPerkData.isAllowable)
				{
					myDestination->PushBack(&arrArg);
				}
			}
		}
	}
	
	//	Processes Perks for use in Level Up Menu Perk List
	bool ProcessPerkList(GFxMovieRoot* myMovieRoot)
	{
		GFxValue arrArgs[3];
		myMovieRoot->CreateArray(&arrArgs[0]);
	
		std::string trace = "Checking ";
		trace.append(std::to_string(CascadiaPerks.count));
		trace.append(" perks from Cascadia Perk List.");
		TraceLog(trace);
	
		//	Eligible Perks first
		for (int p1 = 0; p1 < CascadiaPerks.count; p1++)
		{
			BGSPerk* myPerk = CascadiaPerks.entries[p1];
			PopulatePerkEntry(&arrArgs[0], myMovieRoot, myPerk, true);
		}
	
		//	Ineligible Perks next
		for (int p2 = 0; p2 < CascadiaPerks.count; p2++)
		{
			BGSPerk* myPerk = CascadiaPerks.entries[p2];
			PopulatePerkEntry(&arrArgs[0], myMovieRoot, myPerk, false);
		}
		
		std::string trace2 = "Sending ";
		trace2.append(std::to_string(arrArgs[0].GetArraySize()));
		trace2.append(" perks to Perk Menu.");
		TraceLog(trace2);
	
		arrArgs[1].SetInt((int)GetPerkPoints());
		TraceLog("LevelUpMenu: Perks Ready, Sending to AS3");
	
		myMovieRoot->Invoke("root.Menu_mc.onSwitchToPerks", nullptr, arrArgs, 2);
	
		return true;
	}
	
	//	Gets all Level Up Menu related data and stores it for later use
	void GetLevelUpMenuData()
	{
		PlayerCharacter* player = (*g_player);
		playerLevel = GetLevel(player);
		playerSex = GetActorSex(player);
	}
	
	void CompleteLevelUp()
	{
		switch (menuModeType)
		{
		case kType_LevelUp:
			CASSerialization::SetReadyToLevelUp(false);
			CASSerialization::SetSkillPoints(0);
			TraceLog("LevelUpMenu: Level Up Complete!");
			break;
		case kType_TagSkills:
			tagPointsValue = 0;
			allowRetag = false;
			TraceLog("LevelUpMenu: Tag Skills Complete!");
			break;
		case kType_SpecialRespec:
			TraceLog("LevelUpMenu: Special Respec Complete!");
			break;
		case kType_IntenseTraining:
			TraceLog("LevelUpMenu: Intense Training Complete!");
			break;
		default:
			break;
		}

		menuModeType = 0;
	}
	
	void HandleVanillaMenuOpen()
	{
		bool bShouldClose = !CASSerialization::IsReadyToLevelUp();
	
		Scaleform::CloseMenu_Internal("LevelUpMenu");
		Scaleform::CloseMenu_Internal("PipboyMenu");
	
		if (bShouldClose == true)
		{
			ShowNotification("You do not have any Level Ups available.");
		}
		else
		{
			menuModeType = kType_LevelUp;
			Scaleform::OpenMenu_Internal("CASLevelUpMenu");
		}
	}
	
	//	Used when Setting Skills
	void ModSkillByName(std::string skillName, int value, int baseValue)
	{
		std::string skillNameStr = skillName;
		skillNameStr.erase(std::remove_if(skillNameStr.begin(), skillNameStr.end(), isspace), skillNameStr.end());
	
		ActorValueInfo* mySkill = Skills::GetSkillByName(skillNameStr);
	
		std::string myEditorID = mySkill->GetEditorID();
	
		int modValue = (value - baseValue);
	
		if (myEditorID == "CAS_Barter")
		{
			TempModValues::Barter = modValue;
		}
		else if (myEditorID == "CAS_EnergyWeapons")
		{
			TempModValues::EnergyWeapons = modValue;
		}
		else if (myEditorID == "CAS_Explosives")
		{
			TempModValues::Explosives = modValue;
		}
		else if (myEditorID == "CAS_Guns")
		{
			TempModValues::Guns = modValue;
		}
		else if (myEditorID == "CAS_Lockpick")
		{
			TempModValues::Lockpick = modValue;
		}
		else if (myEditorID == "CAS_Medicine")
		{
			TempModValues::Medicine = modValue;
		}
		else if (myEditorID == "CAS_MeleeWeapons")
		{
			TempModValues::MeleeWeapons = modValue;
		}
		else if (myEditorID == "CAS_Repair")
		{
			TempModValues::Repair = modValue;
		}
		else if (myEditorID == "CAS_Science")
		{
			TempModValues::Science = modValue;
		}
		else if (myEditorID == "CAS_Sneak")
		{
			TempModValues::Sneak = modValue;
		}
		else if (myEditorID == "CAS_Speech")
		{
			TempModValues::Speech = modValue;
		}
		else if (myEditorID == "CAS_Survival")
		{
			TempModValues::Survival = modValue;
		}
		else if (myEditorID == "CAS_Unarmed")
		{
			TempModValues::Unarmed = modValue;
		}
	
		(*g_player)->actorValueOwner.Mod(1, mySkill, modValue);
	}
	
	//	Used when Reverting Skills
	void RevertSkill(ActorValueInfo* mySkill)
	{
		std::string myEditorID = mySkill->GetEditorID();
	
		int modValue;
	
		if (myEditorID == "CAS_Barter")
		{
			modValue = TempModValues::Barter;
			TempModValues::Barter = 0;
		}
		else if (myEditorID == "CAS_EnergyWeapons")
		{
			modValue = TempModValues::EnergyWeapons;
			TempModValues::EnergyWeapons = 0;
		}
		else if (myEditorID == "CAS_Explosives")
		{
			modValue = TempModValues::Explosives;
			TempModValues::Explosives = 0;
		}
		else if (myEditorID == "CAS_Guns")
		{
			modValue = TempModValues::Guns;
			TempModValues::Guns = 0;
		}
		else if (myEditorID == "CAS_Lockpick")
		{
			modValue = TempModValues::Lockpick;
			TempModValues::Lockpick = 0;
		}
		else if (myEditorID == "CAS_Medicine")
		{
			modValue = TempModValues::Medicine;
			TempModValues::Medicine = 0;
		}
		else if (myEditorID == "CAS_MeleeWeapons")
		{
			modValue = TempModValues::MeleeWeapons;
			TempModValues::MeleeWeapons = 0;
		}
		else if (myEditorID == "CAS_Repair")
		{
			modValue = TempModValues::Repair;
			TempModValues::Repair = 0;
		}
		else if (myEditorID == "CAS_Science")
		{
			modValue = TempModValues::Science;
			TempModValues::Science = 0;
		}
		else if (myEditorID == "CAS_Sneak")
		{
			modValue = TempModValues::Sneak;
			TempModValues::Sneak = 0;
		}
		else if (myEditorID == "CAS_Speech")
		{
			modValue = TempModValues::Speech;
			TempModValues::Speech = 0;
		}
		else if (myEditorID == "CAS_Survival")
		{
			modValue = TempModValues::Survival;
			TempModValues::Survival = 0;
		}
		else if (myEditorID == "CAS_Unarmed")
		{
			modValue = TempModValues::Unarmed;
			TempModValues::Unarmed = 0;
		}
	
		(*g_player)->actorValueOwner.Mod(1, mySkill, -modValue);
	}
	
	
	//	Used for Setting Skills Tagged
	void SetCWSkillTaggedByName(std::string skillName, bool bTagged)
	{
		SetSkillTagged(Skills::GetSkillByName(skillName), bTagged);
	}
	
	// VM Functions
	//=========================================================================================================================
	bool RegisterFunctions(VirtualMachine* vm)
	{
		vm->RegisterFunction(new NativeFunction0<StaticFunctionTag, void>("OpenLevelUpMenu", "FOC:Cascadia", LevelUpMenu_Papyrus::OpenLevelUpMenu_Papyrus, vm));
		vm->RegisterFunction(new NativeFunction2<StaticFunctionTag, void, UInt32, bool>("OpenTagSkillsMenu", "FOC:Cascadia", LevelUpMenu_Papyrus::OpenTagSkillsMenu_Papyrus, vm));
		vm->RegisterFunction(new NativeFunction0<StaticFunctionTag, void>("OpenSpecialRespecMenu", "FOC:Cascadia", LevelUpMenu_Papyrus::OpenSpecialRespecMenu_Papyrus, vm));
		vm->RegisterFunction(new NativeFunction0<StaticFunctionTag, void>("OpenIntenseTrainingMenu", "FOC:Cascadia", LevelUpMenu_Papyrus::OpenIntenseTrainingMenu_Papyrus, vm));

		vm->RegisterFunction(new NativeFunction1<StaticFunctionTag, bool, ActorValueInfo*>("GetSkillTagged", "FOC:Cascadia", LevelUpMenu_Papyrus::GetSkillTagged_Papyrus, vm));
		vm->RegisterFunction(new NativeFunction2<StaticFunctionTag, void, ActorValueInfo*, bool>("SetSkillTagged", "FOC:Cascadia", LevelUpMenu_Papyrus::SetSkillTagged_Papyrus, vm));
		return true;
	}
	
	void InitAddresses()
	{
		SetPerkPoints = RVA <_SetPerkPoints_int>(
			"SetPerkPoints_int", {
				{ RUNTIME_VERSION_1_10_163, 0x00EB8BA0 },
				{ RUNTIME_VERSION_1_10_130, 0x00EB8A80 },
				{ RUNTIME_VERSION_1_10_120, 0x00EB8A80 },
				{ RUNTIME_VERSION_1_10_114, 0x00EB8A80 },
				{ RUNTIME_VERSION_1_10_111, 0x00EB8A80 },
				{ RUNTIME_VERSION_1_10_106, 0x00EB8A80 },
				{ RUNTIME_VERSION_1_10_98, 0x00EB8A80 },
				{ RUNTIME_VERSION_1_10_89, 0x00EB8A40 },
				{ RUNTIME_VERSION_1_10_82, 0x00EB89E0 },
				{ RUNTIME_VERSION_1_10_75, 0x00EB89E0 },
				{ RUNTIME_VERSION_1_10_64, 0x00EB8A20 },
				{ RUNTIME_VERSION_1_10_50, 0x0EB8600 },
			}, "48 83 EC 28 88 91 F1 0C 00 00");
	}
}

namespace LevelUpMenu_Papyrus
{
	void OpenLevelUpMenu_Papyrus(StaticFunctionTag*)
	{
		menuModeType = kType_LevelUp;
		Scaleform::OpenMenu_Internal("CASLevelUpMenu");
	}

	void OpenTagSkillsMenu_Papyrus(StaticFunctionTag*, UInt32 tagPoints, bool reTag)
	{
		menuModeType = kType_TagSkills;
		tagPointsValue = tagPoints;
		allowRetag = reTag;
		Scaleform::OpenMenu_Internal("CASLevelUpMenu");
	}

	void OpenSpecialRespecMenu_Papyrus(StaticFunctionTag*)
	{
		menuModeType = kType_SpecialRespec;
		Scaleform::OpenMenu_Internal("CASLevelUpMenu");
	}

	void OpenIntenseTrainingMenu_Papyrus(StaticFunctionTag*)
	{
		menuModeType = kType_IntenseTraining;
		Scaleform::OpenMenu_Internal("CASLevelUpMenu");
	}

	bool GetSkillTagged_Papyrus(StaticFunctionTag*, ActorValueInfo* mySkill)
	{
		return CASSerialization::IsSkillTagged(mySkill->formID);
	}

	void SetSkillTagged_Papyrus(StaticFunctionTag*, ActorValueInfo* mySkill, bool bTag)
	{
		LevelUpMenu::SetSkillTagged(mySkill, bTag);
	}
}

