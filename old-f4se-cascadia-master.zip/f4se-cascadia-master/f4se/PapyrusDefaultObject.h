#pragma once

#include "f4se/GameTypes.h"

class VirtualMachine;

namespace papyrusDefaultObject
{
	void RegisterFuncs(VirtualMachine* vm);
};
