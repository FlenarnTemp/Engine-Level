#pragma once

void Hooks_Memory_Init();
void Hooks_Memory_Commit();

void PrintHeapStatus();
