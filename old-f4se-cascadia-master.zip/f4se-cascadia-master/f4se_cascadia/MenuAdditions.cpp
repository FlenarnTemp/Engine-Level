#include "MenuAdditions.h"

bool bHideWorkshopTab = false;

namespace HUD
{
	void UpdateMenus(GFxMovieRoot* myMovieRoot)
	{
		//TraceLog("HUDMenu Additions Loaded.");
	}
}

namespace Pipboy
{
	void GetINIOptions()
	{
		std::string myINI = "./Data/FalloutCascadia.ini";
		bool workshopTab;
		workshopTab = GetPrivateProfileInt("Pipboy", "bHideWorkshopTab", 0, myINI.c_str());

		bHideWorkshopTab = workshopTab;
	}

	// Update given section of the Pipboy Inventory Page Item Cards
	void UpdateItemCardsOnSection(UInt32 section) 
	{

		switch (section)
		{

		case kPage_Weapons:
			RepopulateItemCardsOnSection(FormType::kFormType_WEAP);
			break;

		case kPage_Apparel:
			RepopulateItemCardsOnSection(FormType::kFormType_ARMO);
			break;

		case kPage_Aid:
			RepopulateItemCardsOnSection(FormType::kFormType_ALCH);
			RepopulateItemCardsOnSection(FormType::kFormType_INGR);
			break;
		
		case kPage_Ammo:
			RepopulateItemCardsOnSection(FormType::kFormType_AMMO);
			break;
	
		default:
			break;
		}
	}

	//	Returns true if we should hide the workshop tab in the Pipboy
	bool CheckWorkshopTab()
	{
		return bHideWorkshopTab;
	}

	void PopulateSkillEntry(GFxValue* myDestination, GFxMovieRoot* myMovieRoot, ActorValueInfo* mySkill, int filter, std::vector<std::string> stringValue)
	{
		GFxValue arrArg;
		myMovieRoot->CreateObject(&arrArg);
		float value = GetPermanentValue((*g_player), mySkill);
		float buffedValue = GetPlayerAVValue(mySkill);
		GFxUtilities::RegisterString(&arrArg, myMovieRoot, "text", mySkill->fullName.name);
		GFxUtilities::RegisterString(&arrArg, myMovieRoot, "editorid", mySkill->GetEditorID());
		GFxUtilities::RegisterString(&arrArg, myMovieRoot, "description", GetDescription(mySkill).c_str());
		if (stringValue.size() > (int)value)
		{
			GFxUtilities::RegisterString(&arrArg, myMovieRoot, "stringValue", stringValue[(int)value].c_str());
		}
		else
		{
			GFxUtilities::RegisterString(&arrArg, myMovieRoot, "stringValue", "");
		}
		GFxUtilities::RegisterInt(&arrArg, "formid", mySkill->formID);
		GFxUtilities::RegisterNumber(&arrArg, "value", buffedValue);
		GFxUtilities::RegisterNumber(&arrArg, "maxVal", 0.0);
		GFxUtilities::RegisterNumber(&arrArg, "baseValue", value);
		GFxUtilities::RegisterNumber(&arrArg, "modifier", buffedValue - value);
		GFxUtilities::RegisterNumber(&arrArg, "buffedValue", buffedValue);
		GFxUtilities::RegisterInt(&arrArg, "filterFlag", filter);

		myDestination->PushBack(&arrArg);
	}

	void UpdateMenus(GFxMovieRoot* myMovieRoot)
	{
		//	Skills
		GFxValue arrSkills[7];
		myMovieRoot->CreateString(&arrSkills[0], "skills");
		myMovieRoot->CreateString(&arrSkills[1], "$F4CW_SKILLS");

		arrSkills[2].SetInt(0);
		arrSkills[3].SetInt(PipboyPage_Skills);

		myMovieRoot->CreateObject(&arrSkills[4]);
		GFxValue skillsArray;
		myMovieRoot->CreateArray(&skillsArray);
		std::vector<std::string> strArray;

		PopulateSkillEntry(&skillsArray, myMovieRoot, CASActorValues.Barter, 1, strArray);
		PopulateSkillEntry(&skillsArray, myMovieRoot, CASActorValues.EnergyWeapons, 1, strArray);
		PopulateSkillEntry(&skillsArray, myMovieRoot, CASActorValues.Explosives, 1, strArray);
		PopulateSkillEntry(&skillsArray, myMovieRoot, CASActorValues.Guns, 1, strArray);
		PopulateSkillEntry(&skillsArray, myMovieRoot, CASActorValues.Lockpick, 1, strArray);
		PopulateSkillEntry(&skillsArray, myMovieRoot, CASActorValues.Medicine, 1, strArray);
		PopulateSkillEntry(&skillsArray, myMovieRoot, CASActorValues.MeleeWeapons, 1, strArray);
		PopulateSkillEntry(&skillsArray, myMovieRoot, CASActorValues.Repair, 1, strArray);
		PopulateSkillEntry(&skillsArray, myMovieRoot, CASActorValues.Science, 1, strArray);
		PopulateSkillEntry(&skillsArray, myMovieRoot, CASActorValues.Sneak, 1, strArray);
		PopulateSkillEntry(&skillsArray, myMovieRoot, CASActorValues.Speech, 1, strArray);
		PopulateSkillEntry(&skillsArray, myMovieRoot, CASActorValues.Survival, 1, strArray);
		PopulateSkillEntry(&skillsArray, myMovieRoot, CASActorValues.Unarmed, 1, strArray);

		arrSkills[4].SetMember("arrayList", &skillsArray);
		arrSkills[5].SetInt(0);
		arrSkills[6].SetInt(0);

		myMovieRoot->Invoke("root.casPipboy_loader.content.registerTab", nullptr, arrSkills, 7);

	}
}

namespace Examine {

	void ProcessUserEvent(const char* controlName, bool isDown, int deviceType, UInt32 keyCode)
	{
		BSFixedString examineMenuStr("ExamineMenu");
		if ((*g_ui)->IsMenuOpen("ExamineMenu"))
		{
			IMenu* menu = (*g_ui)->GetMenu(examineMenuStr);
			GFxMovieRoot* movieRoot = menu->movie->movieRoot;
			GFxValue args[4];
			args[0].SetString(controlName);
			args[1].SetBool(isDown);
			args[2].SetInt(deviceType);
			args[3].SetInt(keyCode);

			movieRoot->Invoke("root.BaseInstance.ProcessUserEventExternal", nullptr, args, 4);
		}
	}

	class F4SEInputHandler : public BSInputEventUser
	{
	public:
		F4SEInputHandler() : BSInputEventUser(true) { }

		virtual void OnButtonEvent(ButtonEvent* inputEvent)
		{
			UInt32	keyCode;
			UInt32	deviceType = inputEvent->deviceType;
			UInt32	keyMask = inputEvent->keyMask;

			if (deviceType == InputEvent::kDeviceType_Mouse)
			{
				keyCode = InputMap::kMacro_MouseButtonOffset + keyMask;
			}
			else if (deviceType == InputEvent::kDeviceType_Gamepad)
			{
				keyCode = InputMap::GamepadMaskToKeycode(keyMask);
			}
			else
			{
				keyCode = keyMask;
			}

			float timer = inputEvent->timer;
			bool isDown = inputEvent->isDown == 1.0f && timer == 0.0f;
			bool isUp = inputEvent->isDown == 0.0f && timer != 0.0f;

			BSFixedString* control = inputEvent->GetControlID();

			if (isDown)
			{
				ProcessUserEvent(control->c_str(), true, deviceType, keyCode);
			}
			else if (isUp)
			{
				ProcessUserEvent(control->c_str(), false, deviceType, keyCode);
			}

		}
	};
	F4SEInputHandler g_examineMenuInputHandler;

	void RegisterForInput(bool bRegister) {
		if (bRegister)
		{
			g_examineMenuInputHandler.enabled = true;
			tArray<BSInputEventUser*>* inputEvents = &((*g_menuControls)->inputEvents);
			BSInputEventUser* inputHandler = &g_examineMenuInputHandler;
			int idx = inputEvents->GetItemIndex(inputHandler);
			if (idx == -1)
			{
				inputEvents->Push(&g_examineMenuInputHandler);
			}
		}
		else
		{
			g_examineMenuInputHandler.enabled = false;
		}
	}
}