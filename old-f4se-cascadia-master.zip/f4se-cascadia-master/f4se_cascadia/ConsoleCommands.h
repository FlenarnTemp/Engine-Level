#pragma once
// Internal Includes
#include "main.h"
#include "../include/RVA.h"	//RVA - reg2k https://github.com/reg2k/rva

//F4SE Includes
#include "f4se/PapyrusVM.h"	// VMClassRegistry

void RegisterForInput(bool bRegister);

void HandleConsoleCommand(const char* sCommand);

void ExecuteCommand_InternalExtern(const char* command);

//	Function Declarations

bool RegisterConsoleCommandFuncs(VirtualMachine* vm);
