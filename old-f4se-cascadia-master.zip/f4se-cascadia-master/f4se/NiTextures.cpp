#include "f4se/NiTextures.h"

RelocAddr <_CreateTexture> CreateTexture(0x01BA5220);

RelocAddr <_CreateBSShaderTextureSet> CreateBSShaderTextureSet(0x027BD1D0);

RelocAddr <_LoadTextureByPath> LoadTextureByPath(0x027D61F0);