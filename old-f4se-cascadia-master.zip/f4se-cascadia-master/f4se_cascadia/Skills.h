#pragma once
#include "main.h"
#include "GameForms.h"
#include "SharedFunctions.h"


//	F4SE Includes
#include "f4se/GameForms.h"
#include "f4se/GameMenus.h"
#include "f4se/GameRTTI.h"
#include "f4se/PapyrusStruct.h"
#include "f4se/GameReferences.h"
#include "f4se/GameData.h"
#include "f4se/GameFormComponents.h"

extern RelocAddr <uintptr_t> ActorValueDerivedVtbl;
extern RelocAddr <uintptr_t> ActorValueCalcVtbl;

typedef std::vector<ActorValueInfo*> AVVector;
typedef std::vector<BGSPerk*> PerkVector;
typedef std::vector<BGSPerkRankArray::Data> PerkRankVector;
typedef std::vector<PerkRankVector> PerkRankMap;

#define DERIVED_FUNCTION_ARG    float(*derivedFunction)(ActorValueOwner*, ActorValueInfo&)
#define CALC_FUNCTION_ARG       void(*calcFunction)(Actor*, ActorValueInfo&, float, float, Actor*)

inline float GetPermanentValue(TESForm* myForm, ActorValueInfo* myAV) {
	ActorValueOwner* owner = DYNAMIC_CAST(myForm, TESForm, ActorValueOwner);
	return owner->GetBase(myAV) + owner->GetMod(1, myAV);
}

inline void ModPermanentValue(TESForm* myForm, ActorValueInfo* myAV, float value) {
	ActorValueOwner* owner = DYNAMIC_CAST(myForm, TESForm, ActorValueOwner);
	owner->Mod(0, myAV, value);
}

inline void ModPermanentSkillValue(TESForm* myForm, ActorValueInfo* myAV, float value) {
	ActorValueOwner* owner = DYNAMIC_CAST(myForm, TESForm, ActorValueOwner);
	owner->Mod(1, myAV, value);
}

enum SPECIALFormIDs {
	StrengthID = 706,
	PerceptionID,
	EnduranceID,
	CharismaID,
	IntelligenceID,
	AgilityID,
	LuckID,
	ExperienceID
};

//	Function Declarations
bool RegisterSkillFuncs(VirtualMachine* vm);
float GetAVValue(Actor* myActor, ActorValueInfo* myAV);
float GetBaseAVValue(Actor* myActor, ActorValueInfo* myAV);
void ModBaseAVValue(Actor* myActor, ActorValueInfo* myAV, int iModAmount);
void SetBaseAVValue(Actor* myActor, ActorValueInfo* myAV, int iSetAmount);
float GetPlayerAVValue(ActorValueInfo* myAV);
float GetPlayerBaseAVValue(ActorValueInfo* myAV);
void ModPlayerBaseAVValue(ActorValueInfo* myAV, int iModAmount);
void SetPlayerBaseAVValue(ActorValueInfo* myAV, int iSetAmount);
bool DefineSkillFormsFromGame();

namespace Skills {
	ActorValueInfo* GetSkillByName(std::string mySkill);
	UInt32 GetSkillValueByName(Actor* myActor, std::string mySkill);
	UInt32 GetBaseSkillValueByName(Actor* myActor, std::string mySkill);

	ActorValueInfo* GetDependantAV(ActorValueInfo* myAV);

	void RegisterForSkillLink();
}



