#pragma once

class VirtualMachine;

#include "f4se/GameTypes.h"

namespace papyrusObjectReference
{
	void RegisterFuncs(VirtualMachine* vm);
}
