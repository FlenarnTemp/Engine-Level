#pragma once
#include "f4se/PluginAPI.h"
#include "f4se/PapyrusEvents.h"
#include <unordered_map>

#include "SharedFunctions.h"

namespace CASSerialization {
	//	Skill Point Functions
	SInt32 GetSkillPoints();
	void SetSkillPoints(SInt32 setValue);
	void ModSkillPoints(SInt32 modValue);

	//	Tag Skill Functions
	void SetSkillTagged(UInt32 skillFormID);
	void RemoveSkillTagged(UInt32 skillFormID);
	bool IsSkillTagged(UInt32 skillFormID);
	UInt32 GetSkillsTagged();

	//	Level Up Functions
	bool IsReadyToLevelUp();
	void SetReadyToLevelUp(bool bReady);

	//	Serialization Functions
	void RevertCallback(const F4SESerializationInterface* f4seSerial);
	void LoadCallback(const F4SESerializationInterface* f4seSerial);
	bool Load(const F4SESerializationInterface* f4seSerial, UInt32 iVersion);
	void SaveCallback(const F4SESerializationInterface* f4seSerial);
	bool Save(const F4SESerializationInterface* f4seSerial, UInt32 iType, UInt32 iVersion);
}