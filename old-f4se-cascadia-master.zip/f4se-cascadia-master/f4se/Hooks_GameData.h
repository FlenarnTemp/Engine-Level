#pragma once

void Hooks_GameData_Init();
void Hooks_GameData_Commit();
