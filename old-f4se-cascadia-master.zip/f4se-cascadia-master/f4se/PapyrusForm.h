#pragma once

class VirtualMachine;
struct StaticFunctionTag;

#include "f4se/GameTypes.h"

namespace papyrusForm
{
	void RegisterFuncs(VirtualMachine* vm);
}
