#pragma once

void Hooks_Gameplay_Init();
void Hooks_Gameplay_Commit();
