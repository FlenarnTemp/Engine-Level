#pragma once
 
class VirtualMachine;

namespace papyrusEquipSlot
{
	void RegisterFuncs(VirtualMachine* vm);
}
