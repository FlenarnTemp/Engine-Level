#pragma once

#include "f4se/GameTypes.h"
 
class BGSHeadPart;
class BGSListForm;
class VirtualMachine;
struct StaticFunctionTag;
 
namespace papyrusHeadPart
{
	void RegisterFuncs(VirtualMachine* vm);
};
