#include "f4se/BSModelDB.h"

// 76A9720CA598893620233A95993057BD7FAF98DD+71
RelocPtr <BSModelDB::BSModelProcessor*> g_TESProcessor(0x058D3370);
