#pragma once

class VirtualMachine;

namespace papyrusArmor
{
	void RegisterFuncs(VirtualMachine* vm);
}
