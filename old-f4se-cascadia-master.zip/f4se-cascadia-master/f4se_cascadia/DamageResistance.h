#pragma once
#pragma warning( disable : 4430)
#include "main.h"

namespace BGSBodyPartDefs
{
	enum LIMB_ENUM
	{
		LIMB_NONE = 0xFFFFFFFF,
		LIMB_BEGIN = 0x0,
		LIMB_TORSO = 0x0,
		LIMB_HEAD_1 = 0x1,
		LIMB_EYE_1 = 0x2,
		LIMB_LOOKAT_1 = 0x3,
		LIMB_FLY_GRAB = 0x4,
		LIMB_HEAD_2 = 0x5,
		LIMB_LEFT_ARM_1 = 0x6,
		LIMB_LEFT_ARM_2 = 0x7,
		LIMB_RIGHT_ARM_1 = 0x8,
		LIMB_RIGHT_ARM_2 = 0x9,
		LIMB_LEFT_LEG_1 = 0xA,
		LIMB_LEFT_LEG_2 = 0xB,
		LIMB_LEFT_LEG_3 = 0xC,
		LIMB_RIGHT_LEG_1 = 0xD,
		LIMB_RIGHT_LEG_2 = 0xE,
		LIMB_RIGHT_LEG_3 = 0xF,
		LIMB_BRAIN = 0x10,
		LIMB_WEAPON = 0x11,
		LIMB_ROOT = 0x12,
		LIMB_COM = 0x13,
		LIMB_PELVIS = 0x14,
		LIMB_CAMERA = 0x15,
		LIMB_OFFSET_ROOT = 0x16,
		LIMB_LEFT_FOOT = 0x17,
		LIMB_RIGHT_FOOT = 0x18,
		LIMB_FACE_TARGET_SOURCE = 0x19,
		LIMB_COUNT = 0x1A
	};

	enum CAUSE_OF_DEATH
	{
		CAUSE_OF_DEATH_NONE = 0xFFFFFFFF,
		CAUSE_OF_DEATH_EXPLOSION = 0x0,
		CAUSE_OF_DEATH_GUN = 0x1,
		CAUSE_OF_DEATH_BLUNT_WEAPON = 0x2,
		CAUSE_OF_DEATH_HAND_TO_HAND = 0x3,
		CAUSE_OF_DEATH_OBJECT_IMPACT = 0x4,
		CAUSE_OF_DEATH_POISON = 0x5,
		CAUSE_OF_DEATH_DECAPITATION = 0x6,
		CAUSE_OF_DEATH_COUNT = 0x7
	};
}

struct AttackData
{
	float			fDamageMult;
	float			fAttackChance;
	SpellItem* pAttackSpell;
	unsigned int	uiFlags;
	float			fAttackAngle;
	float			fStrikeAngle;
	int				iStaggerOffset;
	BGSKeyword* pAttackType;
	float			fKnockdown;
	float			fRecoveryTime;
	float			fActionPointsMult;
};

struct BGSAttackData : NiRefObject
{
	BSFixedString	Event;
	AttackData		Data;
	BGSEquipSlot* pWeaponEquipSlot;
	BGSEquipSlot* pRequiredEquipSlot;
};

struct DamageImpactData
{
	NiPoint3A	kLocation;				//	00
	NiPoint3A	kNormal;				//	10
	NiPoint3A	kVelocity;				//	20
	bhkNPCollisionObject* spColObj;	//	30
	UInt8		pad38[(0x40 - 0x38)];	//	38
};
//STATIC_ASSERT(sizeof(DamageImpactData) == 0x40);

enum STAGGER_MAGNITUDE
{
	STAGGER_NONE = 0x0,
	STAGGER_SMALL = 0x1,
	STAGGER_MEDIUM = 0x2,
	STAGGER_LARGE = 0x3,
	STAGGER_EXTRA_LARGE = 0x4,
	STAGGER_MAGNITUDE_COUNT = 0x5,
	STAGGER_MAGNITUDE_MIN = 0x0,
	STAGGER_MAGNITUDE_MAX = 0x4,
};

struct BGSEquipIndex
{
	unsigned int	uiIndex;
};

//	0xE0
struct HitData
{
	DamageImpactData					ImpactData;					//	00
	UInt32								hAggressor;					//	40
	UInt32								hTarget;					//	44
	UInt32								hSourceRef;					//	48
	UInt8								pad4C[(0x50 - 0x4C)];		//	4C
	NiPointer<BGSAttackData>			spAttackData;				//	50
	BGSObjectInstanceT<TESObjectWEAP>	Weapon;						//	58
	SpellItem* pCriticalEffect;			//	68
	SpellItem* pHitEffect;				//	70
	UInt64								spVATSCommand;				//	78		BSTSmartPointer<VATSCommand,BSTSmartPointerIntrusiveRefCount> spVATSCommand; (padding this out for now)
	TESAmmo* pAmmo;					//	80
	UInt64								pDamageTypesA;				//	88		BSTArray<BSTTuple<TESForm *,BGSTypedFormValuePair::SharedVal>,BSTArrayHeapAllocator> *pDamageTypesA; (padding this out for now)
	float								fHealthDamage;				//	90
	float								fTotalDamage;				//	94
	float								fPhysicalDamage;			//	98
	float								fTargetedLimbDamage;		//	9C
	float								fPercentBlocked;			//	A0
	float								fResistedPhysicalDamage;	//	A4
	float								fResistedTypedDamage;		//	A8
	STAGGER_MAGNITUDE					eStagger;					//	AC
	float								fSneakAttackBonus;			//	B0
	float								fBonusHealthDamageMult;		//	B4
	float								fPushBack;					//	B8
	float								fReflectedDamage;			//	BC
	float								fCriticalDamageMult;		//	C0
	unsigned int						uiFlags;					//	C4
	BGSEquipIndex						EquipIndex;					//	C8
	unsigned int						uiMaterial;					//	CC
	BGSBodyPartDefs::LIMB_ENUM			eDamageLimb;				//	D0
	UInt8								padD4[(0xE0 - 0xD4)];		//	D4
};

//	credit for the following from: https://github.com/isathar/F4SE_F4TF_DamageTweak

// stores a damageType's variables
struct DmgTypeData
{
	UInt32				damageTypeID = 0;
	ActorValueInfo* damageResist = nullptr;
	ActorValueInfo* damageThreshold = nullptr;
	float				fArmorDmgResistExponent = 0.365;
	float				fArmorDmgFactor = 0.15;
	std::string			dmgTypeName = "";
};

// stores a damageType for use in damage calculations
struct DmgTypeStats
{
	UInt32		damageTypeID = 0;
	float		fDmgAmount = 0.0;
	float		fBaseDmg = 0.0;
	float		fDRVal = 0.0;
	float		fArmorPen = 0.0;
	float		fTargetArmorMult = 1.0;
	float		fDRExponent = 0.365;
	float		fDmgFactor = 0.15;
};
//	end credit

enum IncomingDamageType
{
	kDamage_Unknown = -1,
	kDamage_Unarmed = 0,
	kDamage_Melee,
	kDamage_Ranged
};

typedef void (*_ResetArmorRating)	(Actor* actor);

extern RVA <_ResetArmorRating>	ResetArmorRating;

namespace DamageResistance
{
	void GetDamageResistanceForms();
	void InitAddresses();
}

void InitDRHooks();