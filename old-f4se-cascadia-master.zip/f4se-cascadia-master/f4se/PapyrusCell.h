#pragma once

struct StaticFunctionTag;
class VirtualMachine;

namespace papyrusCell
{
	void RegisterFuncs(VirtualMachine* vm);
}
