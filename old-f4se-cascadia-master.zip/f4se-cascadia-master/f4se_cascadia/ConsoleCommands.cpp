#include "ConsoleCommands.h"

#include <fstream>
#include <stdlib.h>

#include "GameForms.h"

typedef void (*_ExecuteCommand)(const char* command);
extern RVA <_ExecuteCommand> ExecuteCommand_Internal("ExecuteCommand", "40 53 55 56 57 41 54 48 81 EC ? ? ? ? 8B 15 ? ? ? ?");


void ExecuteCommand_InternalExtern(const char* command) {
	ExecuteCommand_Internal(command);
}

void ProcessUserEventConsoleCommands(const char* controlName, bool isDown, int deviceType, UInt32 keyCode)
{
	BSFixedString loadingMenuStr("LoadingMenu");
	if ((*g_ui)->IsMenuOpen("LoadingMenu")) {
		if (!strcmp(controlName, "Pipboy") || keyCode == 9) {
			Scaleform::CloseMenu_Internal("LoadingMenu");
			Scaleform::OpenMenu_Internal("Console");
			RegisterForInput(false);
		}
	}
}

class F4SEInputHandler : public BSInputEventUser {
public:
	F4SEInputHandler() : BSInputEventUser(true) { }

	virtual void OnButtonEvent(ButtonEvent* inputEvent) {
		UInt32	keyCode;
		UInt32	deviceType = inputEvent->deviceType;
		UInt32	keyMask = inputEvent->keyMask;

		if (deviceType == InputEvent::kDeviceType_Mouse) {
			keyCode = InputMap::kMacro_MouseButtonOffset + keyMask;
		}
		else if (deviceType == InputEvent::kDeviceType_Gamepad) {
			keyCode = InputMap::GamepadMaskToKeycode(keyMask);
		}
		else {
			keyCode = keyMask;

		}

		float timer = inputEvent->timer;
		bool isDown = inputEvent->isDown == 1.0f && timer == 0.0f;
		bool isUp = inputEvent->isDown == 0.0f && timer != 0.0f;

		BSFixedString* control = inputEvent->GetControlID();

		if (isDown) {
			ProcessUserEventConsoleCommands(control->c_str(), true, deviceType, keyCode);
		}
	}
};

F4SEInputHandler g_consoleCommandsInputHandler;

void RegisterForInput(bool bRegister) {
	if (bRegister) {
		g_consoleCommandsInputHandler.enabled = true;
		tArray<BSInputEventUser*>* inputEvents = &((*g_menuControls)->inputEvents);
		BSInputEventUser* inputHandler = &g_consoleCommandsInputHandler;
		int idx = inputEvents->GetItemIndex(inputHandler);
		if (idx == -1) {
			inputEvents->Push(&g_consoleCommandsInputHandler);
		}
	} else {
		g_consoleCommandsInputHandler.enabled = false;
	}
}

// Runs given console command. eg. RunConsoleCommand("tgm")
void RunConsoleCommand(StaticFunctionTag*, BSFixedString s_CommandString) {
	const char* command = s_CommandString;
	
	ExecuteCommand_Internal(command);
}

// Changes Player's Sex. Call ChangePlayerSex() in Papyrus
void ChangePlayerSex(StaticFunctionTag*) {
	ExecuteCommand_Internal("player.sexchange");
}

namespace CustomConsoleCommands {
	void TestLoadingMenu() {
		//	reimplementing TestLoadingMenu command that is no-op in retail, likely used to test LS models
		std::this_thread::sleep_for(std::chrono::milliseconds(500));

		IMenu* loadingMenu = (*g_ui)->GetMenu(BSFixedString("LoadingMenu"));
		GFxMovieRoot* movieRoot;

		if (loadingMenu) {
			movieRoot = loadingMenu->movie->movieRoot;
		} else {
			TraceLog("TestLoadingMeun: Unable to get IMenu");
			return;
		}

		if (!movieRoot) {
			TraceLog("TestLoadingMenu: Unable to get LoadingMenu root!");
			return;
		} else {
			GFxValue args[3];

			args[0].SetUInt(69420);
			args[1].SetString("");
			args[2].SetString("This is a test loading screen message.");

			movieRoot->Invoke("root.FilterHolder_mc.Menu_mc.SetLoadingText", nullptr, args, 3);
			movieRoot->Invoke("root.FilterHolder_mc.Menu_mc.BGSCodeObj.requestLoadingText", nullptr, nullptr, 0);
		}
	}
}

//	Handles Console Command Batch Files, check each line of given batch file individually
void HandleConsoleCommandBatchFile(const char* sCommand) {
	std::string batchFileName = sCommand;
	std::string trim = "bat ";
	size_t pos = batchFileName.find(trim);

	if (pos != std::string::npos) {
		batchFileName.erase(pos, trim.length());
	}

	std::ifstream batchFile;
	std::string batchData = ("./Data/" + batchFileName + ".txt");
	std::string batchRoot = ("./" + batchFileName + ".txt");

	batchFile.open(batchData);
	if (!batchFile) {
		//	Batch File is not in Data folder, try root folder instead
		batchFile.open(batchRoot);

		if (!batchFile) {
			//	Unable to find batch file
			TraceLog("Console Command: Unable to find Batch File.");
			return;
		}
	}

	std::string str;
	while (std::getline(batchFile, str)) {
		HandleConsoleCommand(str.c_str());
	}

	batchFile.close();
}

//	Receives all console commands
void HandleConsoleCommand(const char* sCommand) {
	//DEBUG
	std::string myDebugStr = "Console Command: ";
	myDebugStr += sCommand;
	TraceLog(myDebugStr);

	std::string commandStr = StrToLower(sCommand);
	size_t batch = commandStr.find("bat");
	size_t testLoadingMenu = commandStr.find("testloadingmenu");

	if (batch != std::string::npos) {
		HandleConsoleCommandBatchFile(sCommand);
	}  else if (testLoadingMenu != std::string::npos) {
		Scaleform::OpenMenu_Internal("LoadingMenu");
		Scaleform::CloseMenu_Internal("Console");
		RegisterForInput(true);
		std::thread TestLoadingMenuWait(CustomConsoleCommands::TestLoadingMenu);
		TestLoadingMenuWait.detach();
	}
}
//=========================================================================================================================

// VM Functions
//=========================================================================================================================
bool RegisterConsoleCommandFuncs(VirtualMachine* vm) {
	vm->RegisterFunction(new NativeFunction1<StaticFunctionTag, void, BSFixedString>("RunConsoleCommand", "FOC:Cascadia", RunConsoleCommand, vm));
	vm->RegisterFunction(new NativeFunction0<StaticFunctionTag, void>("ChangePlayerSex", "FOC:Cascadia", ChangePlayerSex, vm));
	return true;
}
//=========================================================================================================================
