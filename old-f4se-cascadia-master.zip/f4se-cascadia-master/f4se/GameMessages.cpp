#include "f4se/GameMessages.h"

// C23839741F04EC9FEBD007709BC69ED7012F147A+5D
RelocPtr <BSTCommonScrapHeapMessageQueue<BSPackedTask>*> g_messageQueue(0x05AC64F0);
