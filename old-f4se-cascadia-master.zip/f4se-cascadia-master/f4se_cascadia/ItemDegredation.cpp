#include "ItemDegredation.h"

#include <chrono>

#define HasExtraData(ExtraData, Type)\
    ExtraData->HasType(kExtraData_##Type##)

#define SetExtraData(ExtraData, Type, name, value)\
    (((Extra##Type##*)ExtraData->GetByType(kExtraData_##Type##))->##name##) = value;

#define CreateHealthData(ExtraData, Type, value)\
    ExtraData->Add(kExtraData_##Type##, Extra##Type##::Create(value))

#define GetExtraDataValue(ExtraData, Type, name)\
	(((Extra##Type##*)ExtraData->GetByType(kExtraData_##Type##))->##name##)

//	weapon condition game settings
Setting* fDamageWeaponMult;
Setting* fDamageGunWeapCondMult;
Setting* fDamageGunWeapCondBase;
Setting* fDamageMeleeWeapCondMult;
Setting* fDamageMeleeWeapCondBase;
float	 fDamageSkillBase;
float	 fDamageSkillMult;
float	 fAVDMeleeDamageStrengthMult;
float	 fAVDMeleeDamageStrengthOffset;
Setting* fDamageArmConditionBase;
Setting* fDamageArmConditionMult;

//	weapon condition jam game settings https://geck.bethsoft.com/index.php?title=FWeaponConditionReloadJamXX
Setting* fWeaponConditionReloadJam1;
Setting* fWeaponConditionReloadJam2;
Setting* fWeaponConditionReloadJam3;
Setting* fWeaponConditionReloadJam4;
Setting* fWeaponConditionReloadJam5;
Setting* fWeaponConditionReloadJam6;
Setting* fWeaponConditionReloadJam7;
Setting* fWeaponConditionReloadJam8;
Setting* fWeaponConditionReloadJam9;
Setting* fWeaponConditionReloadJam10;

bool bShouldTryAndJamWeapon = false;
std::chrono::system_clock::time_point lastTimeJammed;

//	weapon condition rate of fire game settings https://geck.bethsoft.com/index.php?title=FWeaponConditionRateOfFireXX
Setting* fWeaponConditionRateOfFire1;
Setting* fWeaponConditionRateOfFire2;
Setting* fWeaponConditionRateOfFire3;
Setting* fWeaponConditionRateOfFire4;
Setting* fWeaponConditionRateOfFire5;
Setting* fWeaponConditionRateOfFire6;
Setting* fWeaponConditionRateOfFire7;
Setting* fWeaponConditionRateOfFire8;
Setting* fWeaponConditionRateOfFire9;
Setting* fWeaponConditionRateOfFire10;

ItemDegredation_Struct ItemDegredationForms;

BGSKeyword* furntitureTypePowerArmor;

//	armor type keywords
BGSKeyword* armorTypePower;
BGSKeyword* armorBodyPartChest;
BGSKeyword* armorBodyPartHead;
BGSKeyword* armorBodyPartLeftArm;
BGSKeyword* armorBodyPartRightArm;
BGSKeyword* armorBodyPartLeftLeg;
BGSKeyword* armorBodyPartRightLeg;

/* =============================================================================
	Weapon Condition
   ============================================================================= */

WeaponConditionData::WeaponConditionData() : actor(nullptr), Form(nullptr), extraData(nullptr), instance(nullptr) { }

WeaponConditionData::WeaponConditionData(TESForm* form, ExtraDataList* extradata) 
{
	actor = nullptr;
	Form = form;
	extraData = extradata;
	instance = nullptr;

	if (extraData)
	{
		if (HasExtraData(extraData, InstanceData))
		{
			instance = GetWeaponInstanceData(extraData);
		}
	}
}

WeaponConditionData::WeaponConditionData(Actor* myActor, TESForm* form, ExtraDataList* extradata)
{
	actor = myActor;
	Form = form;
	extraData = extradata;
	instance = nullptr;

	if (extraData)
	{
		if (HasExtraData(extraData, InstanceData))
		{
			instance = GetWeaponInstanceData(extraData);
		}
	}
}

WeaponConditionData::WeaponConditionData(TESObjectREFR* refr) 
{
	if (refr) 
	{
		actor = GetPlayer();
		Form = refr->baseForm;
		extraData = refr->extraDataList;
		instance = nullptr;

		if (extraData)
		{
			if (HasExtraData(extraData, InstanceData))
			{
				instance = GetWeaponInstanceData(extraData);
			}
		}		
	}
}

WeaponConditionData::WeaponConditionData(Actor* myActor)
{
	if (myActor)
	{
		actor = myActor;
		Form = WPNUtilities::GetEquippedWeaponForm(myActor);
		extraData = WPNUtilities::GetEquippedWeaponExtraData(myActor);
		instance = WPNUtilities::GetEquippedWeaponInstanceData(myActor);
	}
}

float GetWeaponConditionMaximum(WeaponConditionData Data) 
{
	if (!Data.extraData)
		return -1.0;
	if (!HasExtraData(Data.extraData, Charge))
		return -1.0;

	return GetExtraDataValue(Data.extraData, Charge, charge);
}

float GetWeaponConditionMaximum(TESObjectREFR* refr)
{
	if (!refr)
		return -1.0;
	return GetWeaponConditionMaximum(WeaponConditionData(refr));
}

float GetWeaponConditionPercent(WeaponConditionData Data) 
{
	if (!Data.extraData)
		return -1.0;
	if (!HasExtraData(Data.extraData, Health))
		return -1.0;

	return GetExtraDataValue(Data.extraData, Health, health);
}

float GetWeaponConditionPercent(TESObjectREFR* refr) 
{
	if (!refr)
		return -1.0;
	return GetWeaponConditionPercent(WeaponConditionData(refr));
}

float GetWeaponConditionCurrent(WeaponConditionData Data) 
{
	float Percent = GetWeaponConditionPercent(Data);
	float Maximum = GetWeaponConditionMaximum(Data);
	if ((0 > Percent) || (0 > Maximum))
		return -1.0;
	return (Percent * Maximum);
}

float GetWeaponConditionCurrent(TESObjectREFR* refr) 
{
	if (!refr)
		return -1.0;
	return GetWeaponConditionPercent(WeaponConditionData(refr));
}

void SetWeaponConditionMaximum(WeaponConditionData Data, float Value)
{
	if (!Data.extraData)
		return;
	if (!HasExtraData(Data.extraData, ObjectHealth))
		return;
	Value = max(1, Value);
	SetExtraData(Data.extraData, Charge, charge, Value);
}

void SetWeaponConditionMaximum(TESObjectREFR* refr, float Value) 
{
	if (!refr)
		return;
	SetWeaponConditionMaximum(WeaponConditionData(refr), Value);
}

void SetWeaponConditionPercent(WeaponConditionData Data, float Value) 
{
	if (!Data.extraData)
	{
		return;
	}

	if (!HasExtraData(Data.extraData, Health))
	{
		return;
	}

	Value = max(0, Value);

	if (Value > 1.0) {
		Value = 1.0;
	}

	SetExtraData(Data.extraData, Health, health, Value);
}

void SetWeaponConditionPercent(TESObjectREFR* refr, float Value) 
{
	if (!refr) {
		return;
	}

	SetWeaponConditionPercent(WeaponConditionData(refr), Value);
}

void SetWeaponConditionCurrent(WeaponConditionData Data, float Value) 
{
	float Current = GetWeaponConditionCurrent(Data);
	float Maximum = GetWeaponConditionMaximum(Data);
	if ((0 > Current) || (0 > Maximum))
		return;

	if (!Data.Form)
		return;

	Value = max(0, Value);
	SetWeaponConditionPercent(Data, (Value / Maximum));
}

void SetWeaponConditionCurrent(TESObjectREFR* refr, float Value) 
{
	if (!refr)
		return;
	SetWeaponConditionCurrent(WeaponConditionData(refr), Value);
}

float GetArmorConditionMaximum(ArmorConditionData Data)
{
	if (!Data.extraData)
		return -1.0;
	if (!HasExtraData(Data.extraData, Charge))
		return -1.0;

	return GetExtraDataValue(Data.extraData, Charge, charge);
}

float GetArmorConditionMaximum(TESObjectREFR* refr)
{
	if (!refr)
		return -1.0;
	return GetArmorConditionMaximum(ArmorConditionData(refr));
}

float GetArmorConditionPercent(ArmorConditionData Data)
{
	if (!Data.extraData)
		return -1.0;
	if (!HasExtraData(Data.extraData, Health))
		return -1.0;

	BSExtraData* healthData = Data.extraData->GetByType(kExtraData_Health);

	if (healthData == nullptr)
		return -1.0;

	return GetExtraDataValue(Data.extraData, Health, health);
}

float GetArmorConditionPercent(TESObjectREFR* refr)
{
	if (!refr)
		return -1.0;
	return GetArmorConditionPercent(ArmorConditionData(refr));
}

float GetArmorConditionCurrent(ArmorConditionData Data)
{
	float Percent = GetArmorConditionPercent(Data);
	float Maximum = GetArmorConditionMaximum(Data);
	if ((0 > Percent) || (0 > Maximum))
		return -1.0;
	return (Percent * Maximum);
}

float GetArmorConditionCurrent(TESObjectREFR* refr)
{
	if (!refr)
		return -1.0;
	return GetArmorConditionPercent(ArmorConditionData(refr));
}

void SetArmorConditionMaximum(ArmorConditionData Data, float Value)
{
	if (!Data.extraData)
		return;
	if (!HasExtraData(Data.extraData, ObjectHealth))
		return;
	Value = max(1, Value);
	SetExtraData(Data.extraData, Charge, charge, Value);
}

void SetArmorConditionMaximum(TESObjectREFR* refr, float Value)
{
	if (!refr)
		return;
	SetArmorConditionMaximum(ArmorConditionData(refr), Value);
}

void SetArmorConditionPercent(ArmorConditionData Data, float Value)
{
	if (!Data.extraData)
	{
		return;
	}

	if (!HasExtraData(Data.extraData, Health))
	{
		return;
	}

	Value = max(0, Value);
	SetExtraData(Data.extraData, Health, health, Value);
}

void SetArmorConditionPercent(TESObjectREFR* refr, float Value)
{
	if (!refr)
		return;
	SetArmorConditionPercent(ArmorConditionData(refr), Value);
}

void SetArmorConditionCurrent(ArmorConditionData Data, float Value)
{
	float Current = GetArmorConditionCurrent(Data);
	float Maximum = GetArmorConditionMaximum(Data);
	if ((0 > Current) || (0 > Maximum))
		return;

	if (!Data.Form)
		return;

	Value = max(0, Value);
	SetArmorConditionPercent(Data, (Value / Maximum));
}

void SetArmorConditionCurrent(TESObjectREFR* refr, float Value)
{
	if (!refr)
		return;
	SetArmorConditionCurrent(ArmorConditionData(refr), Value);
}

float GetWeaponBaseDamageFromDamageType(TESObjectWEAP* baseWPNForm)
{
	if (baseWPNForm->weapData.damageTypes != nullptr)
	{
		for (int i = 0; i < baseWPNForm->weapData.damageTypes->count; i++)
		{
			if (baseWPNForm->weapData.damageTypes->entries[i].damageType != ItemDegredationForms.weaponConditionHealthMaxDMGT && baseWPNForm->weapData.damageTypes->entries[i].damageType != ItemDegredationForms.weaponConditionHealthStartingDMGT)
			{
				return baseWPNForm->weapData.damageTypes->entries[i].value;
			}
		}
	}
	else
	{
		return 1.0;
	}

	return 1.0;
}

float GetWeaponConditionDegradeValue(WeaponConditionData myConditionData)
{
	TESObjectWEAP* baseWPNForm = DYNAMIC_CAST(myConditionData.Form, TESForm, TESObjectWEAP);

	float returnValue = 1.0;

	if (baseWPNForm == nullptr)
	{	
		// Random Degrade Value
		int rngDamage = (rand() % 25 + 5);
		returnValue = (rngDamage * 0.045);
		return returnValue;
	}

	float baseDamage = baseWPNForm->weapData.baseDamage;

	if (baseDamage == 0)
	{
		baseDamage = GetWeaponBaseDamageFromDamageType(baseWPNForm);
	}

	//	using Color Remapping Index as Damage To Weap Mult since Color Remapping isn't used on Weapons
	if (myConditionData.instance->colorRemappingIndex <= 1.0)
	{
		_MESSAGE("Got Value %f from colorRemappingIndex (fDamageToWeapMult)", myConditionData.instance->colorRemappingIndex);
		returnValue = (baseDamage * myConditionData.instance->colorRemappingIndex);
		return returnValue;
	}


	if(baseWPNForm->weapData.skill == nullptr)
	{
		returnValue = (baseDamage * 0.045);
		return returnValue;
	}
	else
	{
		if (baseWPNForm->weapData.skill == CASActorValues.Guns)
		{
			returnValue = (baseDamage * 0.03);
		}
		else if (baseWPNForm->weapData.skill == CASActorValues.EnergyWeapons)
		{
			returnValue = (baseDamage * 0.04);
		}
		else if (baseWPNForm->weapData.skill == CASActorValues.Unarmed || baseWPNForm->weapData.skill == CASActorValues.MeleeWeapons)
		{
			returnValue = (baseDamage * 0.05);
		}

		_MESSAGE("Got Degredation Amount: %f, based on Skill: %s", returnValue, baseWPNForm->weapData.skill->GetFullName());
		return returnValue;
	}
}

void ModWeaponCondition(WeaponConditionData Data, float Value) 
{
	if (IsPlayerGodMode())
	{
		ShowNotification("God Mode Enabled. Ignoring degradation.");
		return;
	}

	float Current = GetWeaponConditionCurrent(Data);
	if (0 > Current)
		return;
	Value = max(0, (Current + Value));

	SetWeaponConditionCurrent(Data, Value);
}

void ModWeaponCondition(TESObjectREFR* refr, float Value) 
{
	if (IsPlayerGodMode())
	{
		ShowNotification("God Mode Enabled. Ignoring degradation.");
		return;
	}

	if (!refr)
	{
		return;
	}

	ModWeaponCondition(WeaponConditionData(refr), Value);
}

void ModWeaponCondition(Actor* actor) 
{
	if (IsPlayerGodMode())
	{
		ShowNotification("God Mode Enabled. Ignoring degradation.");
		return;
	}

	if (!actor)
	{
		return;
	}

	WeaponConditionData Data(actor);

	float Value = GetWeaponConditionDegradeValue(Data);
	ModWeaponCondition(Data, (Value * -1.0));

	float Percent = GetWeaponConditionPercent(Data);
	if (Percent <= 0.25 && Percent != -1.0)
	{
		ShowNotification("Your weapon condition is dangerously low.");

	}

	float Current = GetWeaponConditionCurrent(Data);
	if (Current == 0.0)
	{
		ShowNotification("Your weapon has broken.");
		WPNUtilities::UnequipWeapon(actor);
	}

	_MESSAGE("Mod Weapon Condition: Weapon Condition = %s%%", FloatToPreciseString((GetWeaponConditionPercent(Data) * 100), 2).c_str());

	WPNUtilities::UpdateWeaponStats(Data);
	WPNUtilities::UpdateHUDCondition(Data);
}

float GetArmorConditionDegradeValue(ArmorConditionData myConditionData, ArmorDegrade degrade)
{
	float armorDamagePercent = 0.0;

	if (!degrade.isMelee)
	{
		armorDamagePercent = (degrade.fDamageDealt * 0.35 * 0.5 * 0.5);
	}
	else
	{
		armorDamagePercent = (degrade.fDamageDealt * 0.85 * 0.5);
	}

	return armorDamagePercent;
}

void ModArmorCondition(ArmorConditionData Data, ArmorDegrade degrade, float Value)
{
	if (Data.actor == GetPlayer())
	{
		if (IsPlayerGodMode())
		{
			ShowNotification("God Mode Enabled. Ignoring armor degradation.");
			return;
		}
	}

	float Current = GetArmorConditionCurrent(Data);
	if (0 > Current) {
		return;
	}
	Value = max(0, (Current + Value));
	SetArmorConditionCurrent(Data, Value);
}

void ModArmorCondition(ArmorConditionData Data, ArmorDegrade degrade)
{
	_MESSAGE("Booted into ModArmorCondition");
	if (Data.actor == GetPlayer())
	{
		if (IsPlayerGodMode())
		{
			ShowNotification("God Mode Enabled. Ignoring armor degradation.");
			return;
		}
	}

	float Value = GetArmorConditionDegradeValue(Data, degrade);
	ModArmorCondition(Data, degrade, (Value * -1.0));

	float Percent = GetArmorConditionPercent(Data);
	if (Percent <= 0.25 && Percent != -1.0)
	{
		ShowNotification("Your armor condition is dangerously low.");
	}

	_MESSAGE("Mod Armor Condition: Armor Condition = %s%%", FloatToPreciseString((GetArmorConditionPercent(Data) * 100), 2).c_str());

	ARMOUtilities::UpdateArmorStats(Data);
}

void ModArmorCondition(TESObjectREFR* refr, ArmorDegrade degrade, float Value)
{
	if (!refr)
	{
		return;
	}

	ModArmorCondition(ArmorConditionData(refr), degrade, Value);
}

void ModArmorCondition(Actor* actor, ArmorDegrade degrade)
{
	if (!actor)
	{
		return;
	}

	if (actor == GetPlayer())
	{
		if (IsPlayerGodMode())
		{
			ShowNotification("God Mode Enabled. Ignoring armor degradation.");
			return;
		}
	}

	ArmorConditionData Data(actor);

	float Value = GetArmorConditionDegradeValue(Data, degrade);
	ModArmorCondition(Data, degrade, (Value * -1.0));

	_MESSAGE("Mod Armor Condition: Armor Condition = %s%%", FloatToPreciseString((GetArmorConditionPercent(Data) * 100), 2).c_str());

	ARMOUtilities::UpdateArmorStats(Data);
}

/* =============================================================================
	Armor Condition
   ============================================================================= */

ArmorConditionData::ArmorConditionData() : actor(nullptr), Form(nullptr), extraData(nullptr), instance(nullptr) { }

ArmorConditionData::ArmorConditionData(TESForm* form, ExtraDataList* extradata)
{
	actor = nullptr;
	Form = form;
	extraData = extradata;
	instance = nullptr;

	if (extraData)
	{
		if (HasExtraData(extraData, InstanceData))
		{
			instance = GetArmorInstanceData(extraData);
		}
	}
}

ArmorConditionData::ArmorConditionData(Actor* myActor, TESForm* form, ExtraDataList* extradata)
{
	actor = myActor;
	Form = form;
	extraData = extradata;
	instance = nullptr;

	if (extraData)
	{
		if (HasExtraData(extraData, InstanceData))
		{
			instance = GetArmorInstanceData(extraData);
		}
	}
}

ArmorConditionData::ArmorConditionData(TESObjectREFR* refr)
{
	if (refr)
	{
		actor = GetPlayer();	//	Going to set this to Player so that when a ref gets initialised it already has the Player's stats
		Form = refr->baseForm;
		extraData = refr->extraDataList;
		instance = nullptr;

		if (extraData)
		{
			if (HasExtraData(extraData, InstanceData))
			{
				instance = GetArmorInstanceData(extraData);
			}
		}
	}
}

ArmorConditionData::ArmorConditionData(Actor* myActor)
{
	if (myActor)
	{
		actor = myActor;
		//Form = WPNUtilities::GetEquippedWeaponForm(myActor);
		//extraData = WPNUtilities::GetEquippedWeaponExtraData(myActor);
		//instance = WPNUtilities::GetEquippedWeaponInstanceData(myActor);
	}
}

namespace WPNUtilities
{
	void UpdateHUDCondition(WeaponConditionData myConditionData)
	{
		IMenu* myHUDMenu = (*g_ui)->GetMenu(BSFixedString("HUDMenu"));
		GFxMovieRoot* myMovieRoot = myHUDMenu->movie->movieRoot;

		GFxValue myConditionValue[1];

		float conditionValue = GetWeaponConditionPercent(myConditionData);

		myConditionValue[0].SetNumber(conditionValue);

		myMovieRoot->Invoke("root.CWHUD_loader.content.SetCondition", nullptr, myConditionValue, 1);
	}

	void SetHUDConditionVisibility(bool visible)
	{
		IMenu* myHUDMenu = (*g_ui)->GetMenu(BSFixedString("HUDMenu"));
		GFxMovieRoot* myMovieRoot = myHUDMenu->movie->movieRoot;

		myMovieRoot->Invoke("root.CWHUD_loader.content.ShowHideCondition", nullptr, &GFxValue(visible), 1);
	}

	float CalculateSkillBonusFromActor(WeaponConditionData myConditionData)
	{
		float actorSkillValue = 1.0;

		TESObjectWEAP* myWeapon = DYNAMIC_CAST(myConditionData.Form, TESForm, TESObjectWEAP);

		if (myWeapon->weapData.skill != nullptr)
		{
			if (myConditionData.actor != nullptr)
			{
				actorSkillValue = (GetAVValue(myConditionData.actor, myWeapon->weapData.skill) / 100);
			}
			else
			{
				actorSkillValue = (GetAVValue(GetPlayer(), myWeapon->weapData.skill) / 100);
			}
		}

		float result = (fDamageSkillBase + fDamageSkillMult * actorSkillValue);

		//_MESSAGE("Calculate Skill Bonus From Actor = %f", result);

		return result;
	}

	float CalculateUpdatedDamageValue(float baseDamage, float minimum, float conditionPercent, float skillBonus)
	{
		return (baseDamage * (minimum + conditionPercent * (1 - minimum)) * skillBonus);
	}

	float CalculateUpdatedRateOfFireValue(WeaponConditionData myConditionData, float currentCondition)
	{
		// the calculation here is a bit weird in FO4, Fire Rate is linked to attack delay, with attack delay, the lower it is the higher the Fire Rate
		// instead of multiplying the base attack delay by a set amount instead we divide to make attack delay longer and in turn Fire Rate lower

		TESObjectWEAP* baseWPNForm = DYNAMIC_CAST(myConditionData.Form, TESForm, TESObjectWEAP);

		float baseROF = baseWPNForm->weapData.attackDelay;	//	unkC0 == fAttackSeconds;

		float result = baseROF;

		//_MESSAGE("%s: Base Attack Delay = %f", baseWPNForm->GetFullName(), baseROF);

		if (currentCondition <= 1.0 && currentCondition > 0.9)
		{
			result = (baseROF / fWeaponConditionRateOfFire10->data.f32);
		}
		else if (currentCondition <= 0.9 && currentCondition > 0.8)
		{
			result = (baseROF / fWeaponConditionRateOfFire9->data.f32);
		}
		else if (currentCondition <= 0.8 && currentCondition > 0.7)
		{
			result = (baseROF / fWeaponConditionRateOfFire8->data.f32);
		}
		else if (currentCondition <= 0.7 && currentCondition > 0.6)
		{
			result = (baseROF / fWeaponConditionRateOfFire7->data.f32);
		}
		else if (currentCondition <= 0.6 && currentCondition > 0.5)
		{
			result = (baseROF / fWeaponConditionRateOfFire6->data.f32);
		}
		else if (currentCondition <= 0.5 && currentCondition > 0.4)
		{
			result = (baseROF / fWeaponConditionRateOfFire5->data.f32);
		}
		else if (currentCondition <= 0.4 && currentCondition > 0.3)
		{
			result = (baseROF / fWeaponConditionRateOfFire4->data.f32);
		}
		else if (currentCondition <= 0.3 && currentCondition > 0.2)
		{
			result = (baseROF / fWeaponConditionRateOfFire3->data.f32);
		}
		else if (currentCondition <= 0.2 && currentCondition > 0.1)
		{
			result = (baseROF / fWeaponConditionRateOfFire2->data.f32);
		}
		else if (currentCondition <= 0.1 && currentCondition > 0.0)
		{
			result = (baseROF / fWeaponConditionRateOfFire1->data.f32);
		}

		//_MESSAGE("%s: Updated Attack Delay = %f", baseWPNForm->GetFullName(), result);

		return result;
	}

	bool IsMeleeWeapon(WeaponConditionData myConditionData)
	{
		bool result = false;

		switch (myConditionData.instance->unk137)
		{
		case kWeaponType_HandToHandMelee:
		case kWeaponType_OneHandAxe:
		case kWeaponType_OneHandDagger:
		case kWeaponType_OneHandMace:
		case kWeaponType_OneHandSword:
		case kWeaponType_Staff:
		case kWeaponType_TwoHandAxe:
		case kWeaponType_TwoHandSword:
			result = true;
			break;
		default:
			result = false;
			break;
		}

		return result;
	}

	void UpdateWeaponStats(WeaponConditionData myConditionData)
	{
		if (myConditionData.instance == nullptr)
		{
			return;
		}

		TESObjectWEAP* baseWPNForm = DYNAMIC_CAST(myConditionData.Form, TESForm, TESObjectWEAP);
		TESObjectWEAP::InstanceData* myInstance = myConditionData.instance;

		float currentCondition = GetWeaponConditionPercent(myConditionData);

		float baseValue = baseWPNForm->weapData.value;

		//Value
		float newValue = (baseValue * (pow(currentCondition, 1.5)));
		myInstance->value = newValue;

		//Damage
		float baseDamage = baseWPNForm->weapData.baseDamage;
		float minimum = 0.66;

		//Rate of Fire
		if (!IsMeleeWeapon(myConditionData))
		{
			myInstance->attackDelay = CalculateUpdatedRateOfFireValue(myConditionData, currentCondition);
		}

		switch (myInstance->flags)
		{
		case kFlag_Automatic:
			minimum = 0.54;
			break;
		default:
			switch (myInstance->unk137)
			{
			case kWeaponType_HandToHandMelee:
			case kWeaponType_OneHandAxe:
			case kWeaponType_OneHandDagger:
			case kWeaponType_OneHandMace:
			case kWeaponType_OneHandSword:
			case kWeaponType_Staff:
			case kWeaponType_TwoHandAxe:
			case kWeaponType_TwoHandSword:
				minimum = 0.5;
				break;
			default:
				minimum = 0.66;
				break;
			}
			break;
		}

		if (baseWPNForm->weapData.damageTypes != nullptr)
		{
			for (int i = 0; i < baseWPNForm->weapData.damageTypes->count; i++)
			{
				if (baseWPNForm->weapData.damageTypes->entries[i].damageType != ItemDegredationForms.weaponConditionHealthMaxDMGT && baseWPNForm->weapData.damageTypes->entries[i].damageType != ItemDegredationForms.weaponConditionHealthStartingDMGT)
				{
					float baseValue = baseWPNForm->weapData.damageTypes->entries[i].value;
					float newValue = CalculateUpdatedDamageValue(baseValue, minimum, currentCondition, CalculateSkillBonusFromActor(myConditionData));
					myInstance->damageTypes->entries[i].value = newValue;
					//_MESSAGE("Extra Damage Type: Base Damage = %f, New Damage = %f", baseValue, newValue);
				}
			}
		}

		float newDamage = CalculateUpdatedDamageValue(baseDamage, minimum, currentCondition, CalculateSkillBonusFromActor(myConditionData));
		myInstance->baseDamage = newDamage;
		//_MESSAGE("Base Damage Type: Base Damage = %f, New Damage = %f", baseDamage, newDamage);
	}

	float GetWeaponDamage(WeaponConditionData myConditionData)
	{
		if (myConditionData.instance == nullptr)
		{
			return 0.0;
		}

		TESObjectWEAP* baseWPNForm = DYNAMIC_CAST(myConditionData.Form, TESForm, TESObjectWEAP);
		TESObjectWEAP::InstanceData* myInstance = myConditionData.instance;

		float currentCondition = GetWeaponConditionPercent(myConditionData);

		float baseValue = baseWPNForm->weapData.value;

		//Value
		float newValue = (baseValue * (pow(currentCondition, 1.5)));
		myInstance->value = newValue;

		//Damage
		float baseDamage = baseWPNForm->weapData.baseDamage;
		float minimum = 0.66;

		//Rate of Fire
		if (!IsMeleeWeapon(myConditionData))
		{
			myInstance->attackDelay = CalculateUpdatedRateOfFireValue(myConditionData, currentCondition);
		}

		switch (myInstance->flags)
		{
		case kFlag_Automatic:
			minimum = 0.54;
			break;
		default:
			switch (myInstance->unk137)
			{
			case kWeaponType_HandToHandMelee:
			case kWeaponType_OneHandAxe:
			case kWeaponType_OneHandDagger:
			case kWeaponType_OneHandMace:
			case kWeaponType_OneHandSword:
			case kWeaponType_Staff:
			case kWeaponType_TwoHandAxe:
			case kWeaponType_TwoHandSword:
				minimum = 0.5;
				break;
			default:
				minimum = 0.66;
				break;
			}
			break;
		}

		if (baseWPNForm->weapData.damageTypes != nullptr)
		{
			for (int i = 0; i < baseWPNForm->weapData.damageTypes->count; i++)
			{
				if (baseWPNForm->weapData.damageTypes->entries[i].damageType != ItemDegredationForms.weaponConditionHealthMaxDMGT && baseWPNForm->weapData.damageTypes->entries[i].damageType != ItemDegredationForms.weaponConditionHealthStartingDMGT)
				{
					float baseValue = baseWPNForm->weapData.damageTypes->entries[i].value;
					float newValue = CalculateUpdatedDamageValue(baseValue, minimum, currentCondition, CalculateSkillBonusFromActor(myConditionData));
					return newValue;
					//myInstance->damageTypes->entries[i].value = newValue;
					//_MESSAGE("Extra Damage Type: Base Damage = %f, New Damage = %f", baseValue, newValue);
				}
			}
		}

		float newDamage = CalculateUpdatedDamageValue(baseDamage, minimum, currentCondition, CalculateSkillBonusFromActor(myConditionData));
		return newDamage;
		//myInstance->baseDamage = newDamage;
		//_MESSAGE("Base Damage Type: Base Damage = %f, New Damage = %f", baseDamage, newDamage);
	}

	TESForm* GetEquippedWeaponForm(Actor* actor) 
	{
		for (auto iter : { 0x20, 0x21, 0x25, 0x29 }) 
		{
			if (actor->equipData->slots[iter].item != nullptr)
				return actor->equipData->slots[iter].item;
		}

		return nullptr;
	}

	TESObjectWEAP::InstanceData* GetEquippedWeaponInstanceData(Actor* actor) 
	{
		for (auto iter : { 0x20, 0x21, 0x25, 0x29 }) 
		{
			if (actor->equipData->slots[iter].item != nullptr)
			{
				return CastInstanceData(actor->equipData->slots[iter].instanceData);
			}
		}

		return nullptr;
	}

	UInt64 GetEquippedWeaponHandleID(Actor* actor)
	{
		UInt32 inventoryItemCount = InventoryUtils::GetPipboyInventoryObjectCount();

		for (int i = 0; i < inventoryItemCount; i++)
		{
			TESForm* form = InventoryUtils::GetInventoryFormByIndex(i);
			if (!form)
			{
				continue;
			}

			bool isEquipped = InventoryUtils::GetInventoryItemByIndex(i)->stack->flags & 7;

			if (isEquipped)
			{
				return (UInt64)InventoryUtils::GetHandleIDByIndex(i);
			}
		}

		return 0;
	}

	ExtraDataList* GetEquippedWeaponExtraData(Actor* actor) 
	{
		ExtraDataList* Result = nullptr;
		for (auto iter : { 0x20, 0x21, 0x25, 0x29 }) 
		{
			if (actor->equipData->slots[iter].item != nullptr) 
			{
				actor->GetEquippedExtraData(iter, &Result);
				break;
			}
		}

		return Result;
	}

	void UnequipWeapon(Actor* actor) 
	{
		if (!actor) {
			return;
		}
		

		TESForm* Weapon = GetEquippedWeaponForm(actor);
		if (!Weapon) {
			return;
		}

		//NotificationSound(GetGameSetting("sWeaponBreak")->data.s, "00DCUIWeaponBreak");
		UnequipItem(actor, Weapon, false);
	}

	TESObjectWEAP::InstanceData* CastInstanceData(TBO_InstanceData* myInstanceData)
	{
		return (TESObjectWEAP::InstanceData*)Runtime_DynamicCast(myInstanceData, RTTI_TBO_InstanceData, RTTI_TESObjectWEAP__InstanceData);
	}


	//	returns true if passed weapon instance can jam after reload
	//	this currently doesn't work, maybe the game doesnt track the "No Jam After Reload" flag?
	bool IsWeaponJammingDisabled(TESObjectWEAP::InstanceData* myWeaponInstance)
	{
		return myWeaponInstance->flags == TESObjectWEAP::InstanceData::kFlag_NoJamAfterReload;
	}

	//	runs a RNG check based on current weapon condition and returns true if we should jam
	bool ShouldWeaponJam(WeaponConditionData Data)
	{
		bool result = false;

		if (IsWeaponJammingDisabled(Data.instance))
		{
			_MESSAGE("Weapon %s can not jam.", Data.Form->GetFullName());
			return result;
		}

		float currentWeaponCondition = GetWeaponConditionPercent(Data);
		float rng = RNG((float)0.01, (float)1.0);

		_MESSAGE("Chance to Jam Weapon = %f", rng);

		if (currentWeaponCondition <= 1.0 && currentWeaponCondition > 0.9)
		{
			result = (fWeaponConditionReloadJam10->data.f32 >= rng);
		}
		else if (currentWeaponCondition <= 0.9 && currentWeaponCondition > 0.8)
		{
			result = (fWeaponConditionReloadJam9->data.f32 >= rng);
		}
		else if (currentWeaponCondition <= 0.8 && currentWeaponCondition > 0.7)
		{
			result = (fWeaponConditionReloadJam8->data.f32 >= rng);
		}
		else if (currentWeaponCondition <= 0.7 && currentWeaponCondition > 0.6)
		{
			result = (fWeaponConditionReloadJam7->data.f32 >= rng);
		}
		else if (currentWeaponCondition <= 0.6 && currentWeaponCondition > 0.5)
		{
			result = (fWeaponConditionReloadJam6->data.f32 >= rng);
		}
		else if (currentWeaponCondition <= 0.5 && currentWeaponCondition > 0.4)
		{
			result = (fWeaponConditionReloadJam5->data.f32 >= rng);
		}
		else if (currentWeaponCondition <= 0.4 && currentWeaponCondition > 0.3)
		{
			result = (fWeaponConditionReloadJam4->data.f32 >= rng);
		}
		else if (currentWeaponCondition <= 0.3 && currentWeaponCondition > 0.2)
		{
			result = (fWeaponConditionReloadJam3->data.f32 >= rng);
		}
		else if (currentWeaponCondition <= 0.2 && currentWeaponCondition > 0.1)
		{
			result = (fWeaponConditionReloadJam2->data.f32 >= rng);
		}
		else if (currentWeaponCondition <= 0.1 && currentWeaponCondition > 0.0)
		{
			result = (fWeaponConditionReloadJam1->data.f32 >= rng);
		}

		return result;
	}
}

tArray<BGSMod::Attachment::Mod*> GetAllAttachedObjectMods(ArmorConditionData armorData)
{
	tArray<BGSMod::Attachment::Mod*> modsArray;

	BSExtraData* objectExtraData = armorData.extraData->GetByType(ExtraDataType::kExtraData_ObjectInstance);

	BGSObjectInstanceExtra* objectModData = DYNAMIC_CAST(objectExtraData, BSExtraData, BGSObjectInstanceExtra);

	if (objectModData)
	{
		auto data = objectModData->data;

		int modCount = data->blockSize / sizeof(BGSObjectInstanceExtra::Data::Form);

		if (data && data->forms)
		{
			for (UInt32 i = 0; i < modCount; i++)
			{
				BGSMod::Attachment::Mod* currentOMOD = (BGSMod::Attachment::Mod*)Runtime_DynamicCast(LookupFormByID(data->forms[i].formId), RTTI_TESForm, RTTI_BGSMod__Attachment__Mod);
				modsArray.Push(currentOMOD);
			}
		}
	}

	return modsArray;
}

tArray<BGSMod::Attachment::Mod*> GetAllAttachedObjectMods(WeaponConditionData weapData)
{
	tArray<BGSMod::Attachment::Mod*> modsArray;

	BSExtraData* objectExtraData = weapData.extraData->GetByType(ExtraDataType::kExtraData_ObjectInstance);

	BGSObjectInstanceExtra* objectModData = DYNAMIC_CAST(objectExtraData, BSExtraData, BGSObjectInstanceExtra);

	if (objectModData)
	{
		auto data = objectModData->data;

		int modCount = data->blockSize / sizeof(BGSObjectInstanceExtra::Data::Form);

		if (data && data->forms)
		{
			for (UInt32 i = 0; i < modCount; i++)
			{
				BGSMod::Attachment::Mod* currentOMOD = (BGSMod::Attachment::Mod*)Runtime_DynamicCast(LookupFormByID(data->forms[i].formId), RTTI_TESForm, RTTI_BGSMod__Attachment__Mod);
				modsArray.Push(currentOMOD);
			}
		}
	}

	return modsArray;
}

#include "DamageResistance.h"

namespace ARMOUtilities
{
	BGSKeyword* GetPowerArmorTypeKeyword()
	{
		return armorTypePower;
	}

	void UpdateArmorStats(ArmorConditionData myConditionData)
	{
		if (myConditionData.instance == nullptr)
		{
			return;
		}

		TESObjectARMO* baseARMOForm = DYNAMIC_CAST(myConditionData.Form, TESForm, TESObjectARMO);
		TESObjectARMO::InstanceData* myInstance = myConditionData.instance;

		//	Check if has Armor Body Part Keywords
		bool bHasBodyPartKeyword = false;

		if (ArmorHasKeyword(baseARMOForm, armorBodyPartChest))
			bHasBodyPartKeyword = true;

		if (ArmorHasKeyword(baseARMOForm, armorBodyPartHead))
			bHasBodyPartKeyword = true;

		if (ArmorHasKeyword(baseARMOForm, armorBodyPartLeftArm))
			bHasBodyPartKeyword = true;

		if (ArmorHasKeyword(baseARMOForm, armorBodyPartLeftLeg))
			bHasBodyPartKeyword = true;

		if (ArmorHasKeyword(baseARMOForm, armorBodyPartRightArm))
			bHasBodyPartKeyword = true;

		if (ArmorHasKeyword(baseARMOForm, armorBodyPartRightLeg))
			bHasBodyPartKeyword = true;

		if (!bHasBodyPartKeyword)
		{
			std::string armorFormIDString = GetFormIDAsString(baseARMOForm->formID);
			if (!IsFormIDStringBaseGame(armorFormIDString))
				_MESSAGE("CONDITION: Trying to update a armor (%s) that has no Armor Condition Keywords. Please set up in the Creation Kit!", armorFormIDString.c_str());
			return;
		}

		float currentCondition = GetArmorConditionPercent(myConditionData);

		if (currentCondition == -1.0)
		{
			//	This will likely happen with armors not set up for Armor Condition (ignoring Base game and DLCs for now)
			//	try and initialise condition anyway as a failsafe
			InitializeArmorCondition(myConditionData);

			if (currentCondition == -1.0)
			{
				std::string armorFormIDString = GetFormIDAsString(baseARMOForm->formID);
				if (!IsFormIDStringBaseGame(armorFormIDString)) {
					_MESSAGE("CONDITION: Trying to update a armor (%s) that has no Armor Condition Health. Please set up in the Creation Kit!", armorFormIDString.c_str());
				}
				return;
			}
		}

		float baseValue = (float)baseARMOForm->instanceData.value;

		//	Value
		float newValue = (baseValue * (pow(currentCondition, 1.5)));
		myInstance->value = (UInt32)newValue;

		//	DR
		float maxDR = (float)baseARMOForm->instanceData.armorRating;
		float newDR = ((0.2 * maxDR) + (currentCondition * 100) * ((0.8 * maxDR) / 100));
		//_MESSAGE("Armor (%s): Max DR = %.4f, Health = %.4f%%, Current DR = %.4f", baseARMOForm->GetFullName(), maxDR, (currentCondition * 100), newDR);
		if (newDR < 1.0)
		{
			// minimum DR should be 1 so we don't have 0 DR on an item
			newDR = 1.0;
		}
		myInstance->armorRating = (UInt16)newDR;

	}



	std::vector<BGSInventoryItem> GetEquippedArmorInventoryItems(Actor* actor)
	{
		std::vector<BGSInventoryItem> result{};

		if (!actor)
		{
			actor = GetPlayer();
		}

		auto inventory = actor->inventoryList;
		if (inventory)
		{
			inventory->inventoryLock.LockForReadAndWrite();

			for (int i = 0; i < inventory->items.count; i++)
			{
				BGSInventoryItem iter = inventory->items[i];

				if (iter.stack->flags == 1)
				{
					if (iter.form->formType == FormType::kFormType_ARMO)
					{
						result.push_back(iter);
					}
				}
			}
		}

		inventory->inventoryLock.Unlock();

		return result;
	}

	BGSInventoryItem GetEquippedArmorInventoryItemBasedOnKeyword(Actor* actor, BGSKeyword* keyword)
	{
		std::vector<BGSInventoryItem> equippedArmors = GetEquippedArmorInventoryItems(actor);

		BGSInventoryItem result{};

		for (int i = 0; i < equippedArmors.size(); i++)
		{
			BGSInventoryItem invItem = equippedArmors[i];
			TESObjectARMO* armor = DYNAMIC_CAST(invItem.form, TESForm, TESObjectARMO);

			if (armor)
			{
				if (ArmorHasKeyword(armor, keyword))
				{
					return invItem;
				}
			}
		}

		return result;
	}

	void UpdateArmorStatsOnHit(Actor* actor, UInt32 eDamageLimb, UInt32 eIncomingDamageType, float fDamage)
	{
		BGSKeyword* checkKeyword = nullptr;

		if (actor != GetPlayer())
		{
			//	Ignoring any NPCs
			return;
		}

		bool isPowerArmor = WornHasKeyword(actor, armorTypePower);
		bool isMelee = (eIncomingDamageType == IncomingDamageType::kDamage_Melee);
		bool isUnarmed = (eIncomingDamageType == IncomingDamageType::kDamage_Unarmed);

		switch (eDamageLimb)
		{
		case BGSBodyPartDefs::LIMB_ENUM::LIMB_HEAD_1:
		case BGSBodyPartDefs::LIMB_ENUM::LIMB_HEAD_2:
		case BGSBodyPartDefs::LIMB_ENUM::LIMB_EYE_1:
		case BGSBodyPartDefs::LIMB_ENUM::LIMB_BRAIN:
		{
			_MESSAGE("Hit in Head");
			checkKeyword = armorBodyPartHead;
			break;
		}
		case BGSBodyPartDefs::LIMB_ENUM::LIMB_TORSO:
		case BGSBodyPartDefs::LIMB_ENUM::LIMB_PELVIS:
		{
			_MESSAGE("Hit in Body");
			checkKeyword = armorBodyPartChest;
			break;
		}
		case BGSBodyPartDefs::LIMB_ENUM::LIMB_LEFT_ARM_1:
		case BGSBodyPartDefs::LIMB_ENUM::LIMB_LEFT_ARM_2:
		{
			_MESSAGE("Hit in Left Arm");
			checkKeyword = armorBodyPartLeftArm;
			break;
		}
		case BGSBodyPartDefs::LIMB_ENUM::LIMB_RIGHT_ARM_1:
		case BGSBodyPartDefs::LIMB_ENUM::LIMB_RIGHT_ARM_2:
		{
			_MESSAGE("Hit in Right Arm");
			checkKeyword = armorBodyPartRightArm;
			break;
		}
		case BGSBodyPartDefs::LIMB_ENUM::LIMB_LEFT_LEG_1:
		case BGSBodyPartDefs::LIMB_ENUM::LIMB_LEFT_LEG_2:
		case BGSBodyPartDefs::LIMB_ENUM::LIMB_LEFT_LEG_3:
		case BGSBodyPartDefs::LIMB_ENUM::LIMB_LEFT_FOOT:
		{
			_MESSAGE("Hit in Left Leg");
			checkKeyword = armorBodyPartLeftLeg;
		}
		case BGSBodyPartDefs::LIMB_ENUM::LIMB_RIGHT_LEG_1:
		case BGSBodyPartDefs::LIMB_ENUM::LIMB_RIGHT_LEG_2:
		case BGSBodyPartDefs::LIMB_ENUM::LIMB_RIGHT_LEG_3:
		case BGSBodyPartDefs::LIMB_ENUM::LIMB_RIGHT_FOOT:
		{
			_MESSAGE("Hit in Right Leg");
			checkKeyword = armorBodyPartRightLeg;
			break;
		}
		case BGSBodyPartDefs::LIMB_ENUM::LIMB_WEAPON:

		default:
		{
			_MESSAGE("Unknown Hit Type, Assuming Body");
			checkKeyword = armorBodyPartChest;
			break;
		}
		}

		if (checkKeyword)
		{
			BGSInventoryItem invItem = GetEquippedArmorInventoryItemBasedOnKeyword(actor, checkKeyword);

			if (invItem.form)
			{
				_MESSAGE("Got Form 0x%08X for Armor Degredation", invItem.form->formID);
				ArmorConditionData conditionData = ArmorConditionData(actor, invItem.form, invItem.stack->extraData);
				_MESSAGE("Past ArmorConditionData check");
				if (!isUnarmed)
				{
					_MESSAGE("Not a unarmed attack.");
					ArmorDegrade degrade{};
					degrade.fDamageDealt = fDamage;
					degrade.isMelee = isMelee;
					ModArmorCondition(conditionData, degrade);
				}
			}
		}
	}
}

//	Gets Weapon Instance data from ExtraDataList if it exists
TESObjectWEAP::InstanceData* GetWeaponInstanceData(ExtraDataList* myExtraDataList)
{
	TESObjectWEAP::InstanceData* result = nullptr;
	TBO_InstanceData* myInstanceData = nullptr;

	if (myExtraDataList)
	{
		BSExtraData* myExtraData = myExtraDataList->GetByType(ExtraDataType::kExtraData_InstanceData);

		if (myExtraData)
		{
			ExtraInstanceData* myExtraInstanceData = DYNAMIC_CAST(myExtraData, BSExtraData, ExtraInstanceData);
			if (myExtraInstanceData)
			{
				myInstanceData = myExtraInstanceData->instanceData;
			}
		}
	}
	result = (TESObjectWEAP::InstanceData*)Runtime_DynamicCast(myInstanceData, RTTI_TBO_InstanceData, RTTI_TESObjectWEAP__InstanceData);
	return result;
}

//	Gets Armor Instance data from ExtraDataList if it exists
TESObjectARMO::InstanceData* GetArmorInstanceData(ExtraDataList* myExtraDataList)
{
	TESObjectARMO::InstanceData* result = nullptr;
	TBO_InstanceData* myInstanceData = nullptr;

	if (myExtraDataList)
	{
		BSExtraData* myExtraData = myExtraDataList->GetByType(ExtraDataType::kExtraData_InstanceData);

		if (myExtraData)
		{
			ExtraInstanceData* myExtraInstanceData = DYNAMIC_CAST(myExtraData, BSExtraData, ExtraInstanceData);
			if (myExtraInstanceData)
			{
				myInstanceData = myExtraInstanceData->instanceData;
			}
		}
	}
	result = (TESObjectARMO::InstanceData*)Runtime_DynamicCast(myInstanceData, RTTI_TBO_InstanceData, RTTI_TESObjectARMO__InstanceData);
	return result;
}

float GetMaxConditionValueFromWeapon(TESObjectWEAP* myWeapon)
{
	float result = -1.0;

	if (myWeapon->weapData.damageTypes == nullptr)
	{
		return result;
	}

	//	Find Weapon CND value from custom Damage Type
	for (int i = 0; i < myWeapon->weapData.damageTypes->count; i++)
	{
		if (myWeapon->weapData.damageTypes->entries[i].damageType == ItemDegredationForms.weaponConditionHealthMaxDMGT)
		{
			result = myWeapon->weapData.damageTypes->entries[i].value;
			break;
		}
	}

	return result;
}

float GetMaxConditionValueFromArmor(TESObjectARMO* myArmor)
{
	float result = -1.0;

	if (myArmor->instanceData.health > 0)
	{
		result = (float)myArmor->instanceData.health;
	}

	//_MESSAGE("Getting Max Condition Value of %f from %s", result, myArmor->GetFullName());

	return result;
}

float GetStartingConditionPercentage(TESObjectWEAP::InstanceData* myInstanceData)
{
	float result = -1.0;

	if (myInstanceData == nullptr || myInstanceData->damageTypes == nullptr)
	{
		return -1.0;
	}

	for (int i = 0; i < myInstanceData->damageTypes->count; i++)
	{
		if (myInstanceData->damageTypes->entries[i].damageType == ItemDegredationForms.weaponConditionHealthStartingDMGT)
		{
			result = myInstanceData->damageTypes->entries[i].value;
			break;
		}
	}

	if (result != -1)
	{
		result = (result / 100);
	}

	return result;
}

float GetStartingArmorConditionPercentage(TESObjectARMO::InstanceData* myInstanceData)
{
	//	Setting this up differently from Weapon Condition, if no instance health then we assume 100% Condition
	//	CK health% at 100% is strange and doesn't actually set 100%
	float result = 100.0;

	if (myInstanceData == nullptr)
	{
		return -1.0;
	}

	if (myInstanceData->health > 0)
	{
		result = (float)myInstanceData->health;
	}

	if (result != -1)
	{
		result = (result / 100);
	}

	return result;
}

void InitializeWeaponCondition(WeaponConditionData myConditionData)
{
	TESObjectWEAP* myWeaponBaseForm = DYNAMIC_CAST(myConditionData.Form, TESForm, TESObjectWEAP);

	if (myWeaponBaseForm == nullptr)
	{
		return;
	}

	//	Ignore Grenades and Mines
	if (myWeaponBaseForm->weapData.unk137 == kWeaponType_Grenade || myWeaponBaseForm->weapData.unk137 == kWeaponType_Mine)
	{
		return;
	}

	float iMaxCNDValue = GetMaxConditionValueFromWeapon(myWeaponBaseForm);
	float iMinCNDValue = 0;
	float iStartCNDValue = 0;

	if (!myConditionData.extraData)
	{
		return;
	}

	if (iMaxCNDValue == -1)
	{
		//	Unable to find value from Damage Type so default to random amount between 400 & 500 (Average of all Base Game FO3 Weapons is 438)
		iMaxCNDValue = (rand() % 500 + 400);
	}

	//	Min CND Value should be 10% of max condition
	iMinCNDValue = (iMaxCNDValue / 10);

	//	Create Conditon Values if they don't exist
	if(!HasExtraData(myConditionData.extraData, Health))
	{
		if(HasExtraData(myConditionData.extraData, InstanceData))
		{
			if (myConditionData.instance->modifiers)
			{
				for (int i = 0; i < myConditionData.instance->modifiers->count; i++)
				{
					auto iter = myConditionData.instance->modifiers->entries[i];
					iMaxCNDValue = (iter.avInfo == ItemDegredationForms.itemConditionMaxHealth) ? iter.unk08 : iMaxCNDValue;
					iMinCNDValue = (iter.avInfo == ItemDegredationForms.itemConditionMinHealth) ? iter.unk08 : iMinCNDValue;
					iStartCNDValue = (iter.avInfo == ItemDegredationForms.itemConditionStartCond) ? iter.unk08 : iStartCNDValue;
				}
			}
		}

		float initialHealth = -1.0;

		float initialPercentage = GetStartingConditionPercentage(myConditionData.instance);

		if (initialPercentage == -1.0 || initialPercentage == 0)
		{
			initialHealth = ((rand() % int(iMaxCNDValue - iMinCNDValue) + iMinCNDValue) / iMaxCNDValue);
		}
		else
		{
			initialHealth = initialPercentage;
		}

		CreateHealthData(myConditionData.extraData, Health, 0);
		CreateHealthData(myConditionData.extraData, Charge, iMaxCNDValue);
		SetWeaponConditionPercent(myConditionData, initialHealth);

		WPNUtilities::UpdateWeaponStats(myConditionData);
	}

	//	Update Condition Values with new maximum value
	else
	{
		if (!HasExtraData(myConditionData.extraData, Health) || !HasExtraData(myConditionData.extraData, ObjectHealth))
		{
			return;
		}

		float currentMax = GetWeaponConditionMaximum(myConditionData);
		if (HasExtraData(myConditionData.extraData, InstanceData))
		{
			if (myConditionData.instance->modifiers)
			{
				for (int i = 0; i < myConditionData.instance->modifiers->count; i++)
				{
					auto iter = myConditionData.instance->modifiers->entries[i];
					if (iter.avInfo == ItemDegredationForms.itemConditionMaxHealth)
					{
						if (currentMax != iter.unk08)
						{
							SetWeaponConditionMaximum(myConditionData, iter.unk08);
							WPNUtilities::UpdateWeaponStats(myConditionData);
						}
						break;
					}
				}
			}
		}
	}

}

void InitializeWeaponCondition(TESObjectREFR* myRef)
{
	if (!myRef)
	{
		return;
	}
	InitializeWeaponCondition(WeaponConditionData(myRef));
}

void InitializeArmorCondition(ArmorConditionData myConditionData)
{
	TESObjectARMO* myArmorBaseForm = DYNAMIC_CAST(myConditionData.Form, TESForm, TESObjectARMO);

	if (myArmorBaseForm == nullptr)
	{
		return;
	}

	//	Ignore No Item Degredation keyworded items TODO
	//if (ArmorHasKeyword(myArmorBaseForm, noItemDegredationKeyword))
	//{
		//return;
	//}

	//	Check if Armor has Body Part Keyword
	bool bHasBodyPartKeyword = false;

	if (ArmorHasKeyword(myArmorBaseForm, armorBodyPartChest))
		bHasBodyPartKeyword = true;

	if (ArmorHasKeyword(myArmorBaseForm, armorBodyPartHead))
		bHasBodyPartKeyword = true;

	if (ArmorHasKeyword(myArmorBaseForm, armorBodyPartLeftArm))
		bHasBodyPartKeyword = true;

	if (ArmorHasKeyword(myArmorBaseForm, armorBodyPartLeftLeg))
		bHasBodyPartKeyword = true;

	if (ArmorHasKeyword(myArmorBaseForm, armorBodyPartRightArm))
		bHasBodyPartKeyword = true;

	if (ArmorHasKeyword(myArmorBaseForm, armorBodyPartRightLeg))
		bHasBodyPartKeyword = true;

	if (!bHasBodyPartKeyword)
	{
		//	Disable Condition System if not set up in CK (ignoring base game and DLC for now)
		std::string armorFormIDString = GetFormIDAsString(myArmorBaseForm->formID);
		if (!IsFormIDStringBaseGame(armorFormIDString)) {
			_MESSAGE("CONDITION: Trying to initialise a armor (%s) that has no Armor Condition Keywords. Please set up in the Creation Kit!", armorFormIDString.c_str());
		}
		return;
	}

	float iMaxCNDValue = GetMaxConditionValueFromArmor(myArmorBaseForm);
	float iMinCNDValue = 0;
	float iStartCNDValue = 0;

	if (!myConditionData.extraData)
	{
		return;
	}

	if (iMaxCNDValue == -1.0)
	{
		//	Disable Condition System if not set up in CK (ignoring base game and DLC for now)
		std::string armorFormIDString = GetFormIDAsString(myArmorBaseForm->formID);
		if (!IsFormIDStringBaseGame(armorFormIDString)) {
			_MESSAGE("CONDITION: Trying to initialise a armor (%s) that has no Armor Condition Health. Please set up in the Creation Kit!", armorFormIDString.c_str());
		}
		return;
	}

	//	Min CND Value should be 10% of max condition
	iMinCNDValue = (iMaxCNDValue / 10);

	//	Create Condition Values if they don't exist
	if (!HasExtraData(myConditionData.extraData, Health))
	{
		if (HasExtraData(myConditionData.extraData, InstanceData))
		{
			if (myConditionData.instance->modifiers)
			{
				for (int i = 0; i < myConditionData.instance->modifiers->count; i++)
				{
					auto iter = myConditionData.instance->modifiers->entries[i];
					iMaxCNDValue = (iter.avInfo == ItemDegredationForms.itemConditionMaxHealth) ? iter.unk08 : iMaxCNDValue;
					iMinCNDValue = (iter.avInfo == ItemDegredationForms.itemConditionMinHealth) ? iter.unk08 : iMinCNDValue;
					iStartCNDValue = (iter.avInfo == ItemDegredationForms.itemConditionStartCond) ? iter.unk08 : iStartCNDValue;
				}
			}
		}

		float initialHealth = -1.0;

		float initialPercentage = GetStartingArmorConditionPercentage(myConditionData.instance);

		if (initialPercentage == -1.0 || initialPercentage == 0)
		{
			initialHealth = ((rand() % int(iMaxCNDValue - iMinCNDValue) + iMinCNDValue) / iMaxCNDValue);
		}
		else
		{
			initialHealth = initialPercentage;
		}

		CreateHealthData(myConditionData.extraData, Health, 0);
		CreateHealthData(myConditionData.extraData, Charge, iMaxCNDValue);
		SetArmorConditionPercent(myConditionData, initialHealth);
		ARMOUtilities::UpdateArmorStats(myConditionData);
	}

	//	Update Condition Values with new maximum value
	else
	{
		if (!HasExtraData(myConditionData.extraData, Health) || !HasExtraData(myConditionData.extraData, ObjectHealth))
		{
			return;
		}

		float currentMax = GetArmorConditionMaximum(myConditionData);
		if (HasExtraData(myConditionData.extraData, InstanceData))
		{
			if (myConditionData.instance->modifiers)
			{
				for (int i = 0; i < myConditionData.instance->modifiers->count; i++)
				{
					auto iter = myConditionData.instance->modifiers->entries[i];
					if (iter.avInfo == ItemDegredationForms.itemConditionMaxHealth)
					{
						if (currentMax != iter.unk08)
						{
							SetArmorConditionMaximum(myConditionData, iter.unk08);
							ARMOUtilities::UpdateArmorStats(myConditionData);
						}
						break;
					}
				}
			}
		}
	}
}

void InitializeArmorCondition(TESObjectREFR* myRef)
{
	if (!myRef)
	{
		return;
	}
	InitializeArmorCondition(ArmorConditionData(myRef));
}

BGSInventoryItem GetEquippedPlayerWeaponInventoryItem()
{
	BGSInventoryItem result;

	Actor* player = GetPlayer();

	auto inventory = player->inventoryList;
	if (inventory)
	{
		inventory->inventoryLock.LockForReadAndWrite();

		for (int i = 0; i < inventory->items.count; i++)
		{
			BGSInventoryItem iter;
			inventory->items.GetNthItem(i, iter);

			if (iter.stack->flags == BGSInventoryItem::Stack::kFlagEquipped)
			{
				if (iter.form->formType == FormType::kFormType_WEAP)
				{
					result = iter;
					break;
				}
			}
		}
	}

	inventory->inventoryLock.Unlock();

	return result;
}

void InitializeInventoryItemCondition(TESObjectREFR* myRef, TESForm* myForm)
{
	auto inventory = myRef->inventoryList;
	if (inventory)
	{
		inventory->inventoryLock.LockForReadAndWrite();

		for (int i = 0; i < inventory->items.count; i++)
		{
			BGSInventoryItem iter;
			inventory->items.GetNthItem(i, iter);
			if (iter.form->formID == myForm->formID)
			{
				if (iter.stack)
				{
					int iterCount = 0;
					for (BGSInventoryItem::Stack* traverse = iter.stack; traverse; traverse->next)
					{
						if (!traverse)
						{
							break;
						}

						if (!traverse->extraData)
						{
							break;
						}

						if (!HasExtraData(traverse->extraData, Health))
						{
							switch (myForm->formType)
							{
							case kFormType_ARMO:
								InitializeArmorCondition(ArmorConditionData(iter.form, traverse->extraData));
								break;
							case kFormType_WEAP:
								InitializeWeaponCondition(WeaponConditionData(iter.form, traverse->extraData));
								break;
							default:
								break;
							}
						}

						iterCount++;

						if (iterCount > traverse->count)
						{
							break;
						}
					}
				}

				break;
			}
		}

		inventory->inventoryLock.Unlock();
	}
}

void InitializePowerArmorFrameInventoryCondition(TESObjectREFR* ref)
{
	if (ReferenceHasKeyword(ref, furntitureTypePowerArmor))
	{
		_MESSAGE("Checking Power Armor Frame (%s) Inventory", GetFormIDAsString(ref->formID));
		InitializeInventoryCondition(ref);
	}
}

void InitializeInventoryCondition(TESObjectREFR* myRef)
{
	Actor* myActor = DYNAMIC_CAST(myRef, TESObjectREFR, Actor);

	auto inventory = myRef->inventoryList;
	if (inventory)
	{
		inventory->inventoryLock.LockForReadAndWrite();

		for (int i = 0; i < inventory->items.count; i++)
		{
			BGSInventoryItem iter;
			inventory->items.GetNthItem(i, iter);

			switch (iter.form->formType)
			{
			case kFormType_ARMO:
			{
				if (iter.stack)
				{
					int iterCount = 0;
					for (BGSInventoryItem::Stack* traverse = iter.stack; traverse; traverse->next)
					{
						if (!traverse)
						{
							break;
						}

						if (!traverse->extraData)
						{
							break;
						}

						if (!HasExtraData(traverse->extraData, Health))
						{
							InitializeArmorCondition(ArmorConditionData(myActor, iter.form, traverse->extraData));
						}
						else
						{
							ARMOUtilities::UpdateArmorStats(ArmorConditionData(myActor, iter.form, traverse->extraData));
						}

						iterCount++;

						if (iterCount > traverse->count)
						{
							break;
						}
					}
				}

				break;
			}
			case kFormType_WEAP:
			{
				if (iter.stack)
				{
					int iterCount = 0;
					for (BGSInventoryItem::Stack* traverse = iter.stack; traverse; traverse->next)
					{
						if (!traverse)
						{
							break;
						}

						if (!traverse->extraData)
						{
							break;
						}

						if (!HasExtraData(traverse->extraData, Health))
						{
							InitializeWeaponCondition(WeaponConditionData(myActor, iter.form, traverse->extraData));
						}
						else
						{
							WPNUtilities::UpdateWeaponStats(WeaponConditionData(myActor, iter.form, traverse->extraData));
						}

						iterCount++;

						if (iterCount > traverse->count)
						{
							break;
						}
					}
				}

				break;
			}
			default:
				break;
			}
		}

		inventory->inventoryLock.Unlock();
	}
}

//	Event that handles when Player equips an item
void ItemDegredation_ItemEquipped(TESEquipEvent* myEvent)
{
	if (myEvent->actor && myEvent->bEquipped)
	{
		TESForm* myEventItem = LookupFormByID(myEvent->equippedFormID);
		Actor* actor = DYNAMIC_CAST(myEvent->actor, TESObjectREFR, Actor);
		if (actor && myEventItem)
		{
			if (actor == GetPlayer()) 
			{
				// Player Equipped and item
				switch (myEventItem->formType)
				{
				case FormType::kFormType_ARMO:
				case FormType::kFormType_WEAP:
					break;
				default:
					break;
				}
			}
			else 
			{
				//	NPC equipped an Item
				switch (myEventItem->formType)
				{
				case FormType::kFormType_ARMO:
					break;
				case FormType::kFormType_WEAP:
				{
					WeaponConditionData Data(actor);
					WPNUtilities::UpdateWeaponStats(Data);
					break;
				}
				default:
					break;
				}
			}
		}
	}
}

void CheckForNPCWeaponConditionPerk(TESObjectREFR* myRef)
{
	Actor* myActor = DYNAMIC_CAST(myRef, TESObjectREFR, Actor);

	if (myActor != nullptr)
	{
		if (!HasPerk(myActor, CASPerks.WeaponConditionHandlerPerk))
		{
			AddPerk(myActor, CASPerks.WeaponConditionHandlerPerk, 1);
		}
	}
}

void GetItemDegredationFormsFromGame()
{
	TraceLog("Item Degredation: Defining Degredation Forms From FalloutCascadia.esm");

	//	this holds our max condition health on the Weapon Form in Creation Kit
	ItemDegredationForms.weaponConditionHealthMaxDMGT = reinterpret_cast<BGSDamageType*>(GetFormFromIdentifier("FalloutCascadia.esm|D26DB"));

	//	Actor Values that hold information on Items
	ItemDegredationForms.itemConditionMaxHealth = reinterpret_cast<ActorValueInfo*>(GetFormFromIdentifier("FalloutCascadia.esm|D26E2"));
	ItemDegredationForms.itemConditionMinHealth = reinterpret_cast<ActorValueInfo*>(GetFormFromIdentifier("FalloutCascadia.esm|D26E3"));
	ItemDegredationForms.itemConditionStartCond = reinterpret_cast<ActorValueInfo*>(GetFormFromIdentifier("FalloutCascadia.esm|D26E4"));

	//	this holds our starting condition percent on OMODs in the Creation Kit
	ItemDegredationForms.weaponConditionHealthStartingDMGT = reinterpret_cast<BGSDamageType*>(GetFormFromIdentifier("FalloutCascadia.esm|D3B74"));

	//	Get Condition Game Settings
	fDamageWeaponMult = GetGameSetting("fDamageWeaponMult");
	fDamageGunWeapCondMult = GetGameSetting("fDamageGunWeapCondMult");
	fDamageGunWeapCondBase = GetGameSetting("fDamageGunWeapCondBase");
	fDamageMeleeWeapCondMult = GetGameSetting("fDamageMeleeWeapCondMult");
	fDamageMeleeWeapCondBase = GetGameSetting("fDamageMeleeWeapCondBase");

	fDamageSkillBase = 0.5;
	fDamageSkillMult = 0.5;
	fAVDMeleeDamageStrengthMult = 0.5;
	fAVDMeleeDamageStrengthOffset = 0.0;

	fDamageArmConditionBase = GetGameSetting("fDamageArmConditionBase");
	fDamageArmConditionMult = GetGameSetting("fDamageArmConditionMult");

	fWeaponConditionReloadJam1 = GetGameSetting("fWeaponConditionReloadJam1");
	fWeaponConditionReloadJam2 = GetGameSetting("fWeaponConditionReloadJam2");
	fWeaponConditionReloadJam3 = GetGameSetting("fWeaponConditionReloadJam3");
	fWeaponConditionReloadJam4 = GetGameSetting("fWeaponConditionReloadJam4");
	fWeaponConditionReloadJam5 = GetGameSetting("fWeaponConditionReloadJam5");
	fWeaponConditionReloadJam6 = GetGameSetting("fWeaponConditionReloadJam6");
	fWeaponConditionReloadJam7 = GetGameSetting("fWeaponConditionReloadJam7");
	fWeaponConditionReloadJam8 = GetGameSetting("fWeaponConditionReloadJam8");
	fWeaponConditionReloadJam9 = GetGameSetting("fWeaponConditionReloadJam9");
	fWeaponConditionReloadJam10 = GetGameSetting("fWeaponConditionReloadJam10");

	fWeaponConditionRateOfFire1 = GetGameSetting("fWeaponConditionRateOfFire1");
	fWeaponConditionRateOfFire2 = GetGameSetting("fWeaponConditionRateOfFire2");
	fWeaponConditionRateOfFire3 = GetGameSetting("fWeaponConditionRateOfFire3");
	fWeaponConditionRateOfFire4 = GetGameSetting("fWeaponConditionRateOfFire4");
	fWeaponConditionRateOfFire5 = GetGameSetting("fWeaponConditionRateOfFire5");
	fWeaponConditionRateOfFire6 = GetGameSetting("fWeaponConditionRateOfFire6");
	fWeaponConditionRateOfFire7 = GetGameSetting("fWeaponConditionRateOfFire7");
	fWeaponConditionRateOfFire8 = GetGameSetting("fWeaponConditionRateOfFire8");
	fWeaponConditionRateOfFire9 = GetGameSetting("fWeaponConditionRateOfFire9");
	fWeaponConditionRateOfFire10 = GetGameSetting("fWeaponConditionRateOfFire10");

	//	Store current time
	lastTimeJammed = std::chrono::system_clock::now();

	//	Get Armor Type Keywords
	armorTypePower = reinterpret_cast<BGSKeyword*>(GetFormFromIdentifier("Fallout4.esm|4D8A1"));
	armorBodyPartChest = reinterpret_cast<BGSKeyword*>(GetFormFromIdentifier("Fallout4.esm|6C0EC"));
	armorBodyPartHead = reinterpret_cast<BGSKeyword*>(GetFormFromIdentifier("Fallout4.esm|10C418"));
	armorBodyPartLeftArm = reinterpret_cast<BGSKeyword*>(GetFormFromIdentifier("FalloutCascadia.esm|211D06"));
	armorBodyPartRightArm = reinterpret_cast<BGSKeyword*>(GetFormFromIdentifier("FalloutCascadia.esm|211D08"));
	armorBodyPartLeftLeg = reinterpret_cast<BGSKeyword*>(GetFormFromIdentifier("FalloutCascadia.esm|211D07"));
	armorBodyPartRightLeg = reinterpret_cast<BGSKeyword*>(GetFormFromIdentifier("FalloutCascadia.esm|211D09"));

	_MESSAGE("Item Degredation: Finished defining Degredation Forms");
}

namespace Degredation_Papyrus
{
	void UpdateInventoryCondition_Papyrus(StaticFunctionTag*, TESObjectREFR* myRef)
	{
		if (myRef != nullptr)
		{
			TraceLog("Update Inventory Condition Called from Papyrus");
			InitializeInventoryCondition(myRef);
		}
	}

	float GetEquippedWeaponConditionPercentage_Papyrus(StaticFunctionTag*, Actor* myActor)
	{
		TraceLog("GetEquippedWeaponConditionPercentage called from Papyrus");

		WeaponConditionData actorData(myActor);

		if (actorData.Form == nullptr || actorData.instance == nullptr || actorData.extraData == nullptr) {
			return -1.0;
		}

		return GetWeaponConditionPercent(actorData);
	}

	void ModEquippedWeaponConditionPercentage_Papyrus(StaticFunctionTag*, Actor* myActor, float value)
	{
		TraceLog("ModEquippedWeaponConditionPercentage called from Papyrus");

		WeaponConditionData actorData(myActor);

		if (actorData.Form == nullptr || actorData.instance == nullptr || actorData.extraData == nullptr) {
			return;
		}

		float percentageInitial = GetWeaponConditionPercent(actorData);
		float percentageIncrease = value;

		percentageIncrease += percentageInitial;

		if (percentageIncrease > 1.0)
		{
			percentageIncrease = 1.0;
		}
		else if (percentageIncrease <= 0.0)
		{
			percentageIncrease = 0.0;

			ShowNotification("Your weapon has broken.");
			WPNUtilities::UnequipWeapon(myActor);
		}

		_MESSAGE("Initial Condition = %f, New Condition = %f", percentageInitial, percentageIncrease);
		SetWeaponConditionPercent(actorData, percentageIncrease);
		WPNUtilities::UpdateWeaponStats(actorData);
		if (myActor == GetPlayer())
		{
			WPNUtilities::UpdateHUDCondition(actorData);
		}
	}
}

bool RegisterDegredationFunctions(VirtualMachine* vm)
{
	vm->RegisterFunction(new NativeFunction1<StaticFunctionTag, void, TESObjectREFR*>("UpdateInventoryCondition", "FOC:Cascadia", Degredation_Papyrus::UpdateInventoryCondition_Papyrus, vm));
	vm->RegisterFunction(new NativeFunction1<StaticFunctionTag, float, Actor*>("GetEquippedWeaponConditionPercent", "FOC:Cascadia", Degredation_Papyrus::GetEquippedWeaponConditionPercentage_Papyrus, vm));
	vm->RegisterFunction(new NativeFunction2<StaticFunctionTag, void, Actor*, float>("ModEquippedWeaponConditionPercent", "FOC:Cascadia", Degredation_Papyrus::ModEquippedWeaponConditionPercentage_Papyrus, vm));

	return true;
}

