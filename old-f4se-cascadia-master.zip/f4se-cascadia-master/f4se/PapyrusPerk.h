#pragma once

struct StaticFunctionTag;
class VirtualMachine;

namespace papyrusPerk
{
	void RegisterFuncs(VirtualMachine* vm);
}
