#pragma once

class VirtualMachine;
struct StaticFunctionTag;

#include "f4se/GameTypes.h"

namespace papyrusFavoritesManager
{
	void RegisterFuncs(VirtualMachine* vm);
}
