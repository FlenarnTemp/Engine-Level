#include "Scaleform.h"
#include "SharedFunctions.h"
#include "ItemDegredation.h"

#include "f4se/ScaleformLoader.h"

#include <sstream>

#define LookupTypeByID(id, to) ( ## to *) Runtime_DynamicCast((void*)(LookupFormByID(id)), RTTI_TESForm, RTTI_ ## to)
#define LookupTypeFromPlugin(id, to) ( ## to *) Runtime_DynamicCast((void*)(LookupFormFromPlugin(id)), RTTI_TESForm, RTTI_ ## to)

tArray<ActorValueInfo*> ScaleformSkills;
tArray<BGSSoundDescriptorForm*> ScaleformSkillSounds;

RVA <_PopulateItemCard>		PopulateItemCard;
RVA <_PipboyMenuInvoke>		PipboyMenuInvoke;
RVA <_GetItemByHandleID>	GetItemByHandleID_Internal;
RVA <_GetFormByHandleID>	GetFormByHandleID_Internal;
RVA <_RequestInventoryItem> RequestInventoryItem_Internal;

RVA			<PipboyDataManager*>			g_PipboyDataManager;
RelocPtr    <PipboyDataManager*>            PipboyDataManager_Address(0x058D0AF0);	//	RUNTIME_VERSION_1_10_163

RVA			<InventoryInterface*>			g_InventoryInterface;
RelocPtr    <InventoryInterface*>           InventoryInterface_Address(0x058D4980);	//	RUNTIME_VERSION_1_10_163

bool bInjectMainMenuOnce = false;

bool bShowConditionNumbers = false;

namespace GFxUtilities
{
	void RegisterArray(GFxValue* destination, GFxMovieRoot* root, const char* name, GFxValue* myArray)
	{
		root->CreateArray(myArray);
		destination->SetMember(name, myArray);
	}

	void RegisterString(GFxValue* destination, GFxMovieRoot* root, const char* name, const char* str)
	{
		GFxValue	fxValue;
		root->CreateString(&fxValue, str);
		destination->SetMember(name, &fxValue);
	}
	void RegisterNumber(GFxValue* destination, const char* name, double value)
	{
		GFxValue	fxValue;
		fxValue.SetNumber(value);
		destination->SetMember(name, &fxValue);
	}
	void RegisterInt(GFxValue* destination, const char* name, int value)
	{
		GFxValue	fxValue;
		fxValue.SetInt(value);
		destination->SetMember(name, &fxValue);
	}
	void RegisterUInt(GFxValue* destination, const char* name, UInt32 value)
	{
		GFxValue	fxValue;
		fxValue.SetUInt(value);
		destination->SetMember(name, &fxValue);
	}
	void RegisterBool(GFxValue* destination, const char* name, bool value)
	{
		GFxValue	fxValue;
		fxValue.SetBool(value);
		destination->SetMember(name, &fxValue);
	}

	void SetGFxValue(GFxValue* dst, GFxMovieRoot* root, const char* name, const char* str) 
	{
		GFxValue Value;
		root->CreateString(&Value, str);
		dst->SetMember(name, &Value);
	}

	void SetGFxValue(GFxValue* dst, GFxMovieRoot* root, const char* name, std::string str) 
	{
		GFxValue Value;
		root->CreateString(&Value, str.c_str());
		dst->SetMember(name, &Value);
	}

	void SetGFxValue(GFxValue* dst, const char* name, UInt32 value) 
	{
		GFxValue Value;
		Value.SetUInt(value);
		dst->SetMember(name, &Value);
	}

	void SetGFxValue(GFxValue* dst, const char* name, double value) 
	{
		GFxValue Value;
		Value.SetNumber(value);
		dst->SetMember(name, &Value);
	}

	void SetGFxValue(GFxValue* dst, const char* name, bool value) 
	{
		GFxValue Value;
		Value.SetBool(value);
		dst->SetMember(name, &Value);
	}

	void SetGFxValue(GFxValue* dst, const char* name, int value) 
	{
		GFxValue Value;
		Value.SetInt(value);
		dst->SetMember(name, &Value);
	}

	void SetGFxValue(GFxValue* dst, const char* name, GFxValue value) 
	{
		dst->SetMember(name, &value);
	}

	void SetGFxValue(GFxValue* dst, const char* name, GFxValue* value) 
	{
		dst->SetMember(name, value);
	}
}

class Scaleform_PlayUISound : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{
		if (args->args[0].GetType() != GFxValue::kType_String)
		{
			return;
		}
		else
		{
			PlayUISound(args->args[0].GetString());
		}
	}
};

class LevelUpMenu_OpenMenu : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{
		TraceLog("LevelUpMenu: OpenMenu called from AS3");
		LevelUpMenu::InitialiseValues();
		LevelUpMenu::RegisterForInput(true);
		LevelUpMenu::HandleLevelUpMenuOpen(args->movie->movieRoot);
	}
};

class LevelUpMenu_SetSkills : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{
		UInt32 mySkillsCount = args->args[0].GetArraySize();
		GFxValue arrayElement;
		GFxValue skillName;
		GFxValue skillValue;
		GFxValue skillBaseValue;

		for (int s = 0; s < mySkillsCount; s++)
		{
			args->args[0].GetElement(s, &arrayElement);
			arrayElement.GetMember("sName", &skillName);
			arrayElement.GetMember("iValue", &skillValue);
			arrayElement.GetMember("iBaseValue", &skillBaseValue);
			_MESSAGE(skillName.GetString());
			LevelUpMenu::ModSkillByName(skillName.GetString(), skillValue.GetInt(), skillBaseValue.GetInt());
		}

		TraceLog("Skills set as intended");

		LevelUpMenu::ProcessPerkList(args->movie->movieRoot);
	}
};

class LevelUpMenu_ResetSkills : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{
		LevelUpMenu::ProcessSkillsList(args->movie->movieRoot);
	}
};

class LevelUpMenu_ResetTagSkills : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{
		LevelUpMenu::OnTagSkillsStart(args->movie->movieRoot);
	}
};

class LevelUpMenu_BackToSkills : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{
		GFxMovieRoot* myMovieRoot = args->movie->movieRoot;

		for (int s = 0; s < ScaleformSkills.count; s++)
		{
			ActorValueInfo* myAV = ScaleformSkills.entries[s];
			LevelUpMenu::RevertSkill(myAV);
		}

		TraceLog("LevelUpMenu: Return to Skills Ready, Sending to AS3");

		myMovieRoot->Invoke("root.Menu_mc.onSwitchBackToSkills", nullptr, nullptr, 0);
	}

};

class LevelUpMenu_UpdatePerkMenu : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{
		LevelUpMenu::ProcessPerkList(args->movie->movieRoot);
	}
};

class LevelUpMenu_AddPerks : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{
		UInt32 myPerksCount = args->args[0].GetArraySize();
		GFxValue arrayElement;
		GFxValue perkFormID;

		for (int p = 0; p < myPerksCount; p++)
		{
			args->args[0].GetElement(p, &arrayElement);
			arrayElement.GetMember("iFormID", &perkFormID);
			TESForm* myPerkForm = LookupFormByID(perkFormID.GetInt());
			BGSPerk* myPerk = DYNAMIC_CAST(myPerkForm, TESForm, BGSPerk);
			AddPerk(GetPlayer(), myPerk, 0);
			LevelUpMenu::ModPerkPoints(-1);
		}
	}
};

class LevelUpMenu_TagSkills : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{
		UInt32 mySkillsCount = args->args[0].GetArraySize();
		GFxValue arrayElement;
		GFxValue skillName;
		GFxValue skillTagged;

		TraceLog("LevelUpMenu: Tag Skills received from AS3");

		for (int s = 0; s < mySkillsCount; s++)
		{
			args->args[0].GetElement(s, &arrayElement);
			arrayElement.GetMember("sName", &skillName);
			arrayElement.GetMember("isTagged", &skillTagged);
			LevelUpMenu::SetSkillTagged(Skills::GetSkillByName(skillName.GetString()), skillTagged.GetBool());
		}
	}
};

class LevelUpMenu_LearnSpecial : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{
		UInt32 mySpecialCount = args->args[0].GetArraySize();
		GFxValue arrayElement;
		GFxValue specialFormID;
		GFxValue specialValue;
		ActorValueInfo* mySpecial;

		for (int i = 0; i < mySpecialCount; i++)
		{
			args->args[0].GetElement(i, &arrayElement);
			arrayElement.GetMember("formID", &specialFormID);
			arrayElement.GetMember("iValue", &specialValue);
			mySpecial = LookupTypeByID(specialFormID.GetInt(), ActorValueInfo);
			(*g_player)->actorValueOwner.SetBase(mySpecial, specialValue.GetInt());
		}
	}
};

class LevelUpMenu_ResetSpecial : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{
		LevelUpMenu::HandleLevelUpMenuOpen(args->movie->movieRoot);
	}
};

class LevelUpMenu_PlaySkillSound : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{/*
		if (args->args[0].GetType() != GFxValue::kType_Int)
		{
			return;
		}
		else
		{
			for (int i = 0; i < ScaleformSkills.count; i++)
			{
				ActorValueInfo* myAV = ScaleformSkills.entries[i];
				if (myAV->formID == args->args[0].GetInt())
				{
					BGSSoundDescriptorForm* mySkillSound = ScaleformSkillSounds.entries[i];

					CallGlobalFunctionNoWait1<BGSSoundDescriptorForm*>("CAS:Cascadia", "PlayUISoundFromSoundDescriptor", mySkillSound);
					break;
				}
			}
		}*/
	}
};

class LevelUpMenu_PlayPerkSound : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{/*
		if (args->args[0].GetType() != GFxValue::kType_Int)
		{
			return;
		}
		else
		{
			TESForm* myPerkForm = LookupFormByID(args->args[0].GetInt());
			BGSPerk* myPerk = DYNAMIC_CAST(myPerkForm, TESForm, BGSPerk);
			BGSSoundDescriptorForm* myPerkSound = myPerk->sound;

			//CallGlobalFunctionNoWait1<BGSSoundDescriptorForm*>("FOC:Cascadia", "PlayUISoundFromSoundDescriptor", myPerkSound);
		}*/
	}
};

class LevelUpMenu_CloseMenu : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{
		LevelUpMenu::RegisterForInput(false);
		//Scaleform::OpenMenu_Internal("HUDMenu");
		Scaleform::CloseMenu_Internal("CASLevelUpMenu");
		LevelUpMenu::CompleteLevelUp();
	}
};

class Pipboy_Ready : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{
		//Pipboy::RegisterForInput(true);
		Pipboy::UpdateMenus(args->movie->movieRoot);
	}
};

class Pipboy_CheckForcedLevelUp : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{
		args->result->SetBool(LevelUpMenu::GetForcedLevelUp());
	}
};

class Pipboy_CheckWorkshopTab : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{
		args->result->SetBool(Pipboy::CheckWorkshopTab());
	}
};

class Pipboy_UpdateItemCardsOnSection : public GFxFunctionHandler 
{
public:

	virtual void	Invoke(Args* args)
	{
		UInt32 section = args->args[0].GetInt();

		Pipboy::UpdateItemCardsOnSection(section);
	}
};

class HUD_Ready : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{
		HUD::UpdateMenus(args->movie->movieRoot);
	}
};

class HUD_GetCurrentCondition : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{
		float conditionValue = GetWeaponConditionPercent(WeaponConditionData(GetPlayer()));

		args->result->SetNumber(conditionValue);
	}
};

class RepairNotNeeded_Exectued : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{
		ShowNotification("$CAS_NoNeedToRepair");
	}
};

class NoRepairKits_Executed : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args) 
	{
		ShowNotification("$CAS_NoRepairKits");
	}
};

class RepairFunc_Executed : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{

		UInt32 argReturn = args->args[0].GetInt();

		if (argReturn == -1)
		{
			return;
		}

		BGSInventoryItem* myItem = InventoryUtils::GetInventoryItemByIndex(argReturn);

		Actor* player = GetPlayer();
		TESObjectMISC* repairKit = reinterpret_cast<TESObjectMISC*>(GetFormFromIdentifier("FalloutCascadia.esm|1D59F7"));

		UInt32 repairKitCountReduced = GetItemCount(player, repairKit) - 1;

		RemoveItem(player, repairKit, GetItemCount(player, repairKit), true, nullptr);

		_MESSAGE("%i", myItem->form->formID);
		_MESSAGE(myItem->form->GetFullName());

		if (myItem->form->formType == FormType::kFormType_WEAP) {
			WeaponConditionData weaponData(player, myItem->form, myItem->stack->extraData);

			if (GetWeaponConditionPercent(weaponData) + 0.5 > 1.0) {
				SetWeaponConditionPercent(weaponData, 0.999);
			}
			else {
				SetWeaponConditionPercent(weaponData, GetWeaponConditionPercent(weaponData) + 0.5);
			}

			Pipboy::UpdateItemCardsOnSection(kPage_Weapons);
			WPNUtilities::UpdateWeaponStats(weaponData);
			WPNUtilities::UpdateHUDCondition(weaponData);

		}
		else if(myItem->form->formType == FormType::kFormType_ARMO) {
			ArmorConditionData armorData(player, myItem->form, myItem->stack->extraData);

			if (GetArmorConditionPercent(armorData) + 0.5 > 1.0)
			{
				SetArmorConditionPercent(armorData, 0.999);
			}
			else {
				SetArmorConditionPercent(armorData, GetArmorConditionPercent(armorData) + 0.5);
			}

			Pipboy::UpdateItemCardsOnSection(kPage_Apparel);
			ARMOUtilities::UpdateArmorStats(armorData);
		}
		//AddItem(player, repairKit, -1, true);

		return;
	}
};

class repairKitCount_Executed : public GFxFunctionHandler
{
public:

	virtual void Invoke(Args* args) {
		TESObjectMISC* repairKit = reinterpret_cast<TESObjectMISC*>(GetFormFromIdentifier("FalloutCascadia.esm|1D59F7"));

		args->result->SetInt(GetItemCount(GetPlayer(), repairKit));
	}
};

class hasRepairKit_Executed : public GFxFunctionHandler
{
public:

	virtual void Invoke(Args* args) {

		bool boolTemp = false;

		TESObjectMISC* repairKit = reinterpret_cast<TESObjectMISC*>(GetFormFromIdentifier("FalloutCascadia.esm|1D59F7"));

		if (GetItemCount(GetPlayer(), repairKit) > 0) {
			boolTemp = true;
		}

		args->result->SetBool(boolTemp);
	}
};

class repairWorkbench_Executed : public GFxFunctionHandler
{
public:

	virtual void Invoke(Args* args) {
		int index = args->args[0].GetInt();

		BGSInventoryItem* myItem = InventoryUtils::GetInventoryItemByIndex(index);
		Actor* player = GetPlayer();

		tArray<BGSMod::Attachment::Mod*> bgsMods;

		if (myItem->form->formType == kFormType_WEAP) {
			WeaponConditionData weaponData(player, myItem->form, myItem->stack->extraData);
			bgsMods = GetAllAttachedObjectMods(weaponData);
			//_MESSAGE("%i", bgsMods.count);
		}
		else if (myItem->form->formType == kFormType_ARMO)
		{
			ArmorConditionData armorData(player, myItem->form, myItem->stack->extraData);
			bgsMods = GetAllAttachedObjectMods(armorData);
			//_MESSAGE("%i", bgsMods.count);
		}

		tArray<BGSConstructibleObject*> constObjects;

		constObjects.Push(FindRecipe(myItem->form));

		for (UInt32 i = 0; i < bgsMods.count - 1; i++)
		{

			BGSConstructibleObject* constObject = FindRecipe(bgsMods.entries[i]);

			if (constObject != nullptr && constObject->components->entries[0].component != nullptr)
			{
				constObjects.Push(FindRecipe(bgsMods.entries[i]));
			}
		}

		if (constObjects.count != 0)
		{
			AdjustComponentsBasedOnRepair(GetAllRepairComponents(constObjects));

			//TODO Math on reduction based on repair skill.
		}
	}
};

class NeedsRepair_Executed : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{
		int index = args->args[0].GetInt();

		BGSInventoryItem* myItem = InventoryUtils::GetInventoryItemByIndex(index);

		ArmorConditionData armorData{};
		WeaponConditionData weaponData{};

		float currentPercent = 0.0;

		if (myItem->form->formType == FormType::kFormType_ARMO)
		{
			armorData = ArmorConditionData(GetPlayer(), myItem->form, myItem->stack->extraData);
			currentPercent = GetArmorConditionPercent(armorData);
			SetArmorConditionPercent(armorData, (currentPercent + 0.001));
			args->result->SetBool(IsDamaged(myItem->stack->extraData));
			SetArmorConditionPercent(armorData, currentPercent);
			return;
		}
		else if (myItem->form->formType == FormType::kFormType_WEAP)
		{
			weaponData = WeaponConditionData(GetPlayer(), myItem->form, myItem->stack->extraData);
			currentPercent = GetWeaponConditionPercent(weaponData);
			SetWeaponConditionPercent(weaponData, (currentPercent + 0.001));
			args->result->SetBool(IsDamaged(myItem->stack->extraData));
			SetWeaponConditionPercent(weaponData, currentPercent);
			return;
		}
	}
};

class EligableRepair_Executed : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{

		int index = args->args[0].GetInt();

		BGSInventoryItem* myItem = InventoryUtils::GetInventoryItemByIndex(index);
	
		ArmorConditionData armorData{};
		WeaponConditionData weaponData{};

		switch (myItem->form->formType) {

		case kFormType_ARMO:
			armorData = ArmorConditionData(GetPlayer(), myItem->form, myItem->stack->extraData);
			_MESSAGE("Health: %f", GetArmorConditionPercent(armorData));
			if (GetArmorConditionPercent(armorData) != -1.0)
			{
				args->result->SetBool(true);
				return;
			}
			else
			{
				args->result->SetBool(false);
				return;
			}
			break;

		case kFormType_WEAP:
			weaponData = WeaponConditionData(GetPlayer(), myItem->form, myItem->stack->extraData);
			_MESSAGE("Health: %f", GetWeaponConditionPercent(weaponData));
			if (GetWeaponConditionPercent(weaponData) != -1.0)
			{
				args->result->SetBool(true);
				return;
			}
			else {
				args->result->SetBool(false);
				return;
			}
			break;

		default:
			args->result->SetBool(false);
			return;
			break;
		}
	}
};

class ConsoleMenu_CommandExecuted : public GFxFunctionHandler
{
public:

	virtual void	Invoke(Args* args)
	{
		const char* lastCommand = args->args[0].GetString();

		HandleConsoleCommand(lastCommand);
	}
};

static IMenu* CreateCASLevelUpMenu()
{
	return new Menus::CASLevelUpMenu();
}

static IMenu* CreateCASHUDAdditions()
{
	return new Menus::CWHUDAdditions();
}

namespace Menus
{
	const char* CASLevelUpMenu::sMenuName = "CASLevelUpMenu";

	CASLevelUpMenu::CASLevelUpMenu() : GameMenuBase()
	{
		flags = kFlag_PauseGame | kFlag_ShowCursor | kFlag_HideOther | kFlag_UpdateCursorOnPlatformChange | kFlag_BlurBackground;

		if (CALL_MEMBER_FN((*g_scaleformManager), LoadMovie)(this, movie, "CASLevelUpMenu", "root", 2))
		{
			GFxMovieRoot* movieRoot = movie->movieRoot;

			CreateBaseShaderTarget(shaderTarget, stage);
			shaderTarget->SetFilterColor(false);

			GFxValue BGSCodeObj;
			movieRoot->GetVariable(&BGSCodeObj, "root.Menu_mc.BGSCodeObj");
			RegisterFunction<Scaleform_PlayUISound>(&BGSCodeObj, movieRoot, "PlayUISound");
			RegisterFunction<LevelUpMenu_OpenMenu>(&BGSCodeObj, movieRoot, "OpenMenu");
			RegisterFunction<LevelUpMenu_SetSkills>(&BGSCodeObj, movieRoot, "SetSkills");
			RegisterFunction<LevelUpMenu_ResetSkills>(&BGSCodeObj, movieRoot, "ResetSkills");
			RegisterFunction<LevelUpMenu_ResetTagSkills>(&BGSCodeObj, movieRoot, "ResetTagSkills");
			RegisterFunction<LevelUpMenu_BackToSkills>(&BGSCodeObj, movieRoot, "BackToSkills");
			RegisterFunction<LevelUpMenu_UpdatePerkMenu>(&BGSCodeObj, movieRoot, "UpdatePerkMenu");
			RegisterFunction<LevelUpMenu_AddPerks>(&BGSCodeObj, movieRoot, "AddPerks");
			RegisterFunction<LevelUpMenu_TagSkills>(&BGSCodeObj, movieRoot, "TagSkills");
			RegisterFunction<LevelUpMenu_LearnSpecial>(&BGSCodeObj, movieRoot, "LearnSpecial");
			RegisterFunction<LevelUpMenu_ResetSpecial>(&BGSCodeObj, movieRoot, "ResetSpecial");
			RegisterFunction<LevelUpMenu_PlaySkillSound>(&BGSCodeObj, movieRoot, "PlaySkillSound");
			RegisterFunction<LevelUpMenu_PlayPerkSound>(&BGSCodeObj, movieRoot, "PlayPerkSound");
			RegisterFunction<LevelUpMenu_CloseMenu>(&BGSCodeObj, movieRoot, "CloseMenu");

			LevelUpMenu::GetLevelUpMenuData();

			movieRoot->Invoke("root.Menu_mc.onCodeObjCreate", nullptr, nullptr, 0);
		}
	}

	CASLevelUpMenu::~CASLevelUpMenu() {
		//
	}

	void CASLevelUpMenu::RegisterFunctions() {
		//
	}

	void CASLevelUpMenu::DrawNextFrame(float unk0, void* unk1) {
		__super::DrawNextFrame(unk0, unk1);
	}


	CWHUDAdditions::CWHUDAdditions() : GameMenuBase()
	{
		//flags = ;

		//depth = ;

		if (CALL_MEMBER_FN((*g_scaleformManager), LoadMovie)(this, movie, "CASHUDAdditions", "root", 2))
		{
			GFxMovieRoot* movieRoot = movie->movieRoot;

			CreateBaseShaderTarget(shaderTarget, stage);
			shaderTarget->SetFilterColor(false);

			GFxValue BGSCodeObj;
			movieRoot->GetVariable(&BGSCodeObj, "root.BGSCodeObj");
			RegisterFunction<HUD_Ready>(&BGSCodeObj, movieRoot, "Ready");
			movieRoot->Invoke("root.onCodeObjCreate", nullptr, nullptr, 0);
		}
	}

	CWHUDAdditions::~CWHUDAdditions() {

	}

	void CWHUDAdditions::RegisterFunctions() {

	}

	void CWHUDAdditions::DrawNextFrame(float unk0, void* unk1) {
		__super::DrawNextFrame(unk0, unk1);
	}
}

namespace Scaleform
{
	//	Opens Menu, returns false if menu is not registered
	bool OpenMenu_Internal(std::string myMenu) {
		BSFixedString menuName = myMenu.c_str();

		if ((*g_ui)->IsMenuRegistered(menuName)) {
			CALL_MEMBER_FN(*g_uiMessageManager, SendUIMessage)(menuName, kMessage_Open);
			return true;
		} else {
			return false;
		}
	}

	//	Closes Menu, returns false if menu is not registered
	bool CloseMenu_Internal(std::string myMenu)
	{
		BSFixedString menuName = myMenu.c_str();

		if ((*g_ui)->IsMenuRegistered(menuName)) {
			CALL_MEMBER_FN(*g_uiMessageManager, SendUIMessage)(menuName, kMessage_Close);
			return true;
		} else {
			return false;
		}
	}
	
	//	Returns True if passed menu is open
	bool IsMenuOpen_Internal(std::string myMenu) {
		BSFixedString menuName = myMenu.c_str();

		return (*g_ui)->IsMenuOpen(menuName);
	}

	GFxMovieRoot* GetMovieRootByName(const char* menuName) {
		IMenu* currentMenu = (*g_ui)->GetMenu(BSFixedString(menuName));

		return currentMenu->movie->movieRoot;
	}

	void GetSkillForms() {
		auto skillsListCAS = DYNAMIC_CAST(GetFormFromIdentifier("FalloutCascadia.esm|21F9DF1"), TESForm, BGSListForm);
		for (int s = 0; s < skillsListCAS->forms.count; s++) {
			ActorValueInfo* mySkill = DYNAMIC_CAST(skillsListCAS->forms.entries[s], TESForm, ActorValueInfo);
			if (mySkill == nullptr) {
				//Item is not an ActorValue
				continue;
			}
			ScaleformSkills.Push(mySkill);
		}

		auto skillSoundListCAS = DYNAMIC_CAST(GetFormFromIdentifier("FalloutCascadia.esm|21F9E03"), TESForm, BGSListForm);
		for (int ss = 0; ss < skillSoundListCAS->forms.count; ss++) {
			BGSSoundDescriptorForm* mySkillSound = DYNAMIC_CAST(skillSoundListCAS->forms.entries[ss], TESForm, BGSSoundDescriptorForm);
			if (mySkillSound == nullptr) {
				//Item is not a Sound Descriptor
				continue;
			}
			ScaleformSkillSounds.Push(mySkillSound);
		}
	}

	//	Gets Text from MainMenuUpdates.txt file located in the Interface folder
	std::string GetMainMenuTextFromFile() {
		std::string result;

		std::stringstream resultSS;

		std::ifstream inFile;

		inFile.open("Data\\Interface\\MainMenuUpdates.txt");

		if (!inFile) {
			result = "Unable to open MainMenuUpdates.txt";
		} else {
			std::string str;
			while (std::getline(inFile, str))
			{
				resultSS << str << "\n";
			}

			result = resultSS.str();
		}

		inFile.close();

		return result;
	}

	void RemoveHUDDropShadow() {
		// Remove Dropshadow from the HUD
		IMenu* pHUD = nullptr;
		static BSFixedString menuName("HUDMenu");
		if ((*g_ui) != nullptr && (pHUD = (*g_ui)->GetMenu(menuName), pHUD)) {
			//bool RemovedDropShadow = (*g_ui)->SetDropShadow(menuName, false, false);
		}
	}

	bool RegisterCustomMenus() {
		TraceLog("Scaleform: Registering Custom Menus");

		if ((*g_ui) != nullptr) {
			(*g_ui)->menuOpenCloseEventSource.AddEventSink(&g_MenuOpenCloseEventHandler);

			if (!(*g_ui)->menuTable.Find(&BSFixedString("CASLevelUpMenu"))) {
				(*g_ui)->Register("CASLevelUpMenu", CreateCASLevelUpMenu);
			}

			if (!(*g_ui)->menuTable.Find(&BSFixedString("CASHUDAdditions"))) {
				(*g_ui)->Register("CASHUDAdditions", CreateCASHUDAdditions);
			}
		}
		return true;
	}

	bool RegisterScaleform(GFxMovieView* movieView, GFxValue* f4se_root) {
		GFxMovieRoot* movieRoot = movieView->movieRoot;

		GFxValue currentSWFPath;
		std::string currentSWFPathString = "";
		if (movieRoot->GetVariable(&currentSWFPath, "root.loaderInfo.url")) {
			currentSWFPathString = currentSWFPath.GetString();
			//_MESSAGE("Scaleform: %s Opened", currentSWFPathString.c_str());
		}
		else {
			TraceLog("Scaleform Registration Failed!");
		}

		if (currentSWFPathString.find("CASLevelUpMenu.swf") != std::string::npos) {
			TraceLog("Scaleform: CASLevelUpMenu Opened");
			auto root = movieRoot;
			if (!root) {
				return false;
			}
			else {
				//Scaleform::CloseMenu_Internal("HUDMenu");
			}
		}
		else if (currentSWFPathString.find("LevelUpMenu.swf") != std::string::npos) {
			TraceLog("Scaleform: Vanilla Level Up Menu Opened");
			auto root = movieRoot;
			if (!root) {
				return false;
			}
			else {
				LevelUpMenu::HandleVanillaMenuOpen();
			}
		}
		else if (currentSWFPathString.find("PipboyMenu.swf") != std::string::npos) {
			TraceLog("Scaleform: Pipboy Menu Opened");
			auto root = movieRoot;
			if (!root) {
				return false;
			}
			else {
				GFxValue loader, urlRequest, root;
				movieRoot->GetVariable(&root, "root");
				movieRoot->CreateObject(&loader, "flash.display.Loader");
				movieRoot->CreateObject(&urlRequest, "flash.net.URLRequest", &GFxValue("CASPipboy.swf"), 1);
				root.SetMember("casPipboy_loader", &loader);
				GFxValue casPipboy; movieRoot->CreateObject(&casPipboy);
				root.SetMember("casPipboy", &casPipboy);
				RegisterFunction<Pipboy_Ready>(&casPipboy, movieView->movieRoot, "ready");
				RegisterFunction<Pipboy_CheckForcedLevelUp>(&casPipboy, movieView->movieRoot, "IsForcedLevelUp");
				RegisterFunction<Pipboy_CheckWorkshopTab>(&casPipboy, movieView->movieRoot, "IsWorkshopTabHidden");
				RegisterFunction<Pipboy_UpdateItemCardsOnSection>(&casPipboy, movieView->movieRoot, "UpdateItemCardsOnSection");
				movieRoot->Invoke("root.casPipboy_loader.load", nullptr, &urlRequest, 1);
				movieRoot->Invoke("root.Menu_mc.addChild", nullptr, &loader, 1);
			}
		}
		else if (currentSWFPathString.find("HUDMenu.swf") != std::string::npos)
		{
			TraceLog("Scaleform: HUD Menu Opened");
			auto root = movieRoot;
			if (!root)
			{
				return false;
			}
			else
			{
				GFxValue loader, urlRequest, root;
				movieRoot->GetVariable(&root, "root");
				movieRoot->CreateObject(&loader, "flash.display.Loader");
				movieRoot->CreateObject(&urlRequest, "flash.net.URLRequest", &GFxValue("CWHUDAdditions.swf"), 1);
				root.SetMember("CWHUD_loader", &loader);
				GFxValue cwHUD; movieRoot->CreateObject(&cwHUD);
				root.SetMember("cwHUD", &cwHUD);
				RegisterFunction<HUD_Ready>(&cwHUD, movieView->movieRoot, "Ready");
				RegisterFunction<HUD_GetCurrentCondition>(&cwHUD, movieView->movieRoot, "GetCurrentCondition");
				movieRoot->Invoke("root.CWHUD_loader.load", nullptr, &urlRequest, 1);
				movieRoot->Invoke("root.addChild", nullptr, &loader, 1);
			}
		}
		else if (currentSWFPathString.find("MainMenu.swf") != std::string::npos)
		{
			TraceLog("Scaleform: Main Menu Opened");
			auto root = movieRoot;
			if (!root)
			{
				return false;
			}
			else
			{
				if (!bInjectMainMenuOnce)
				{
					GFxValue motd, header;
					std::string menuText = GetMainMenuTextFromFile();
					motd.SetString(menuText.c_str());
					header.SetString("$MM_UPDATE_HEADER");
					movieRoot->Invoke("root.Menu_mc.SetMotd_External", nullptr, &motd, 1);
					movieRoot->Invoke("root.Menu_mc.SetHeader_External", nullptr, &header, 1);
					bInjectMainMenuOnce = true;
				}
			}
		}
		else if (currentSWFPathString.find("Console.swf") != std::string::npos)
		{
			TraceLog("Scaleform: Console Menu Opened");
			auto root = movieRoot;
			if (!root)
			{
				return false;
			}
			else
			{
				GFxValue BGSCodeObj;
				movieRoot->GetVariable(&BGSCodeObj, "root.AnimHolder_mc.Menu_mc.BGSCodeObj");
				RegisterFunction<ConsoleMenu_CommandExecuted>(&BGSCodeObj, movieRoot, "logCommand");
			}
		}
		else if (currentSWFPathString.find("ExamineMenu.swf") != std::string::npos)
		{
			TraceLog("Scaleform: Examine Menu Opened");
			auto root = movieRoot;
			if (!root)
			{
				return false;
			}
			else
			{
				GFxValue BGSCodeObj;
				movieRoot->GetVariable(&BGSCodeObj, "root.BaseInstance.BGSCodeObj");
				Examine::RegisterForInput(true);
				RegisterFunction<RepairFunc_Executed>(&BGSCodeObj, movieRoot, "CASRepairItem");
				RegisterFunction<EligableRepair_Executed>(&BGSCodeObj, movieRoot, "EligableRepair");
				RegisterFunction<hasRepairKit_Executed>(&BGSCodeObj, movieRoot, "hasRepairKits");
				RegisterFunction<repairKitCount_Executed>(&BGSCodeObj, movieRoot, "repairKitCount");
				RegisterFunction<NeedsRepair_Executed>(&BGSCodeObj, movieRoot, "needsRepair");
				RegisterFunction<NoRepairKits_Executed>(&BGSCodeObj, movieRoot, "NoRepairKits");
				RegisterFunction<RepairNotNeeded_Exectued>(&BGSCodeObj, movieRoot, "RepairNotNeeded");
				RegisterFunction<repairWorkbench_Executed>(&BGSCodeObj, movieRoot, "RepairWorkbench");
			}
		}

		return true;
	}

	void InitAddresses()
	{
		PopulateItemCard = RVA <_PopulateItemCard>(
			"PopulateItemCard", {
				{ RUNTIME_VERSION_1_10_163, 0x00AED830 },
			}, "48 8B C4 4C 89 48 20 44 89 40 18 48 89 50 10 48 89 48 08 55 48 8D A8 28");
		PipboyMenuInvoke = RVA <_PipboyMenuInvoke>(
			"PipboyMenuInvoke", {
				{ RUNTIME_VERSION_1_10_163, 0x00B94080 },
			}, "4C 8B DC 55 53 57 49 8D 6B 88");
		GetItemByHandleID_Internal = RVA <_GetItemByHandleID>(
			"GetItemByHandleID", {
				{ RUNTIME_VERSION_1_10_163, 0x001A3650 },
			}, "40 53 56 57 48 83 EC 20 33 FF");
		GetFormByHandleID_Internal = RVA <_GetFormByHandleID>(
			"GetFormByHandleID", {
				{ RUNTIME_VERSION_1_10_163, 0x001A3740 },
			}, "48 83 EC 28 E8 07 FF FF FF 48");

		g_PipboyDataManager = RVA <PipboyDataManager*>		(GET_RVA(PipboyDataManager_Address),	"48 8B 0D ? ? ? ?",				0, 3, 7);
		g_InventoryInterface = RVA <InventoryInterface*>	(GET_RVA(InventoryInterface_Address),	"48 8B 0D ? ? ? ? E8 ? ? ? ?",	0, 3, 7);
	}
}


namespace InventoryUtils
{
	UInt32 GetPipboyInventoryObjectCount()
	{
		return PipboyInventoryObjects.count;
	}

	std::string GetInventoryDisplayName(UInt32 index)
	{
		return (std::string)GetTableValue(BSFixedString, index, "text");
	}

	UInt32 GetHandleIDByIndex(UInt32 index) 
	{
		return GetTableValue(UInt32, index, "HandleID");
	}

	UInt32 GetStackIDByIndex(UInt32 index) 
	{
		PipboyArray* StackIDs = GetTableArray(index, "StackID");
		UInt32 Result = 0;

		for (int i = 0; i < StackIDs->value.count; i++) 
		{
			Result = GetTableArrayValue(UInt32, i, StackIDs);
		}

		return Result;
	}

	TESForm* GetInventoryFormByHandleID(UInt32 HandleID) 
	{
		return GetFormByHandleID_Internal(*g_InventoryInterface, &HandleID);
	}

	TESForm* GetInventoryFormByIndex(UInt32 index) 
	{
		UInt32 HandleID = GetTableValue(UInt32, index, "HandleID");
		return GetInventoryFormByHandleID(HandleID);
	}

	BGSInventoryItem* GetInventoryItemByHandleID(UInt32 HandleID) 
	{
		return GetItemByHandleID_Internal(*g_InventoryInterface, &HandleID);
	}

	BGSInventoryItem* GetInventoryItemByIndex(UInt32 index) 
	{
		UInt32 HandleID = GetTableValue(UInt32, index, "HandleID");
		return GetInventoryItemByHandleID(HandleID);
	}

	UInt32 GetIndexByInventoryItem(BGSInventoryItem* item)
	{
		UInt32 inventoryCount = GetPipboyInventoryObjectCount();

		for (UInt32 i = 0; i < inventoryCount; i++)
		{
			BGSInventoryItem* iter = GetInventoryItemByIndex(i);

			if (item == iter)
			{
				return i;
			}
		}

		return -1;
	}

	BGSInventoryItem::Stack* GetStackByStackID(BGSInventoryItem* Item, int StackID) 
	{
		BGSInventoryItem::Stack* traverse = Item->stack;
		if (!traverse)
			return nullptr;

		while (StackID != 0) {
			traverse = traverse->next;
			if (!traverse)
				return nullptr;
			StackID--;
		}

		return traverse;
	}

	ExtraDataList* GetExtraDataListByStackID(BGSInventoryItem* Item, int StackID) 
	{
		if (!Item)
			return nullptr;

		BGSInventoryItem::Stack* stack = GetStackByStackID(Item, StackID);
		return (stack) ? stack->extraData : nullptr;
	}

	ExtraDataList* GetExtraDataListByIndex(UInt32 index) 
	{
		BGSInventoryItem* Item = GetInventoryItemByIndex(index);
		UInt32              StackID = GetStackIDByIndex(index);

		if (!Item)
			return nullptr;

		BGSInventoryItem::Stack* stack = GetStackByStackID(Item, StackID);
		return (stack) ? stack->extraData : nullptr;
	}
}

namespace ItemCard
{
	void ChangePACondition(GFxValue* InfoObj, GFxMovieRoot* root, const char* title, float value, bool isExamineMenu)
	{
		for (int i = 0; i < InfoObj->GetArraySize(); i++) {
			GFxValue element, text;
			InfoObj->GetElement(i, &element);

			element.GetMember("text", &text);

			if (!_stricmp(text.GetString(), title))
			{
				if (!isExamineMenu)
				{
					GFxUtilities::SetGFxValue(&element, root, "text", "$F4CW_CND_PERCENT");
				}
				else
				{
					GFxUtilities::SetGFxValue(&element, root, "text", "$F4CW_Condition_Percent");
				}

				GFxUtilities::SetGFxValue(&element, "value", value);
				GFxUtilities::SetGFxValue(&element, "max", 200.0);
				if (!bShowConditionNumbers)
				{
					GFxUtilities::SetGFxValue(&element, "IsMeter", true);
				}
				GFxUtilities::SetGFxValue(&element, "showAsPercent", true);
			}
		}
	}

	int GetMax(GFxValue* Entry) 
	{
		GFxValue Value;
		Entry->GetMember("value", &Value);
		if (!Value.IsString())
			return -1;

		std::string ValueStr = Value.GetString();
		if (ValueStr.empty())
			return -1;

		auto delimiter = ValueStr.find_first_of("/");
		std::string maximum = ValueStr.substr(0, delimiter);

		return std::stoi(maximum);
	}

	void DivToMeter(GFxValue* Entry) 
	{
		GFxValue Value;
		Entry->GetMember("value", &Value);
		if (!Value.IsString())
			return;

		std::string ValueStr = Value.GetString();
		if (ValueStr.empty())
			return;

		auto delimiter = ValueStr.find_first_of("/");
		std::string current = ValueStr.substr(delimiter + 1);
		std::string maximum = ValueStr.substr(0, delimiter);

		GFxUtilities::SetGFxValue(Entry, "value", std::stoi(current));
		GFxUtilities::SetGFxValue(Entry, "max", std::stoi(maximum));
		if (!bShowConditionNumbers)
		{
			GFxUtilities::SetGFxValue(Entry, "IsMeter", true);
		}
		GFxUtilities::SetGFxValue(Entry, "showAsPercent", true);
	}

	void UpdateWeaponValue(GFxValue* InfoObj, GFxMovieRoot* root, const char* title, float newValue)
	{
		for (int i = 0; i < InfoObj->GetArraySize(); i++)
		{
			GFxValue element, text, value;
			InfoObj->GetElement(i, &element);

			element.GetMember("text", &text);
			if (!_stricmp(text.GetString(), title))
			{
				element.GetMember("value", &value);
				if (!value.GetNumber() == 0)
				{
					GFxUtilities::SetGFxValue(&element, "value", newValue);
				}
			}
		}
	}

	void UpdateArmorValue(GFxValue* InfoObj, GFxMovieRoot* root, const char* title, float newValue)
	{
		for (int i = 0; i < InfoObj->GetArraySize(); i++)
		{
			GFxValue element, text, value;
			InfoObj->GetElement(i, &element);

			element.GetMember("text", &text);
			if (!_stricmp(text.GetString(), title))
			{
				element.GetMember("value", &value);
				if (!value.GetNumber() == 0)
				{
					GFxUtilities::SetGFxValue(&element, "value", newValue);
				}
			}
		}
	}

	void ReformatCondition(GFxValue* InfoObj, GFxMovieRoot* root, const char* title, bool ShowMax) 
	{
		for (int i = 0; i < InfoObj->GetArraySize(); i++) {
			GFxValue element, text;
			InfoObj->GetElement(i, &element);

			element.GetMember("text", &text);
			if (!_stricmp(text.GetString(), title)) {
				DivToMeter(&element);

				if (ShowMax) {
					int maximum = GetMax(&element);
					if (maximum != -1) {
						GFxValue MaxCondEntry;
						GFxUtilities::SetGFxValue(&MaxCondEntry, root, "text", "$MAX CND");
						GFxUtilities::SetGFxValue(&MaxCondEntry, "value", maximum);
						GFxUtilities::SetGFxValue(&MaxCondEntry, "IsMeterMax", true);
						if (!bShowConditionNumbers)
						{
							GFxUtilities::SetGFxValue(&MaxCondEntry, "IsMeter", true);
						}
						InfoObj->PushBack(&MaxCondEntry);
					}
				}
			}
		}
	}
}

_PipboyMenuInvoke PipboyMenuInvoke_Original;
void HookPipboyMenuInvoke(void (*hookFunc)(PipboyMenu*, GFxFunctionHandler::Args*))
{
	struct HookCode : Xbyak::CodeGenerator
	{
		HookCode(void* buf) : Xbyak::CodeGenerator(4096, buf)
		{
			Xbyak::Label retnLabel;

			mov(r11, rsp);
			push(rbp);
			push(rbx);
			jmp(ptr[rip + retnLabel]);

			L(retnLabel);
			dq(PipboyMenuInvoke.GetUIntPtr() + 5);
		}
	};

	void* codeBuf = g_localTrampoline.StartAlloc();
	HookCode code(codeBuf);
	g_localTrampoline.EndAlloc(code.getCurr());

	PipboyMenuInvoke_Original = (_PipboyMenuInvoke)codeBuf;
	g_branchTrampoline.Write5Branch(PipboyMenuInvoke.GetUIntPtr(), (uintptr_t)hookFunc);
}

void PipboyMenuInvoke_Hook(PipboyMenu* menu, GFxFunctionHandler::Args* args) 
{
	PipboyMenuInvoke_Original(menu, args);

	GFxMovieRoot* root = menu->movie->movieRoot;

	switch (args->optionID) 
	{
	case PipboyMenu::kFunction_OnInvItemSelection: 
	{
		int SelectedIndex = args->args[0].GetInt();
		if (SelectedIndex > -1) {
			BGSInventoryItem*	Item = InventoryUtils::GetInventoryItemByIndex(SelectedIndex);
			UInt32              StackID = InventoryUtils::GetStackIDByIndex(SelectedIndex);

			SimpleCollector<InvItemStack> Blank{ 0, { } };
			PopulateItemCard_Custom(&args->args[1], Item, StackID, &Blank);
		};
	}

	default:
		break;
	}
}

void PopulateItemCard_Custom(GFxValue* InfoObj, BGSInventoryItem* Item, UInt16 StackID, InvItemStackList CompareList)
{
	GFxMovieRoot* root = InfoObj->objectInterface->view->movieRoot;

	GFxValue SWFPath; root->GetVariable(&SWFPath, "root.loaderInfo.url");
	bool isExamineMenu = (!_stricmp("Interface/ExamineMenu.swf", SWFPath.GetString()));
	bool isBarterMenu = (!_stricmp("Interface/BarterMenu.swf", SWFPath.GetString()));

	if (!Item) {
		return;
	}

	if (!Item->form) {
		return;
	}

	if (!InfoObj->IsArray()) {
		return;
	}
	switch (Item->form->formType) 
	{
	case kFormType_AMMO: 
	{
		ItemCard::ReformatCondition(InfoObj, root, "$charge", false);
		break;
	}

	case kFormType_ARMO: 
	{
		ItemCard::ReformatCondition(InfoObj, root, "$health", isExamineMenu);

		ExtraDataList* extraDataList = InventoryUtils::GetExtraDataListByStackID(Item, StackID);
		if (!extraDataList)
		{
			return;
		}

		ArmorConditionData Data(Item->form, extraDataList);
		Data.actor = GetPlayer();
		TESObjectARMO* baseARMOForm = DYNAMIC_CAST(Data.Form, TESForm, TESObjectARMO);

		bool bPowerArmor = ArmorHasKeyword(baseARMOForm, ARMOUtilities::GetPowerArmorTypeKeyword());

		ARMOUtilities::UpdateArmorStats(Data);

		float Value = GetArmorConditionPercent(Data);

		if (Value == -1.0)
		{
			InitializeArmorCondition(Data);
			Value = GetArmorConditionPercent(Data);

			if (Value == -1.0)
			{
				return;
			}
		}

		if (isExamineMenu)
		{
			ItemCard::UpdateArmorValue(InfoObj, root, "$val", Value);
		}

		if (Value == -1)
		{
			return;
		}
		else
		{
			Value = (Value * 100);
		}

		if (!bPowerArmor)
		{
			GFxValue InfoCardEntry;
			root->CreateObject(&InfoCardEntry);

			if (!isExamineMenu)
			{
				GFxUtilities::SetGFxValue(&InfoCardEntry, root, "text", "$F4CW_CND_PERCENT");
			}
			else
			{
				GFxUtilities::SetGFxValue(&InfoCardEntry, root, "text", "$F4CW_Condition_Percent");
			}

			GFxUtilities::SetGFxValue(&InfoCardEntry, "value", Value);
			GFxUtilities::SetGFxValue(&InfoCardEntry, "max", 100.0);
			if (!bShowConditionNumbers)
			{
				GFxUtilities::SetGFxValue(&InfoCardEntry, "IsMeter", true);
			}
			GFxUtilities::SetGFxValue(&InfoCardEntry, "showAsPercent", true);

			InfoObj->PushBack(&InfoCardEntry);
		}
		else
		{
			ItemCard::ChangePACondition(InfoObj, root, "$health", Value, isExamineMenu);
		}

		break;
	}

	case kFormType_WEAP: 
	{
		ExtraDataList* extraDataList = InventoryUtils::GetExtraDataListByStackID(Item, StackID);
		if (!extraDataList)
		{
			return;
		}

		WeaponConditionData Data(Item->form, extraDataList);
		Data.actor = GetPlayer();
		TESObjectWEAP* baseWPNForm = DYNAMIC_CAST(Data.Form, TESForm, TESObjectWEAP);

		float Value = GetWeaponConditionPercent(Data);

		if (Value == -1.0)
		{
			// No condition, try setting up.
			InitializeWeaponCondition(Data);

			Value = GetWeaponConditionPercent(Data);

			if (Value == -1.0)
			{
				// Weapon condition is not setup for this weapon, ignore.
				return;
			}
		}

		float weapDamage = WPNUtilities::GetWeaponDamage(Data);
		float baseValue = baseWPNForm->weapData.value;
		float weapValue = (baseValue * (pow(Value, 1.5)));

		//	Ignore Grenades and Mines
		if (baseWPNForm->weapData.unk137 == kWeaponType_Grenade || baseWPNForm->weapData.unk137 == kWeaponType_Mine)
		{
			return;
		}

		ItemCard::UpdateWeaponValue(InfoObj, root, "$dmg", weapDamage);
		if (isExamineMenu)
		{
			ItemCard::UpdateWeaponValue(InfoObj, root, "$val", weapValue);
		}

		if (Value == -1)
		{
			return;
		}
		else
		{
			Value = (Value * 100);
		}

		GFxValue InfoCardEntry;
		root->CreateObject(&InfoCardEntry);

		if (!isExamineMenu)
		{
			GFxUtilities::SetGFxValue(&InfoCardEntry, root, "text", "$F4CW_CND_PERCENT");
		}
		else
		{
			GFxUtilities::SetGFxValue(&InfoCardEntry, root, "text", "$F4CW_Condition_Percent");
		}

		GFxUtilities::SetGFxValue(&InfoCardEntry, "value", Value);
		GFxUtilities::SetGFxValue(&InfoCardEntry, "max", 100.0);
		if (!bShowConditionNumbers)
		{
			GFxUtilities::SetGFxValue(&InfoCardEntry, "IsMeter", true);
		}

		InfoObj->PushBack(&InfoCardEntry);

		break;
	}

	default:
		break;
	}
}

_PopulateItemCard PopulateItemCard_Original;
void HookPopulateItemCard(void (*hookFunc)(GFxValue*, BGSInventoryItem*, UInt16, InvItemStackList))
{
	struct HookCode : Xbyak::CodeGenerator
	{
		HookCode(void* buf) : Xbyak::CodeGenerator(4096, buf)
		{
			Xbyak::Label retnLabel;

			mov(rax, rsp);
			mov(ptr[rax + 0x20], r9);

			jmp(ptr[rip + retnLabel]);

			L(retnLabel);
			dq(PopulateItemCard.GetUIntPtr() + 7);
		}
	};

	void* codeBuf = g_localTrampoline.StartAlloc();
	HookCode code(codeBuf);
	g_localTrampoline.EndAlloc(code.getCurr());

	PopulateItemCard_Original = (_PopulateItemCard)codeBuf;
	g_branchTrampoline.Write6Branch(PopulateItemCard.GetUIntPtr(), (uintptr_t)hookFunc);
}

void PopulateItemCard_Hook(GFxValue* InfoObj, BGSInventoryItem* Item, UInt16 StackID, InvItemStackList CompareList) 
{
	PopulateItemCard_Original(InfoObj, Item, StackID, CompareList);

	if (InfoObj->GetType() == GFxValue::kType_Object) 
	{
		GFxValue ItemCardInfoList;
		InfoObj->GetMember("ItemCardInfoList", &ItemCardInfoList);
		PopulateItemCard_Custom(&ItemCardInfoList, Item, StackID, CompareList);
	}
	else 
	{
		PopulateItemCard_Custom(InfoObj, Item, StackID, CompareList);
	}
}