#include "f4se/BSParticleShaderEmitter.h"
