#include "f4se/NiMaterials.h"

// 84348FDD81710405CBC1A9C84103811EF7BF8394+3E
RelocAddr <_CreateShaderMaterialByType> CreateShaderMaterialByType(0x02826CB0);

RelocAddr <_LoadMaterialFile> LoadMaterialFile(0x01C9D170);
