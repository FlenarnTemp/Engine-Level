#pragma once

struct StaticFunctionTag;
class VirtualMachine;

namespace papyrusObjectMod
{
	void RegisterFuncs(VirtualMachine* vm);
}
