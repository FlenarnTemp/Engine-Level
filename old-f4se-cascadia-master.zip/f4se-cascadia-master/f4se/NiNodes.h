#pragma once

#include "f4se/NiObjects.h"
#include "f4se/BSLight.h"

// 140
class NiNode : public NiAVObject
{
public:
	virtual void	Unk_39(void);
	virtual void	AttachChild(NiAVObject * obj, bool firstAvail);
	virtual void	InsertChildAt(UInt32 index, NiAVObject * obj);
	virtual void	DetachChild(NiAVObject * obj, NiPointer<NiAVObject> & out);
	virtual void	RemoveChild(NiAVObject * obj);
	virtual void	DetachChildAt(UInt32 i, NiPointer<NiAVObject> & out);
	virtual void	RemoveChildAt(UInt32 i);
	virtual void	SetAt(UInt32 index, NiAVObject * obj, NiPointer<NiAVObject> & replaced);
	virtual void	SetAt(UInt32 index, NiAVObject * obj);
	virtual void	Unk_42(void);

	NiTArray <NiAVObject *>	m_children;	// 120
	float					unk138;
	float					unk13C;

	static NiNode * Create(UInt16 children = 0);

	MEMBER_FN_PREFIX(NiNode);
	DEFINE_MEMBER_FN(ctor, NiNode*, 0x01B98920, UInt16 children);
};
STATIC_ASSERT(sizeof(NiNode) == 0x140);

// 1C0
class BSFadeNode : public NiNode
{
public:
	virtual ~BSFadeNode();

	struct FlattenedGeometryData
	{
		NiBound					kBound;		// 00
		NiPointer<BSGeometry>	spGeometry;	// 10
		UInt32					uiFlags;	// 18
	};

	BSShaderPropertyLightData		kLightData;					// 140
	tArray<FlattenedGeometryData*>	kGeomArray;					// 168
	tArray<NiBound>					MergedGeomBoundsA;			// 180
	float							fNearDistSqr;				// 198
	float							fFarDistSqr;				// 19C
	float							fCurrentFade;				// 1A0
	float							fCurrentDecalFade;			// 1A4
	float							fBoundRadius;				// 1A8
	float							fTimeSinceUpdate;			// 1AC
	SInt32							iFrameCounter;				// 1B0
	float							fPreviousMaxA;				// 1B4
	float							fCurrentShaderLODLevel;		// 1B8
	float							fPreviousShaderLODLevel;	// 1BC
};

// 190
class BSFaceGenNiNode : public NiNode
{
public:
	UInt64	unk140[(0x178 - 0x140) >> 3];	// 140
	UInt32	unk178;							// 178

	// 1FA2A8F9E63D0F771FC6A9BAB875E88A9215810B
	enum
	{
		kFlag_UpdateModel	= (1 << 0),
		kFlag_Unk1			= (1 << 7),
		kFlag_Unk2			= (1 << 8)
	};

	UInt32					flags;			// 17C
	UInt64					unk180;			// 180
	UInt64					unk188;			// 188
};

#include "directxmath.h"

//	380
class ShadowSceneNode : public NiNode
{
public:
	enum eChildNodes
	{
		SSN_CHILDNODE_DEBUG = 0x0,
		SSN_CHILDNODE_SKY = 0x1,
		SSN_CHILDNODE_WEATHER = 0x2,
		SSN_CHILDNODE_LOD = 0x3,
		SSN_CHILDNODE_OBJECTLOD = 0x4,
		SSN_CHILDNODE_NAVMESH = 0x5,
		SSN_CHILDNODE_SANDBOX = 0x6,
		SSN_CHILDNODE_MPS = 0x7,
		SSN_CHILDNODE_GRASS = 0x8,
		SSN_CHILDNODE_PARTICLE_SHADER = 0x9,
		SSN_CHILDNODE_MULTIBOUND = 0xA,
		SSN_CHILDNODE_PORTALSHARED = 0xB,
		SSN_CHILDNODE_NVIDIA_FLEX_DEBRIS = 0xC,
		SSN_CHILDNODE_COUNT = 0xD,
	};

	bool						bFrustrumAddedToVis;		//	140
	UInt8						pad141[(0x144 - 0x141)];	//	141
	float						fStoredFarClip;				//	144
	UInt32						uiVisibleNonShadowLights;	//	148
	UInt32						uiVisibleShadowLights;		//	14C
	UInt32						uiVisibleAmbientLights;		//	150
	UInt8						pad154[(0x158 - 0x154)];	//	154
	tArray<BSLight>				lLightList;					//	158
	tArray<BSLight>				lShadowLightList;			//	170
	tArray<BSLight>				lAmbientLightList;			//	188
	tArray<BSLight>				lLightQueueAdd;				//	1A0
	tArray<BSLight>				lLightQueueRemove;			//	1B8
	UInt8						SSNLightQueueCrit[(0x1D8 - 0x1D0)];			//	1D0 - supposed to be BSSpinLock (size of 8) but isnt reverse engineered yet
	UInt8						DecalList[(0x1F0 - 0x1D8)];					//	1D8 - supposed to be tArray<NiPointer<BSDefferedDecal::BSDFDecal>> but isnt reverse engineered yet
	BSNonReentrantSpinLock		DecalListLock;				//	1F0
	UInt8						pad1F4[(0x1F8 - 0x1F4)];	//	1F4
	BSLight* pSunLight;				//	1F8
	BSLight* pCloudSunLight;			//	200
	UInt8						pSunShadowLight[(0x210 - 0x208)];			//	208	-	supposed to be BSShadowDirectionalLight but isnt reverse engineered yet
	BSLight* pLocalSunLight;			//	210
	NiPoint3					AverageLightPos;			//	218
	char						cSceneGraphIndex;			//	224
	bool						bDisableLightUpdate;		//	225
	bool						bWireframe;					//	226
	bool						bOpaqueWireframe;			//	227
	bool						bAlwaysUpdateLights;		//	228
	UInt8						pad229[(0x230 - 0x229)];	//	229
	UInt8						spFog[(0x238 - 0x230)];						//	230 - supposed to be NiPointer<BSFogProperty> but isnt reverse engineered yet
	BSPortalGraph* pBSPortalGraph;			//	238
	UInt8						lShadowLightAccum[(0x258 - 0x240)];			//	240 - supposed to be tArray<BSShadowLight*> but isnt reverse engineered yet
	UInt32						ui1stPersonShadowMask;		//	258
	DirectX::XMFLOAT4X4			kPrevViewProjTransform[2];	//	25C
	NiPoint3					kPrevViewTranslate[2];		//	2DC
	UInt32						uiPrevTransformIndex;		//	2F4
	float						fWorldWetnessLevel;			//	2F8
	float						fWorldRainLevel;			//	2FC
	float						fForceWetness;				//	300
	NiPoint3					kLightingOffset;			//	304
	NiPoint3					kEyePosition;				//	310
	bool						bAllowLightRemoveQueues;	//	31C
	UInt8						pad31D[(0x320 - 0x31D)];	//	31D
	NiPointer<NiTexture>		spWetnessEnvMap;			//	320
	NiPointer<BSMultiBoundNode>	spSeletectedMultiBound;		//	328
	tArray<NiPointer<BSLight>>	lTestLights;				//	330
	NiPointer<NiNode>			spDebugNode;				//	348
	int							iEnableDebugGeometry;		//	350
	UInt8						pad354[(0x358 - 0x354)];	//	354
	NiPointer<NiCamera>			spFrozenCamera;				//	358
	const NiCamera* spRestoreCamera;			//	360
	UInt8						spTestCloud[(0x370 - 0x368)];			//	368 - supposed to be NiPointer<BSMultiStreamInstanceTriShape> but isnt reverse engineered yet
	UInt32						kTestCloudHandle;			//	370
	bool						bUnlitPreviewMode;			//	374
	UInt8						pad375[(0x378 - 0x375)];	//	375
	float						fWindMagnitude;				//	378
	UInt8						pad37C[(0x380 - 0x37C)];	//	37C
};
