#pragma once

struct StaticFunctionTag;
class VirtualMachine;

namespace papyrusWeapon
{
	void RegisterFuncs(VirtualMachine* vm);
}
