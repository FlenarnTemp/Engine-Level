#include "ObScript.h"

// 61A506FAB79EC111F852CE23E1E7A87D3E195A1B+43
RelocPtr <ObScriptCommand>	g_firstObScriptCommand(0x036F6DD0);
// 61A506FAB79EC111F852CE23E1E7A87D3E195A1B+1A
RelocPtr <ObScriptCommand>	g_firstConsoleCommand(0x03706DC0);
