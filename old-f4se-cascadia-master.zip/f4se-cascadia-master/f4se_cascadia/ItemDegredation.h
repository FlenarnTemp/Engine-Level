#pragma once
#include "main.h"
#include "Scaleform.h"

#include "f4se/GameExtraData.h"
#include "f4se/GameFormComponents.h"
#include "f4se/GameObjects.h"

#pragma warning(default:4716)

/*
template<typename EventT>
BSTEventDispatcher<EventT>* GetSingletonEventDispatcher_Internal() { };

#define DECLARE_SINGLETON_EVENT_DISPATCHER(Event, address)\
template<> inline BSTEventDispatcher<Event>* GetSingletonEventDispatcher_Internal(){\
    typedef BSTEventDispatcher<Event>* (_GetSingletonEventDispatcher_Internal);\
    RelocAddr <_GetSingletonEventDispatcher_Internal> GetDispatcher(address);\
    return GetDispatcher;\
}
*/

#include "f4se/GameExtraData.h"

struct ExtraReferenceHandles : public BSExtraData
{
	TESObjectREFR* hOriginalRef;
	TESObjectREFR* hContainerRef;
};

#define DECLARE_EVENT_CLASS(Event)\
class Event##Handler : public BSTEventSink<Event> {\
public:\
    virtual ~Event##Handler() { };\
    virtual	EventResult	ReceiveEvent(Event* evn, void* dispatcher) override;\
};\
extern Event##Handler g_##Event##Handler

//#define GetSingletonEventDispatcher(Event) (*GetSingletonEventDispatcher_Internal<Event>())

//	Weapon Condition Struct
struct WeaponConditionData {
	WeaponConditionData();
	WeaponConditionData(TESForm* form, ExtraDataList* extradata);
	WeaponConditionData(Actor* myActor, TESForm* form, ExtraDataList* extradata);
	WeaponConditionData(TESObjectREFR* refr);
	WeaponConditionData(Actor* actor);

	Actor*							actor;
	TESForm*						Form;
	ExtraDataList*					extraData;
	TESObjectWEAP::InstanceData*	instance;
	UInt64							invHandle;
};

//	Armor Condition Struct
struct ArmorConditionData {
	ArmorConditionData();
	ArmorConditionData(TESForm* form, ExtraDataList* extradata);
	ArmorConditionData(Actor* myActor, TESForm* form, ExtraDataList* extradata);
	ArmorConditionData(TESObjectREFR* refr);
	ArmorConditionData(Actor* actor);

	Actor*							actor;
	TESForm*						Form;
	ExtraDataList*					extraData;
	TESObjectARMO::InstanceData*	instance;
};

//	This enum correlates with TESObjectWEAP's unk137
//	See GameObjects.h
enum WeaponTypes {
	kWeaponType_HandToHandMelee = 0,
	kWeaponType_OneHandSword,
	kWeaponType_OneHandDagger,
	kWeaponType_OneHandAxe,
	kWeaponType_OneHandMace,
	kWeaponType_TwoHandSword,
	kWeaponType_TwoHandAxe,
	kWeaponType_Bow,
	kWeaponType_Staff,
	kWeaponType_Gun,
	kWeaponType_Grenade,
	kWeaponType_Mine
};

//	TESObjectWEAP::InstanceData flags
//	See GameObjects.h
enum WeaponFlags {
	kFlag_IgnoresNormalResist = 0x0000002,
	kFlag_MinorCrime = 0x0000004,
	kFlag_ChargingReload = 0x0000008,
	kFlag_HideBackpack = 0x0000010,
	kFlag_NonHostile = 0x0000040,
	kFlag_NPCsUseAmmo = 0x0000200,
	kFlag_RepeatableSingleFire = 0x0000800,
	kFlag_HasScope = 0x0001000,
	kFlag_HoldInputToPower = 0x0002000,
	kFlag_Automatic = 0x0004000,
	kFlag_CantDrop = 0x0008000,
	kFlag_ChargingAttack = 0x0010000,
	kFlag_NotUsedInNormalCombat = 0x0020000,
	kFlag_BoundWeapon = 0x0040000,
	kFlag_SecondaryWeapon = 0x0200000,
	kFlag_BoltAction = 0x0400000,
	kFlag_NoJamAfterReload = 0x0800000,
	kFlag_DisableShells = 0x1000000,
};

struct ArmorDegrade
{
	float fDamageDealt;
	bool isMelee;
};

//=========================================================================================================================
//	Function Declarations

namespace WPNUtilities {
	void UpdateHUDCondition(WeaponConditionData myConditionData);
	float CalculateSkillBonusFromActor(WeaponConditionData myConditionData);
	float CalculateUpdatedDamageValue(float baseDamage, float minimum, float conditionPercent, float skillBonus);
	void UpdateWeaponStats(WeaponConditionData myConditionData);
	float GetWeaponDamage(WeaponConditionData myConditionData);
	TESForm* GetEquippedWeaponForm(Actor* actor);
	UInt64 GetEquippedWeaponHandleID(Actor* actor);
	TESObjectWEAP::InstanceData* GetEquippedWeaponInstanceData(Actor* actor);
	ExtraDataList* GetEquippedWeaponExtraData(Actor* actor);
	void UnequipWeapon(Actor* actor);
	TESObjectWEAP::InstanceData* CastInstanceData(TBO_InstanceData* myInstanceData);
	float CalculateUpdatedRateOfFireValue(WeaponConditionData myConditionData, float currentCondition);
}

namespace ARMOUtilities {
	BGSKeyword* GetPowerArmorTypeKeyword();
	void UpdateArmorStats(ArmorConditionData myConditionData);
	void UpdateArmorStatsOnHit(Actor* actor, UInt32 eDamageLimb, UInt32 eIncomingDamageType, float fDamage);
}

TESObjectWEAP::InstanceData* GetWeaponInstanceData(ExtraDataList* myExtraDataList);
TESObjectARMO::InstanceData* GetArmorInstanceData(ExtraDataList* myExtraDataList);

float GetWeaponConditionMaximum(WeaponConditionData Data);
float GetWeaponConditionMaximum(TESObjectREFR* refr);
float GetWeaponConditionPercent(WeaponConditionData Data);
float GetWeaponConditionPercent(TESObjectREFR* refr);
float GetWeaponConditionCurrent(WeaponConditionData Data);
float GetWeaponConditionCurrent(TESObjectREFR* refr);

void SetWeaponConditionMaximum(WeaponConditionData Data, float Value);
void SetWeaponConditionMaximum(TESObjectREFR* refr, float Value);
void SetWeaponConditionPercent(WeaponConditionData Data, float Value);
void SetWeaponConditionPercent(TESObjectREFR* refr, float Value);
void SetWeaponConditionCurrent(WeaponConditionData Data, float Value);
void SetWeaponConditionCurrent(TESObjectREFR* refr, float Value);

float GetArmorConditionMaximum(ArmorConditionData Data);
float GetArmorConditionMaximum(TESObjectREFR* refr);
float GetArmorConditionPercent(ArmorConditionData Data);
float GetArmorConditionPercent(TESObjectREFR* refr);
float GetArmorConditionCurrent(ArmorConditionData Data);
float GetArmorConditionCurrent(TESObjectREFR* refr);

void SetArmorConditionMaximum(ArmorConditionData Data, float Value);
void SetArmorConditionMaximum(TESObjectREFR* refr, float Value);
void SetArmorConditionPercent(ArmorConditionData Data, float Value);
void SetArmorConditionPercent(TESObjectREFR* refr, float Value);
void SetArmorConditionCurrent(ArmorConditionData Data, float Value);
void SetArmorConditionCurrent(TESObjectREFR* refr, float Value);

void ModWeaponCondition(WeaponConditionData Data, float Value);
void ModWeaponCondition(TESObjectREFR* refr, float Value);
void ModWeaponCondition(Actor* actor);

void InitializeWeaponCondition(WeaponConditionData myConditionData);
void InitializeWeaponCondition(TESObjectREFR* myRef);

void InitializeArmorCondition(ArmorConditionData myConditionData);
void InitializeArmorCondition(TESObjectREFR* myRef);

void InitializeInventoryItemCondition(TESObjectREFR* myRef, TESForm* myForm);
void InitializeInventoryCondition(TESObjectREFR* myRef);
void InitializePowerArmorFrameInventoryCondition(TESObjectREFR* ref);

tArray<BGSMod::Attachment::Mod*> GetAllAttachedObjectMods(ArmorConditionData armorData);
tArray<BGSMod::Attachment::Mod*> GetAllAttachedObjectMods(WeaponConditionData weaponData);

void ItemDegredation_ItemEquipped(TESEquipEvent* myEvent);

void CheckForNPCWeaponConditionPerk(TESObjectREFR* myRef);

void GetItemDegredationFormsFromGame();

bool RegisterDegredationFunctions(VirtualMachine* vm);