﻿//==============================================================================================================================================
//															Fallout 4 Cascadia Main F4SE Plugin
//											  Made by HcGxGrill, expanded and modified by Flenarn
//==============================================================================================================================================

// Internal Includes
#include "main.h"
#include "LevelUpMenu.h"
#include "MenuAdditions.h"
#include "common/ICriticalSection.h"
#include "AmmoSwitch.h"


//	Variables
//=========================================================================================================================
PluginHandle g_pluginHandle = kPluginHandle_Invalid;	//Plugin Handle

//Interface variables
static F4SEPapyrusInterface* g_papyrusInterface = 0;
static F4SEMessagingInterface* g_messagingInterface = 0;
static F4SEScaleformInterface* g_scaleformInterface = 0;
static F4SESerializationInterface* g_serializationInterface = 0;

ICriticalSection g_criticalSection;
AmmoSwitch::AmmoSwitchValues_Struct AmmoSwitchValues;

//=========================================================================================================================
//	Animation Graph Event Hook
//=========================================================================================================================

class BSAnimationGraphEvent
{
public:
	UInt64			uiHolderIDC;	//00 - not sure what this is?
	BSFixedString	eventTag;		//08 - Event sent to graph (eg. "weaponFire")
	BSFixedString	eventPayload;	//10 - Payload (if any) sent with event (eg. for "SoundPlay.WPNSound" the eventTag would be "SoundPlay" and eventPayload would be "WPNSound")
};

typedef UInt8(*_animGraphEvent)(void* eventSink, BSAnimationGraphEvent* evn, void** dispatcher);
RelocAddr <_animGraphEvent> animGraph_Hook(0x02D442E0);
_animGraphEvent animGraphEvent_Original;

UInt8 PlayerAnimationGraphEvent(void* eventSink, BSAnimationGraphEvent* evn, void** dispatcher) {
	const char* evnTag = evn->eventTag.c_str();
	const char* evnPayload = evn->eventPayload.c_str();

	if (!strcmp(evnTag, "WeaponFire") || !strcmp(evnTag, "weaponFire")) {
		if (WPNUtilities::GetEquippedWeaponForm(GetPlayer())) {
			if (strcmp(evnPayload, "")) {
				//	Throwing Grenade/Mine, ignore event
				TraceLog("Player used Grenade / Mine");
				return animGraphEvent_Original(eventSink, evn, dispatcher);
			}

			TraceLog("Player used Ranged Weapon");
			ModWeaponCondition(GetPlayer());
		}
	}
	else if (!strcmp(evnTag, "HitFrame")) {
		if (WPNUtilities::GetEquippedWeaponForm(GetPlayer())) {
			TraceLog("Player used Melee/Unarmed Weapon");
			ModWeaponCondition(GetPlayer());
		}
	}
	else if (!strcmp(evnTag, "ReloadEnd") || !strcmp(evnTag, "reloadEnd")) {
		TraceLog("ReloadEnd");
		if (AmmoSwitch::AmmoSwitchValues.isCurrentlySwitching) {
			AmmoSwitch::AmmoSwitchValues.isCurrentlySwitching = false;
		}
	}

	return animGraphEvent_Original(eventSink, evn, dispatcher);
}

//=========================================================================================================================
// Functions
//=========================================================================================================================

bool RegisterFuncs(VirtualMachine* vm) {
	RegisterConsoleCommandFuncs(vm);
	RegisterSkillFuncs(vm);
	LevelUpMenu::RegisterFunctions(vm);
	RegisterSharedFunctions(vm);
	RegisterDegredationFunctions(vm);
	return true;
}

bool GetAllINISettings() {
	Pipboy::GetINIOptions();
	LevelUpMenu::GetINIOptions();

	return true;
}

bool GameDataReadyCallback() {
	_MESSAGE("GameDataReadyCallback");

	Events::RegisterForEvents();
	AmmoSwitch::RegisterForInput(true);

	Scaleform::RegisterCustomMenus();
	if (DefineSkillFormsFromGame()) {
		Skills::RegisterForSkillLink();
	}
	LevelUpMenu::GetLevelUpFormsFromGame();
	GetItemDegredationFormsFromGame();

	GetAllINISettings();

	return true;
}

//	Returns True if FalloutCascadia.esm is enabled
bool IsCascadiaInstalled() {
	bool result = false;

	for (auto i = 0; i < (*g_dataHandler)->modList.loadedMods.count; i++) {
		ModInfo* modInfo = (*g_dataHandler)->modList.loadedMods[i];
		if (strcmp(modInfo->name, "FalloutCascadia.esm")) {
			result = true;
		}
	}

	return result;
}

static void F4SEMessageCallback(F4SEMessagingInterface::Message* myMessage) {
	switch (myMessage->type) {
	case(F4SEMessagingInterface::kMessage_GameDataReady):
		GameDataReadyCallback();
		break;
	case(F4SEMessagingInterface::kMessage_GameLoaded):
		break;
	case(F4SEMessagingInterface::kMessage_PostLoadGame):
		//AmmoSwitch::ResetToCoreAmmo();
		break;
	default:
		break;
	}
}
//=========================================================================================================================

//Plugin Manager Code
extern "C" {

	//F4SE Query Manager
	//=========================================================================================================================
	bool F4SEPlugin_Query(const F4SEInterface* a_f4se, PluginInfo* a_info)
	{
		//Initialise Log
		gLog.OpenRelative(CSIDL_MYDOCUMENTS, "\\My Games\\Fallout4\\F4SE\\CASMain.log");
		gLog.SetPrintLevel(IDebugLog::kLevel_DebugMessage);
		gLog.SetLogLevel(IDebugLog::kLevel_DebugMessage);

		//Initialise Plugin Log Message
		_MESSAGE("Initialising CAS Main v%s", F4CW_VERSION_VERSTRING);

		//Set Version information
		a_info->infoVersion = PluginInfo::kInfoVersion;
		a_info->name = "CAS Main";
		a_info->version = F4CW_VERSION_MAJOR;

		//Store Plugin Handle
		g_pluginHandle = a_f4se->GetPluginHandle();

		//if loading into CK
		if (a_f4se->isEditor) {

			_MESSAGE("CAS Main loaded in Creation Kit. Disabling plugin.\n");
			return false;

		} 
		//if game doesn't match current F4SE build target, error and show message box.
		else if (a_f4se->runtimeVersion != CURRENT_RELEASE_RUNTIME) {
			
			//Show Error Message Box
			char ErrorString[512];
			sprintf_s(ErrorString, sizeof(ErrorString), "Current Fallout 4 Version: %d.%d.%d.%d\nExpected Fallout 4 Version: %d\n%s will be disabled.",
				GET_EXE_VERSION_MAJOR(a_f4se->runtimeVersion),
				GET_EXE_VERSION_MINOR(a_f4se->runtimeVersion),
				GET_EXE_VERSION_BUILD(a_f4se->runtimeVersion),
				GET_EXE_VERSION_SUB(a_f4se->runtimeVersion),
				CURRENT_RELEASE_RUNTIME,
				"F4CW Main"
			);
			MessageBox(NULL, ErrorString, "CAS Main", MB_OK | MB_ICONEXCLAMATION);
			return false;
		}

		//Query Messaging interface, if fail throw fatal error
		g_messagingInterface = (F4SEMessagingInterface*)a_f4se->QueryInterface(kInterface_Messaging);
		if (!g_messagingInterface) {
			_FATALERROR("CASMain: Couldn't get F4SE Messaging Interface.");
			return false;
		}

		//Query Scaleform interface, if fail throw fatal error
		g_scaleformInterface = (F4SEScaleformInterface*)a_f4se->QueryInterface(kInterface_Scaleform);
		if (!g_scaleformInterface) {
			_FATALERROR("CASMain: Couldn't get F4SE Scaleform Interface.");
			return false;
		}

		//Query Serialization interface, if fail throw fatal error
		g_serializationInterface = (F4SESerializationInterface*)a_f4se->QueryInterface(kInterface_Serialization);
		if (!g_serializationInterface) {
			_FATALERROR("CASMain: Couldn't get F4SE Serialization Interface.");
			return false;
		}

		//Create Branch Trampoline
		if (!g_branchTrampoline.Create(1024 * 64)){
			_FATALERROR("CASMain: Failed to create Branch Trampoline.");
			return false;
		}

		//Create Local Trampoline (CodeGen Buffer)
		if (!g_localTrampoline.Create(1024 * 64, nullptr)){
			_FATALERROR("CASMain: Failed to create CodeGen Buffer.");
			return false;
		}

		if (!IObScript::Init()) {
			_MESSAGE("CASMain: Couldn't get ObScript Interface.");
			return false;
		}

		return true;
	}
	//=========================================================================================================================
	
	//F4SE Plugin Load Manager
	//=========================================================================================================================
	bool F4SEPlugin_Load(const F4SEInterface* a_f4se){
		_MESSAGE("Loading CAS Main Plugin");

		g_serializationInterface->SetUniqueID(g_pluginHandle, 'CAS');
		g_serializationInterface->SetRevertCallback(g_pluginHandle, CASSerialization::RevertCallback);
		g_serializationInterface->SetLoadCallback(g_pluginHandle, CASSerialization::LoadCallback);
		g_serializationInterface->SetSaveCallback(g_pluginHandle, CASSerialization::SaveCallback);

		//Query Interfaces
		g_papyrusInterface = static_cast<F4SEPapyrusInterface*>(a_f4se->QueryInterface(kInterface_Papyrus));

		//If for some reason Papyrus interface fails to query
		if (!g_papyrusInterface) {
			_MESSAGE("CAS Main: Unable to hook Papyrus.");
			return false;
		}

		//If for some reason Papyrus functions fail to register
		else if (!g_papyrusInterface->Register(RegisterFuncs)) {
			_MESSAGE("CAS Main: Unable to register Papyrus Functions.");
			return false;
		}

		//Messaging Interface
		if (g_messagingInterface != 0) {
			g_messagingInterface->RegisterListener(g_pluginHandle, "F4SE", F4SEMessageCallback);
		}

		//Scaleform Interface
		if (g_scaleformInterface != 0) {
			g_scaleformInterface->Register("CASMain", Scaleform::RegisterScaleform);
		}

		//ObScript Functions
		if (!ObScript::Init()) {
			_MESSAGE("CAS Main: Unable to register ObScript functions.");
			return false;
		}

		//Init & Update RVA Addresses
		InitSharedAddresses();
		LevelUpMenu::InitAddresses();
		Events::InitAddresses();
		ObScriptNS::InitAddresses();
		Scaleform::InitAddresses();
		RVAManager::UpdateAddresses(a_f4se->runtimeVersion);

		//Hook Pipboy/Item Menu Functions
		HookPipboyMenuInvoke(PipboyMenuInvoke_Hook);
		HookPopulateItemCard(PopulateItemCard_Hook);

		//Hook Animation Graph Event
		animGraphEvent_Original = HookUtil::SafeWrite64(animGraph_Hook.GetUIntPtr(), &PlayerAnimationGraphEvent);

		//Successfully loaded :)
		_MESSAGE("CAS Main Loaded Successfully");

		return true;
	}
	//=========================================================================================================================
};
