#pragma once

#include "IObScript.h"
#include "Skills.h"

typedef bool (*_ExtractArgs) (void* paramInfo, void* scriptData, void* opcodeOffset, TESObjectREFR* thisObj, void* containingObj, void* script, void* eventList, ...);

#define INFO_SIZE 0x7FFF
#define TIMESTAMP "%m/%d/%Y (%I:%M)"

DEFINE_CMD_EVAL_FULL(GetPermanentValue, , , 1, kParams_OneActorValue);
DEFINE_CMD_FULL(BetaComment, bc, , 0, kParams_OneString);

namespace ObScript {
    bool Init();
    bool Init_BetaComment();
}

namespace ObScriptNS
{
    void InitAddresses();
}