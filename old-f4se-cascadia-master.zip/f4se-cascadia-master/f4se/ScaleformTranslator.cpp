#include "f4se/ScaleformTranslator.h"

// E33FAE94A9BB57E033DF51B26B8EC718FD4FAA35+3B
RelocAddr <_CreateEmptyString> CreateEmptyString(0x01B42AC0);
// E33FAE94A9BB57E033DF51B26B8EC718FD4FAA35+73
RelocAddr <_SetWideString> SetWideString(0x01B42C10);
