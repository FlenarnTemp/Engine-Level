#include "f4se/ScaleformLoader.h"

// 7A4A1713A39F72AA5098850E74E38B4655E445AF+4D
RelocPtr <BSScaleformManager *> g_scaleformManager(0x058DE410);
