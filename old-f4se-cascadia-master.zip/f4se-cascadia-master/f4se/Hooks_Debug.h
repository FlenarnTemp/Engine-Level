#pragma once

void Hooks_Debug_Init();
void Hooks_Debug_Commit();
