#pragma once

struct StaticFunctionTag;
class VirtualMachine;

namespace papyrusComponent
{
	void RegisterFuncs(VirtualMachine* vm);
}
