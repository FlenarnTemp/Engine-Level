#include "Skills.h"

#define LookupTypeByID(id, to) ( ## to *) Runtime_DynamicCast((void*)(LookupFormByID(id)), RTTI_TESForm, RTTI_ ## to)
#define LookupTypeFromPlugin(id, to) ( ## to *) Runtime_DynamicCast((void*)(LookupFormFromPlugin(id)), RTTI_TESForm, RTTI_ ## to)
//#define GetFormID(id, name) g_Settings.GetInteger(## name ##, ## id ##)

//RelocAddr <uintptr_t> ActorValueDerivedVtbl(0x2CEDBC8);	1.10.138
RelocAddr <uintptr_t> ActorValueDerivedVtbl(0x02CEDC58);		//confirmed 1.10.163
// ActorValue AVOwner*, AVInfo&

//RelocAddr <uintptr_t> ActorValueCalcVtbl(0x2CEDC08);	1.10.138
RelocAddr <uintptr_t> ActorValueCalcVtbl(0x02CEDC98);	//confirmed 1.10.163
// ActorValue Actor*, AVInfo&, float, float, Actor*

class ActorValueInfo;

VanillaAV_Struct				VanillaActorValues;
CascadiaAV_Struct				CASActorValues;
CascadiaPerks_Struct			CASPerks;
CascadiaGlobals_Struct			CWGlobals;

/*
	Fallout New Vegas Calculations:

	Barter				(CHA * 2) + 2 + (LCK / 2)

	Energy Weapons		(PER * 2) + 2 + (LCK / 2)

	Explosives			(PER * 2) + 2 + (LCK / 2)

	Guns				(AGI * 2) + 2 + (LCK / 2)

	Lockpick 			(PER * 2) + 2 + (LCK / 2)

	Medicine 			(INT * 2) + 2 + (LCK / 2)

	Melee Weapons 		(STR * 2) + 2 + (LCK / 2)

	Repair				(INT * 2) + 2 + (LCK / 2)

	Science				(INT * 2) + 2 + (LCK / 2)

	Sneak				(AGI * 2) + 2 + (LCK / 2)

	Speech				(CHA * 2) + 2 + (LCK / 2)

	Survival			(END * 2) + 2 + (LCK / 2)

	Unarmed				(END * 2) + 2 + (LCK / 2)
*/

namespace Skills
{
	//	Most functions in this namespace are based on shad0wshayd3's work on Project Massachusetts
	//	Link: https://github.com/shad0wshayd3/F4SE-dev/tree/master/f4se/f4se_plugins/ProjectMassachusetts
	//	Rewrite Link: https://github.com/shad0wshayd3/F4SE-dev/tree/pm-rewrite

	std::unordered_multimap<ActorValueInfo*, ActorValueInfo*> skillsLinkMap;
	std::unordered_multimap<std::string, ActorValueInfo*> strSkillMap;

	AVVector CASSkillsList;
	PerkVector CASNPCPerksList;
	PerkRankMap RegisteredActors;

	//	Returns ActorValueInfo based on Skill Name
	ActorValueInfo* GetSkillByName(std::string mySkill)
	{
		auto result = strSkillMap.find(mySkill);
		if (result != strSkillMap.end())
		{
			return result->second;
		}

		return nullptr;
	}

	//	Returns Actor Value of given Actor based on Skill Name
	UInt32 GetSkillValueByName(Actor* myActor, std::string mySkill)
	{
		ActorValueInfo* myAV = GetSkillByName(mySkill);

		if (myAV) 
		{
			return myActor->actorValueOwner.GetValue(myAV);
		}
		else
		{
			return -1;
		}

	}

	//	Returns Base Actor Value of given Actor based on Skill Name
	UInt32 GetBaseSkillValueByName(Actor* myActor, std::string mySkill)
	{
		ActorValueInfo* myAV = GetSkillByName(mySkill);

		if (myAV)
		{
			return myActor->actorValueOwner.GetBase(myAV);
		}
		else
		{
			return -1;
		}
	}

	//	Gets given Actor Values Dependant Actor Value (if has none, returns nullptr)
	ActorValueInfo* GetDependantAV(ActorValueInfo* myAV)
	{
		auto result = skillsLinkMap.find(myAV);
		if (result != skillsLinkMap.end())
		{
			return result->second;
		}

		return nullptr;
	}

	//	Adds Dependant AV to given AV
	void AddDependentAV(ActorValueInfo* myAV, ActorValueInfo* dependantAV)
	{
		if (dependantAV->numDependentAVs < sizeof(dependantAV->dependentAVs) / 8)
		{
			dependantAV->dependentAVs[dependantAV->numDependentAVs++] = myAV;
		}
	}

	//	Sets AV as derived
	void RegisterDerivedAV(ActorValueInfo* myAV, float(*f)(ActorValueOwner*, ActorValueInfo&))
	{
		myAV->derived_func_vtable = reinterpret_cast<void*>(ActorValueDerivedVtbl.GetUIntPtr());
		myAV->derived_func_ptr = &myAV->derived_func_vtable;
		myAV->derived_func = f;
	}

	//	Registers AV as Hardcoded and sets what AVs it should update with
	void RegisterLinkedAV(ActorValueInfo* myAV, float(*CalcFunction)(ActorValueOwner*, ActorValueInfo&), ActorValueInfo* av1, ActorValueInfo* av2)
	{
		RegisterDerivedAV(myAV, CalcFunction);
		AddDependentAV(myAV, av1);
		AddDependentAV(myAV, av2);
		skillsLinkMap.emplace(myAV, av1);
	}

	void RegisterCalc(ActorValueInfo* myAV, void(*f)(Actor*, ActorValueInfo&, float, float, Actor*)) 
	{
		myAV->func_vtable = reinterpret_cast<void*>(ActorValueCalcVtbl.GetUIntPtr());
		myAV->func_ptr = &myAV->func_vtable;
		myAV->func = f;
	}

	//	Returns calculation of the offset of the given Skill
	float CalculateSkillOffset(ActorValueOwner* myAVOwner, ActorValueInfo& myAV)
	{
		if (!myAVOwner || !&myAV)
		{
			return 0.0;
		}
		else
		{
			//	(Dependant x 2) + 2 + (Luck / 2)
			return ((myAVOwner->GetValue(GetDependantAV(&myAV)) * 2) + 2 + ceilf(myAVOwner->GetValue(VanillaActorValues.Luck) / 2));
		}
	}

	void RegisterForSkillLink()
	{
		TraceLog("Skills: Linking Skills from FalloutCascadia.esm");

		//	Clear existing maps
		skillsLinkMap.clear();
		strSkillMap.clear();

		//	Link Skills to their SPECIAL skills
		RegisterLinkedAV(CASActorValues.Barter,			CalculateSkillOffset,	VanillaActorValues.Charisma,		VanillaActorValues.Luck);
		RegisterLinkedAV(CASActorValues.EnergyWeapons,	CalculateSkillOffset,	VanillaActorValues.Perception,		VanillaActorValues.Luck);
		RegisterLinkedAV(CASActorValues.Explosives,		CalculateSkillOffset,	VanillaActorValues.Perception,		VanillaActorValues.Luck);
		RegisterLinkedAV(CASActorValues.Guns,			CalculateSkillOffset,	VanillaActorValues.Agility,			VanillaActorValues.Luck);
		RegisterLinkedAV(CASActorValues.Lockpick,		CalculateSkillOffset,	VanillaActorValues.Perception,		VanillaActorValues.Luck);
		RegisterLinkedAV(CASActorValues.Medicine,		CalculateSkillOffset,	VanillaActorValues.Intelligence,	VanillaActorValues.Luck);
		RegisterLinkedAV(CASActorValues.MeleeWeapons,	CalculateSkillOffset,	VanillaActorValues.Strength,		VanillaActorValues.Luck);
		RegisterLinkedAV(CASActorValues.Repair,			CalculateSkillOffset,	VanillaActorValues.Intelligence,	VanillaActorValues.Luck);
		RegisterLinkedAV(CASActorValues.Science,		CalculateSkillOffset,	VanillaActorValues.Intelligence,	VanillaActorValues.Luck);
		RegisterLinkedAV(CASActorValues.Sneak,			CalculateSkillOffset,	VanillaActorValues.Agility,			VanillaActorValues.Luck);
		RegisterLinkedAV(CASActorValues.Speech,			CalculateSkillOffset,	VanillaActorValues.Charisma,		VanillaActorValues.Luck);
		RegisterLinkedAV(CASActorValues.Survival,		CalculateSkillOffset,	VanillaActorValues.Endurance,		VanillaActorValues.Luck);
		RegisterLinkedAV(CASActorValues.Unarmed,		CalculateSkillOffset,	VanillaActorValues.Endurance,		VanillaActorValues.Luck);

		//	Link Karma Global to Karma Skill


		//	Add Skills to array with Strings so we can find them based on name later
		strSkillMap.emplace("Barter",			CASActorValues.Barter);
		strSkillMap.emplace("EnergyWeapons",	CASActorValues.EnergyWeapons);
		strSkillMap.emplace("Explosives",		CASActorValues.Explosives);
		strSkillMap.emplace("Guns",				CASActorValues.Guns);
		strSkillMap.emplace("Lockpick",			CASActorValues.Lockpick);
		strSkillMap.emplace("Medicine",			CASActorValues.Medicine);
		strSkillMap.emplace("MeleeWeapons",		CASActorValues.MeleeWeapons);
		strSkillMap.emplace("Repair",			CASActorValues.Repair);
		strSkillMap.emplace("Science",			CASActorValues.Science);
		strSkillMap.emplace("Sneak",			CASActorValues.Sneak);
		strSkillMap.emplace("Speech",			CASActorValues.Speech);
		strSkillMap.emplace("Survival",			CASActorValues.Survival);
		strSkillMap.emplace("Unarmed",			CASActorValues.Unarmed);

		//	Add AVs to all Races
		tArray<TESRace*> RaceList = (*g_dataHandler)->arrRACE;
		for (int r = 0; r < RaceList.count; r++)
		{
			//	Add Skills
			for (auto skills : CASSkillsList)
			{
				RaceList[r]->propertySheet.sheet->Push({ skills, 0 });
			}
		}

		/*
		// Add Perks to NPCs
		PerkRankVector defaultPerkRanks;
		for (auto iter : CASNPCPerksList)
			defaultPerkRanks.emplace_back(BGSPerkRankArray::Data{ iter, 1 });

		tArray<TESNPC*> NPCList = (*g_dataHandler)->arrNPC_;
		for (int i = 0; i < NPCList.count; i++) {

			TESNPC* thisNPC = NPCList[i];
			RegisteredActors.emplace_back(defaultPerkRanks);

			for (int j = thisNPC->perkRankArray.numPerkRanks - 1; j >= 0; j--)
				RegisteredActors.back().insert(RegisteredActors.back().begin(),
					BGSPerkRankArray::Data{
						thisNPC->perkRankArray.perkRanks[j].perk,
						thisNPC->perkRankArray.perkRanks[j].rank
					});

			thisNPC->perkRankArray.perkRanks = RegisteredActors.back().data();
			thisNPC->perkRankArray.numPerkRanks = RegisteredActors.back().size();
		}
		*/

	}

}

namespace Skills_Papyrus
{
	using namespace Skills;

	//	Returns ActorValue based on Skill Name - Papyrus
	ActorValueInfo* GetSkillByName_Papyrus(StaticFunctionTag*, BSFixedString mySkill)
	{
		return GetSkillByName(mySkill.c_str());
	}

	//	Returns Actor Value of given Actor based on Skill Name - Papyrus
	UInt32 GetSkillValueByName_Papyrus(StaticFunctionTag*, Actor* myActor, BSFixedString mySkill)
	{
		return GetSkillValueByName(myActor, mySkill.c_str());
	}

	//	Returns Base Actor Value of given Actor based on Skill Name - Papyrus
	UInt32 GetBaseSkillValueByName_Papyrus(StaticFunctionTag*, Actor* myActor, BSFixedString mySkill)
	{
		return GetBaseSkillValueByName(myActor, mySkill.c_str());
	}

	void ModPermanentSkillValue_Papyrus(StaticFunctionTag*, TESForm* myForm, ActorValueInfo* myAV, float value)
	{
		ModPermanentSkillValue(myForm, myAV, value);
	}
}

//	Internal Functions
//=========================================================================================================================
float GetAVValue(Actor* myActor, ActorValueInfo* myAV)
{
	float myActorValue;

	if (myActor) 
	{
		myActorValue = myActor->actorValueOwner.GetValue(myAV);
		return myActorValue;
	}

	return NULL;
}

float GetBaseAVValue(Actor* myActor, ActorValueInfo* myAV)
{
	float myActorValue;

	if (myActor) 
	{
		myActorValue = myActor->actorValueOwner.GetBase(myAV);
		return myActorValue;
	}

	return NULL;
}

void ModBaseAVValue(Actor* myActor, ActorValueInfo* myAV, int iModAmount)
{
	myActor->actorValueOwner.ModBase(myAV, iModAmount);
}

void SetBaseAVValue(Actor* myActor, ActorValueInfo* myAV, int iSetAmount)
{
	myActor->actorValueOwner.SetBase(myAV, iSetAmount);
}

float GetPlayerAVValue(ActorValueInfo* myAV)
{
	return GetAVValue(GetPlayer(), myAV);
}

float GetPlayerBaseAVValue(ActorValueInfo* myAV)
{
	return GetBaseAVValue(GetPlayer(), myAV);
}

void ModPlayerBaseAVValue(ActorValueInfo* myAV, int iModAmount)
{
	ModBaseAVValue(GetPlayer(), myAV, iModAmount);
}

void SetPlayerBaseAVValue(ActorValueInfo* myAV, int iSetAmount)
{
	SetBaseAVValue(GetPlayer(), myAV, iSetAmount);
}

bool DefineSkillFormsFromGame()
{
	TraceLog("Skills: Defining Skill Forms From FalloutCascadia.esm");

	//	Vanilla Actor Values
	VanillaActorValues.Strength		= LookupTypeByID(StrengthID, ActorValueInfo);
	VanillaActorValues.Perception	= LookupTypeByID(PerceptionID, ActorValueInfo);
	VanillaActorValues.Endurance	= LookupTypeByID(EnduranceID, ActorValueInfo);
	VanillaActorValues.Charisma		= LookupTypeByID(CharismaID, ActorValueInfo);
	VanillaActorValues.Intelligence = LookupTypeByID(IntelligenceID, ActorValueInfo);
	VanillaActorValues.Agility		= LookupTypeByID(AgilityID, ActorValueInfo);
	VanillaActorValues.Luck			= LookupTypeByID(LuckID, ActorValueInfo);

	//	Cascadia Actor Values
	CASActorValues.Barter			= reinterpret_cast<ActorValueInfo*>(GetFormFromIdentifier("FalloutCascadia.esm|F35ED"));
	CASActorValues.EnergyWeapons	= reinterpret_cast<ActorValueInfo*>(GetFormFromIdentifier("FalloutCascadia.esm|F35EE"));
	CASActorValues.Explosives		= reinterpret_cast<ActorValueInfo*>(GetFormFromIdentifier("FalloutCascadia.esm|F35EF"));
	CASActorValues.Guns				= reinterpret_cast<ActorValueInfo*>(GetFormFromIdentifier("FalloutCascadia.esm|F35F0"));
	CASActorValues.Lockpick			= reinterpret_cast<ActorValueInfo*>(GetFormFromIdentifier("FalloutCascadia.esm|F35F1"));
	CASActorValues.Medicine			= reinterpret_cast<ActorValueInfo*>(GetFormFromIdentifier("FalloutCascadia.esm|F35F2"));
	CASActorValues.MeleeWeapons		= reinterpret_cast<ActorValueInfo*>(GetFormFromIdentifier("FalloutCascadia.esm|F35F3"));
	CASActorValues.Repair			= reinterpret_cast<ActorValueInfo*>(GetFormFromIdentifier("FalloutCascadia.esm|F35F4"));
	CASActorValues.Science			= reinterpret_cast<ActorValueInfo*>(GetFormFromIdentifier("FalloutCascadia.esm|F35F5"));
	CASActorValues.Sneak			= reinterpret_cast<ActorValueInfo*>(GetFormFromIdentifier("FalloutCascadia.esm|F35F6"));
	CASActorValues.Speech			= reinterpret_cast<ActorValueInfo*>(GetFormFromIdentifier("FalloutCascadia.esm|F35F7"));
	CASActorValues.Survival			= reinterpret_cast<ActorValueInfo*>(GetFormFromIdentifier("FalloutCascadia.esm|F35F8"));
	CASActorValues.Unarmed			= reinterpret_cast<ActorValueInfo*>(GetFormFromIdentifier("FalloutCascadia.esm|F35F9"));

	//	Cascadia Globals
	//CWGlobals.TutorialWPNCND = reinterpret_cast<TESGlobal*>(GetFormFromIdentifier("CapitalWasteland.esm|D3BDE"));

	//	Cascadia Perks
	CASPerks.WeaponTypeEnergyWeaponsPerk	= reinterpret_cast<BGSPerk*>(GetFormFromIdentifier("FalloutCascadia.esm|21F9DFE"));
	CASPerks.WeaponTypeExplosivesPerk		= reinterpret_cast<BGSPerk*>(GetFormFromIdentifier("FalloutCascadia.esm|21F9DFF"));
	CASPerks.WeaponTypeMeleeWeaponsPerk		= reinterpret_cast<BGSPerk*>(GetFormFromIdentifier("FalloutCascadia.esm|21F9E00"));
	CASPerks.WeaponTypeGunsPerk				= reinterpret_cast<BGSPerk*>(GetFormFromIdentifier("FalloutCascadia.esm|21F9E01"));
	CASPerks.WeaponTypeUnarmedPerk			= reinterpret_cast<BGSPerk*>(GetFormFromIdentifier("FalloutCascadia.esm|21F9E02"));
	CASPerks.WeaponConditionHandlerPerk		= reinterpret_cast<BGSPerk*>(GetFormFromIdentifier("FalloutCascadia.esm|21F9E04"));
	
	//	CW Skills List
	Skills::CASSkillsList.emplace_back(CASActorValues.Barter);
	Skills::CASSkillsList.emplace_back(CASActorValues.EnergyWeapons);
	Skills::CASSkillsList.emplace_back(CASActorValues.Explosives);
	Skills::CASSkillsList.emplace_back(CASActorValues.Guns);
	Skills::CASSkillsList.emplace_back(CASActorValues.Lockpick);
	Skills::CASSkillsList.emplace_back(CASActorValues.Medicine);
	Skills::CASSkillsList.emplace_back(CASActorValues.MeleeWeapons);
	Skills::CASSkillsList.emplace_back(CASActorValues.Repair);
	Skills::CASSkillsList.emplace_back(CASActorValues.Science);
	Skills::CASSkillsList.emplace_back(CASActorValues.Sneak);
	Skills::CASSkillsList.emplace_back(CASActorValues.Speech);
	Skills::CASSkillsList.emplace_back(CASActorValues.Survival);
	Skills::CASSkillsList.emplace_back(CASActorValues.Unarmed);

	//	CW NPC Perks List
	Skills::CASNPCPerksList.emplace_back(CASPerks.WeaponConditionHandlerPerk);

	_MESSAGE("Skills: Finished Defining Skill Forms.");

	return true;
}

//=========================================================================================================================

// VM Functions
//=========================================================================================================================
bool RegisterSkillFuncs(VirtualMachine* vm)
{
	vm->RegisterFunction(new NativeFunction1<StaticFunctionTag, ActorValueInfo*, BSFixedString>("GetSkillAV", "FOC:Cascadia", Skills_Papyrus::GetSkillByName_Papyrus, vm));
	vm->RegisterFunction(new NativeFunction2<StaticFunctionTag, UInt32, Actor*, BSFixedString>("GetSkill", "FOC:Cascadia", Skills_Papyrus::GetSkillValueByName_Papyrus, vm));
	vm->RegisterFunction(new NativeFunction2<StaticFunctionTag, UInt32, Actor*, BSFixedString>("GetBaseSkill", "FOC:Cascadia", Skills_Papyrus::GetBaseSkillValueByName_Papyrus, vm));
	vm->RegisterFunction(new NativeFunction3<StaticFunctionTag, void, TESForm*, ActorValueInfo*, float>("ModPermanentSkillValue", "FOC:Cascadia", Skills_Papyrus::ModPermanentSkillValue_Papyrus, vm));
	return true;
}