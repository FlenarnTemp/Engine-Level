#pragma once

#include "main.h"

#include "f4se/bhkWorld.h"
#include "f4se/GameObjects.h"

//Definitions
#define REGISTER_EVENT(_event, _sink) GetEventDispatcher<_event>()->AddEventSink(&_sink);

#define DECLARE_EVENT_CLASS(Event)\
class Event##Handler : public BSTEventSink<Event> {\
public:\
    virtual ~Event##Handler() { };\
    virtual	EventResult	ReceiveEvent(Event* evn, void* dispatcher) override;\
};\
extern Event##Handler g_##Event##Handler

#define DECLARE_EVENT_DISPATCHER_RVA(Event, address) \
template<> inline BSTEventDispatcher<Event> * GetEventDispatcher() \
{ \
	typedef BSTEventDispatcher<Event> * (*_GetEventDispatcher)(); \
	RelocAddr<_GetEventDispatcher> GetDispatcher(address.GetUIntPtr()-RelocationManager::s_baseAddr); \
	return GetDispatcher(); \
}

struct ActorEquipManagerEvent {
    struct Event {
        //
    };
};

struct ActorValueEvents {
    struct ActorValueChangedEvent {
        //
    };
};

struct PerkValueEvents {
    struct PerkEntryUpdatedEvent {
        //
    };

    struct PerkValueChangedEvent {
        //
    };
};

struct HolotapeStateChanged {
    struct Event {
        //
    };
};

struct BGSInventoryItemEvent {
    struct Event {
        UInt32                      ownerRefHandle;
        UInt32                      itemHandleID;
    };
};

struct FavoriteMgr_Events {
    struct ComponentFavoriteEvent {
        BGSComponent* component;
        UInt8                       taggedForSearch;
    };
};

struct PlayerDifficultySettingChanged {
    struct Event {
        UInt32                      From;
        UInt32                      To;
    };
};

struct Workshop {
    struct WorkshopModeEvent {
        TESObjectREFR* WorkshopRef;
        bool                        start;
    };

    struct PowerOnEvent {
        TESObjectREFR* ref;
    };

    struct PowerOffEvent {
        TESObjectREFR* ref;
    };

    struct ItemGrabbedEvent {
        TESObjectREFR* workshopRef;
        TESObjectREFR* objectRef;
    };

    struct ItemRepairedEvent {
        TESObjectREFR* workshopRef;
        TESObjectREFR* objectRef;
    };

    struct ItemPlacedEvent {
        TESObjectREFR* workshopRef;
        TESObjectREFR* objectRef;
        NiTransform                 transform;
    };

    struct ItemMovedEvent {
        TESObjectREFR* workshopRef;
        TESObjectREFR* objectRef;
        UInt32                      unk10[(0x50 - 0x10) / 4];
        NiPoint3                    position;
    };

    struct ItemDestroyedEvent {
        TESObjectREFR* workshopRef;
        TESObjectREFR* objectRef;
    };

    struct BuildableAreaEvent {
        UInt8                       leaveArea;
    };

    struct ItemScrappedEvent {
        void* unk00;

        struct Component {
            TESObjectMISC* component;
            UInt32                  count;
            UInt32                  pad0C;
        };
        tArray<Component>* components;
    };

    struct PlacementStatusEvent {
        UInt32                      flags;
        float                       unk04;
        bhkWorldM* _bhkWorldM;
        float                       unk10[8];
        TESObjectREFR* objectRef;
        UInt64                      unk40;
        TESObjectREFR* workshopRef;
        float                       unk50[10];
        NiTransform                 transform;
    };
};

struct TravelMarkerStateChange {
    struct Event {
        //
    };
};

struct PlayerUpdateEvent {
    //
};

struct BGSActorCellEvent {
    //
};

struct TESQuestEvent {
    struct Event {
        //
    };
};

struct PlayerCharacterQuestEvent {
    struct Event {
        //
    };
};

struct CustomMarkerUpdate {
    struct Event {
        //
    };
};

struct LocationMarkerArrayUpdate {
    struct Event {
        //
    };
};

struct LocalMapCameraUpdate {
    struct Event {
        //
    };
};

struct TESLocationClearedEvent {
    //
};

struct RadioManager {
    struct PipboyFrequencyDetectionEvent {
        //
    };

    struct PipboyRadioTuningEvent {
        //
    };
};

struct PerkPointIncreaseEvent {
    //
};

struct HourPassed {
    struct Event {
        //
    };
};

struct SPECIALMenuEvent {
    struct NameChangedEvent {
        //
    };
};

struct PlayerActiveEffectChanged {
    struct Event {
        //
    };
};

struct PlayerLifeStateChanged {
    struct Event {
        //
    };
};

struct PlayerInDialogueChanged {
    struct Event {
        //
    };
};

struct LoadingStatusChanged {
    struct Event {
        //
    };
};

struct VATSEvents {
    struct ModeChange {
        //
    };
};

class InventoryInterface {
public:
    struct CountChangedEvent {
        //
    };

    struct FavoriteChangedEvent {
        //
    };

    void* unk00;
    BSTEventDispatcher<CountChangedEvent>       countChangedEventDispatcher;
    BSTEventDispatcher<FavoriteChangedEvent>    favoriteChangedEventDispatcher;

    struct Entry {
    public:
        UInt32                                  handleID;
        UInt32                                  ownerHandle;
        UInt16                                  itemPosition;
        UInt16                                  unk0A;
    };
    tArray<Entry>                               inventoryItems;
};

struct InvInterfaceStateChangeEvent
{
    //
};

struct PipboyLevelIncrease {
    struct Event {
        UInt32                      gainedLevel;
        // UInt32                      pad04;
        // Actor*                      actor;
        // UInt32                      unk10;
        // UInt32                      unk14;
        // float                       gainedExp;
        // UInt32                      unk1C[3];
        // Actor*                      actor1;
        // void*                       unk30;
        // Actor*                      actor2;
        // UInt32                      fromLevel;
        // UInt32                      pad44;
    };
};

struct LevelIncrease
{
    struct Event
    {
        UInt32				gainedLevel;			// 00
        UInt32				pad04;					// 04
        Actor* actor;					// 08
        UInt32				unk10;					// 10 always 1 ?
        UInt32				unk14;					// 14
        float				gainedExp;				// 18
        UInt32				unk1C[3];				// 1C
        Actor* actor1;					// 28
        void* unk30;					// 30
        Actor* actor2;					// 38
        UInt32				fromLevel;				// 40
        UInt32				pad44;					// 44
    };
};

class LevelIncreaseEventHandler : public BSTEventSink<LevelIncrease::Event>
{
public:
    virtual	EventResult	ReceiveEvent(LevelIncrease::Event* evn, void* dispatcher) override;
};

extern LevelIncreaseEventHandler g_LevelIncreaseEventHandler;

/*
struct TESEquipEvent
{
    NiPointer<TESObjectREFR>    hActor;
    UInt32                      uiBaseObjectFormID;
    UInt32                      uiOriginalRefrFormID;
    UInt16                      usUniqueID;
    bool                        bEquipped;
};
*/

struct TESEquipEvent
{
    TESObjectREFR* actor;
    UInt32            equippedFormID;
    UInt8			  pad1[9];
    bool		      bEquipped;
    UInt8             pad2[111];

    BGSInventoryItem::Stack* inventoryItem;
    UInt8			            pad3[15];
    TESObject* equippedItem;
    TESObjectWEAP::InstanceData* equippedInstance;
};
STATIC_ASSERT(offsetof(TESEquipEvent, equippedInstance) == 0xA8);
STATIC_ASSERT(offsetof(TESEquipEvent, inventoryItem) == 0x88);

struct TESCellFullyLoadedEvent
{
    TESObjectCELL* pCell;
};

struct TESCellAttachDetachEvent
{
    NiPointer<TESObjectREFR>    pRef;
    bool                        bAttached;
};

struct PlayerWeaponReloadEvent
{
    bool       bReloaded;
};

#include "f4se/GameFormComponents.h"

//BGSBodyPartDefs::LIMB_ENUM
enum LIMB_ENUM
{
    LIMB_NONE = 0xFFFFFFFF,
    LIMB_BEGIN = 0x0,
    LIMB_TORSO = 0x0,
    LIMB_HEAD_1 = 0x1,
    LIMB_EYE_1 = 0x2,
    LIMB_LOOKAT_1 = 0x3,
    LIMB_FLY_GRAB = 0x4,
    LIMB_HEAD_2 = 0x5,
    LIMB_LEFT_ARM_1 = 0x6,
    LIMB_LEFT_ARM_2 = 0x7,
    LIMB_RIGHT_ARM_1 = 0x8,
    LIMB_RIGHT_ARM_2 = 0x9,
    LIMB_LEFT_LEG_1 = 0xA,
    LIMB_LEFT_LEG_2 = 0xB,
    LIMB_LEFT_LEG_3 = 0xC,
    LIMB_RIGHT_LEG_1 = 0xD,
    LIMB_RIGHT_LEG_2 = 0xE,
    LIMB_RIGHT_LEG_3 = 0xF,
    LIMB_BRAIN = 0x10,
    LIMB_WEAPON = 0x11,
    LIMB_ROOT = 0x12,
    LIMB_COM = 0x13,
    LIMB_PELVIS = 0x14,
    LIMB_CAMERA = 0x15,
    LIMB_OFFSET_ROOT = 0x16,
    LIMB_LEFT_FOOT = 0x17,
    LIMB_RIGHT_FOOT = 0x18,
    LIMB_FACE_TARGET_SOURCE = 0x19,
    LIMB_COUNT = 0x1A
};

//  110
struct TESHitEvent2
{
    //  E0
    struct HitData
    {
        //  40
        struct DamageImpactData
        {
            NiPoint3A                       kLocation;              //  00
            NiPoint3A                       kNormal;                //  10
            NiPoint3A                       kVelocity;              //  20
            NiPointer<bhkNPCollisionObject> spColObj;               //  30
            UInt8                           pad38[(0x40 - 0x38)];   //  38
        };

        DamageImpactData                    impactData;             //  00
        Actor* hAggressor;           //  40
        Actor* hTarget;              //  44
        TESObjectREFR* hSourceRef;           //  48
        UInt8                               pad4C[(0x50 - 0x4C)];   //  4C
        NiPointer<BGSAttackDataForm>        spAttackData;           //  50
        UInt8                               weapon[(0x68 - 0x58)];  //  58 - BGSObjectInstanceT<TESObjectWEAP> doesnt work? padding for now
        SpellItem* pCriticalEffect;      //  68
        SpellItem* pHitEffect;           //  70

        //  130
        struct VATSCommand : BSIntrusiveRefCounted
        {
            //  ActionPoints::Action
            enum APAction
            {
                ACTION_ATTACK_UNARMED = 0x0,
                ACTION_ATTACK_ONE_HAND_MELEE = 0x1,
                ACTION_ATTACK_TWO_HAND_MELEE = 0x2,
                ACTION_ATTACK_MAGIC = 0x3,
                ACTION_ATTACK_RANGED = 0x4,
                ACTION_RELOAD = 0x5,
                ACTION_SWITCH_WEAPON = 0x6,
                ACTION_TOGGLE_WEAPON_DRAWN = 0x7,
                ACTION_HEAL = 0x8,
                ACTION_PLAYER_VATS_DEATH = 0x9,
                ACTION_PLAYER_DIALOGUE = 0xA,
                ACTION_SIGHTED_ENTER = 0xB,
                ACTION_COUNT = 0xC
            };

            APAction                eAction;                        //  04
            TESObjectREFR* hTarget;                      //  08
            LIMB_ENUM               eLimb;                          //  0C
            NiPointer<NiAVObject>   apAimAtObj;                     //  10
            UInt8                   pad18[(0x20 - 0x18)];           //  18
            UInt8                   vatsHitData[(0x100 - 0x20)];    //  20
            SpellItem* pMeleeImpactEffect;           //  100
            float                   fActionPointCost;               //  108
            float                   fMinActionTime;                 //  10C
            float                   fActionExecuteDelay;            //  110
            float                   fFakeShotFrequency;             //  114
            float                   fDamageMult;                    //  118
            UInt32                  uiLoadedAmmoCount;              //  11C
            char                    ucFireShots;                    //  120
            __int8                  bStranger : 1;                  //  ??
            __int8                  bParalyzingPalm : 1;            //  ??
            __int8                  bLeftHandCast : 1;              //  ??
            __int8                  bExecuteAction : 1;             //  ??
            __int8                  bActionExecuteSuccess : 1;      //  ??
            __int8                  bNextShotCausesCritical : 1;    //  ??
            __int8                  bSpendCriticalCharge : 1;       //  ??
            __int8                  bAttackChanceHit : 1;           //  ??
            __int8                  bShotFired : 1;                 //  ??
            __int8                  bCriticalAttack : 1;            //  ??
            __int8                  bSyncedAnim : 1;                //  ??
            __int8                  bAttemptChain : 1;              //  ??
            __int8                  bAllowWarp : 1;                 //  ??
            __int8                  bMeleeSneakAttack : 1;          //  ??
        };

        VATSCommand* spVATSCommand;            //  78
        const TESAmmo* pAmmo;                    //  80
        tArray<TBO_InstanceData::DamageTypes>* pDamageTypes;             //  88
        float                                   fHealthDamage;              //  90
        float                                   fTotalDamage;               //  94
        float                                   fPhysicalDamage;            //  98
        float                                   fTargetedLimbDamage;        //  9C
        float                                   fPercentBlocked;            //  A0
        float                                   fResistedPhysicalDamage;    //  A4
        float                                   fResistedTypedDamage;       //  A8

        enum STAGGER_MAGNITUDE
        {
            STAGGER_NONE = 0x0,
            STAGGER_SMALL = 0x1,
            STAGGER_MEDIUM = 0x2,
            STAGGER_LARGE = 0x3,
            STAGGER_EXTRA_LARGE = 0x4,
            STAGGER_MAGNITUDE_COUNT = 0x5,
            STAGGER_MAGNITUDE_MIN = 0x0,
            STAGGER_MAGNITUDE_MAX = 0x4
        };

        STAGGER_MAGNITUDE       eStagger;                   //  AC
        float                   fSneakAttackBonus;          //  B0
        float                   fBonusHealthDamageMult;     //  B4
        float                   fPushBack;                  //  B8
        float                   fReflectedDamage;           //  BC
        float                   fCriticalDamageMult;        //  C0
        UInt32                  uiFlags;                    //  C4
        BGSEquipSlot            equipIndex;                 //  C8
        UInt32                  uiMaterial;                 //  CC
        LIMB_ENUM               eDamageLimb;                //  D0
        UInt8                   padD4[(0xE0 - 0xD4)];       //  D4
    };

    HitData                     hitData;                    //  00
    NiPointer<TESObjectREFR>    spTarget;                   //  E0
    NiPointer<TESObjectREFR>    spCause;                    //  E8
    BSFixedString               material;                   //  F0
    UInt32                      uiSourceFormID;             //  F8
    UInt32                      uiProjectileFormID;         //  FC
    bool                        bUsesHitData;               //  100
    UInt8                       pad101[(0x110 - 0x101)];    //  101
};
//STATIC_ASSERT(offsetof(TESHitEvent2, hitData) == 0x00);
//STATIC_ASSERT(offsetof(TESHitEvent2::HitData, impactData) == 0x00);
STATIC_ASSERT(sizeof(TESHitEvent2::HitData::DamageImpactData) == 0x40);
STATIC_ASSERT(sizeof(TESHitEvent2::HitData::VATSCommand) == 0x130);
//STATIC_ASSERT(sizeof(TESHitEvent2::HitData) == 0xE0);
//STATIC_ASSERT(sizeof(TESHitEvent2) == 0x110);

namespace Events
{
    void RegisterForEvents();
    void InitAddresses();
}


DECLARE_EVENT_CLASS(TESInitScriptEvent);
DECLARE_EVENT_CLASS(TESEquipEvent);
DECLARE_EVENT_CLASS(TESObjectLoadedEvent);

DECLARE_EVENT_CLASS(TESCellFullyLoadedEvent);
DECLARE_EVENT_CLASS(TESCellAttachDetachEvent);
DECLARE_EVENT_CLASS(MenuOpenCloseEvent);
DECLARE_EVENT_CLASS(TESHitEvent2);

extern RVA <BSTEventDispatcher<LevelIncrease::Event>*> LevelIncreaseEvent_Address;
extern RVA <uintptr_t> TESCellFullyLoadedEvent_Address;
extern RVA <uintptr_t> TESCellAttachDetachEvent_Address;
extern RVA <uintptr_t> TESEquipEvent_Address;
extern RVA <uintptr_t> TESHitEvent_Address;
extern RVA <uintptr_t> TESContainerChangedEvent_Address;

DECLARE_EVENT_DISPATCHER_RVA(LevelIncrease::Event, LevelIncreaseEvent_Address);
DECLARE_EVENT_DISPATCHER_RVA(TESCellFullyLoadedEvent, TESCellFullyLoadedEvent_Address);
DECLARE_EVENT_DISPATCHER_RVA(TESCellAttachDetachEvent, TESCellAttachDetachEvent_Address);
DECLARE_EVENT_DISPATCHER_RVA(TESEquipEvent, TESEquipEvent_Address);
DECLARE_EVENT_DISPATCHER_RVA(TESHitEvent2, TESHitEvent_Address);