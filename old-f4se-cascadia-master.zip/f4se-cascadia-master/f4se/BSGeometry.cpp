#include "f4se/BSGeometry.h"

RelocAddr <_ConvertHalfToFloat> ConvertHalfToFloat(0x006945C0);
