#pragma once
#pragma warning(disable : 4834)
#include <iostream>
#include <chrono>
#include <thread>
#include <future>

#include "main.h"
#include "EventDefinitions.h"
#include "Skills.h"
#include "Scaleform.h"
#include "f4se/PapyrusInput.h"
#include "f4se/InputMap.h"
#include "f4se/GameReferences.h"
#include "f4se/PapyrusStruct.h"
#include "f4se/GameMenus.h"

//	The following was used from Neanka's PRKF
//	Source: https://github.com/Neanka/f4se/tree/master/f4se/PRKF
struct perkData {
	bool			isEligible;
	bool			isAllowable; // for GetIsSex checks
	bool			isHighLevel;
	int				filterFlag;
	int				reqlevel;
	std::string		reqs;
	std::string		description;
	std::string		SWFPath;
	bool			isTagged;
};

struct AvailablePerk {
	BGSPerk*		Perk;
	int				Level;
	int				NumRanks;
	BSFixedString	ranksInfo;
};

enum CASSkillArray {
	Barter = 0,
	EnergyWeapons,
	Explosives,
	Guns,
	Lockpick,
	Medicine,
	MeleeWeapons,
	Repair,
	Science,
	Sneak,
	Speech,
	Survival,
	Unarmed
};

enum LevelTypes {
	kType_LevelUp = 0,		//	Normal Level Up
	kType_TagSkills,		//	Tag Skills Mode
	kType_SpecialRespec,	//	Special Respec Mode
	kType_IntenseTraining	//	Intense Training Perk
};

enum filterFlags {
	filterFlag_elig = 1,
	filterFlag_notelig = 2,
	filterFlag_highlvl = 4,
	filterFlag_S = 8,
	filterFlag_P = 16,
	filterFlag_E = 32,
	filterFlag_C = 64,
	filterFlag_I = 128,
	filterFlag_A = 256,
	filterFlag_L = 512,
	filterFlag_NonSpecial = 1024,
	filterFlag_Other = 2048
};

enum PerkTypes {
	Type_Default = 0,
	Type_STRTrain,
	Type_PERTrain,
	Type_ENDTrain,
	Type_CHATrain,
	Type_INTTrain,
	Type_AGITrain,
	Type_LCKTrain,
	Type_IntenseTraining,
	Type_Cancel
};

// sub_140571710 
struct PerkAdded {
	struct Event {

	};
};

/*
class LevelUpMenu : public GameMenuBase
{
public:
	BSTEventSink<PerkAdded::Event>			eventSink;							// E0
	UInt64									unkE8[(0x180 - 0xE8) / 8];			// E8
	SInt32									unk180;								// 180
};
STATIC_ASSERT(sizeof(LevelUpMenu) == 0x188);
*/

typedef void(*_SetPerkPoints_int)(PlayerCharacter* pc, UInt8 count);
extern RVA <_SetPerkPoints_int> SetPerkPoints;

//	End of code used from Neanka's PRKF

namespace LevelUpMenu {
	void InitialiseValues();
	void HandleLevelUpMenuOpen(GFxMovieRoot* myMovieRoot);
	void ModSkillByName(std::string skillName, int value, int baseValue);
	void RevertSkill(ActorValueInfo* mySkill);
	void ModPerkPoints(SInt8 count);
	void SetSkillTagged(ActorValueInfo* mySkill, bool bTag);
	void CompleteLevelUp();
	void HandleVanillaMenuOpen();

	void OnTagSkillsStart(GFxMovieRoot* myMovieRoot);

	void GetINIOptions();
	bool GetForcedLevelUp();
	void GetLevelUpFormsFromGame();
	void UpdateLevelUpFormsFromGame();
	void CheckForLevelUp();
	void WaitForLevelUpReady();
	void HandleLevelUp(LevelIncrease::Event* myEvent);
	void GetLevelUpMenuData();

	void RegisterForInput(bool bRegister);

	bool ProcessSkillsList(GFxMovieRoot* myMovieRoot);
	bool ProcessTagSkillsList(GFxMovieRoot* myMovieRoot, int tagSkills, bool bRetag);
	bool ProcessSpecialList(GFxMovieRoot* myMovieRoot);
	bool ProcessPerkList(GFxMovieRoot* myMovieRoot);

	void ProcessUserEvent(const char* controlName, bool isDown, int deviceType, UInt32 keyCode);
	void RegisterForInput(bool bRegister);

	perkData GetPerkRequirements(BGSPerk* myPerk);

	bool RegisterFunctions(VirtualMachine* vm);
	void InitAddresses();

}

namespace LevelUpMenu_Papyrus {
	void OpenLevelUpMenu_Papyrus(StaticFunctionTag*);
	void OpenTagSkillsMenu_Papyrus(StaticFunctionTag*, UInt32 tagPoints, bool reTag);
	void OpenSpecialRespecMenu_Papyrus(StaticFunctionTag*);
	void OpenIntenseTrainingMenu_Papyrus(StaticFunctionTag*);

	bool GetSkillTagged_Papyrus(StaticFunctionTag*, ActorValueInfo* mySkill);
	void SetSkillTagged_Papyrus(StaticFunctionTag*, ActorValueInfo* mySkill, bool bTag);
}