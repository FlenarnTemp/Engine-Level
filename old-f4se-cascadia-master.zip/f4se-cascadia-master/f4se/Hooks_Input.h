#pragma once

void Hooks_Input_Init();
void Hooks_Input_Commit();
