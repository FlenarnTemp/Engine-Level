#pragma once

struct StaticFunctionTag;
class VirtualMachine;

namespace papyrusUtility
{
	void RegisterFuncs(VirtualMachine* vm);
}
