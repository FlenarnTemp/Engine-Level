#pragma once

void Hooks_SaveLoad_Init();
void Hooks_SaveLoad_Commit();
