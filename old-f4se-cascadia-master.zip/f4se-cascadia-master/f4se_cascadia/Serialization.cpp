#include <fstream>

#include "Serialization.h"
#include "f4se/PluginAPI.h"

namespace CASSerialization
{

	/*	Level Up Menu Stuff
	=========================================================================================================================*/
	SInt32 playerSkillPoints = 0;
	std::set<UInt32> taggedSkills;
	bool playerReadyToLevelUp = false;

	//	Returns Player's Skill Points
	SInt32 GetSkillPoints()
	{
		return playerSkillPoints;
	}

	//	Sets Player's Skill Points
	void SetSkillPoints(SInt32 setValue)
	{
		playerSkillPoints = setValue;
	}

	//	Modifies Player's Skill Points
	void ModSkillPoints(SInt32 modValue)
	{
		playerSkillPoints += modValue;
	}

	//	Sets Skill as Tagged
	void SetSkillTagged(UInt32 skillFormID)
	{
		taggedSkills.insert(skillFormID);
	}

	//	Sets Skill as Not Tagged
	void RemoveSkillTagged(UInt32 skillFormID)
	{
		taggedSkills.erase(skillFormID);
	}

	//	Returns True if Skill is Tagged
	bool IsSkillTagged(UInt32 skillFormID)
	{
		return taggedSkills.find(skillFormID) != taggedSkills.end();
	}

	//	Returns the number of Skills tagged
	UInt32 GetSkillsTagged()
	{
		return taggedSkills.size();
	}

	//	Returns true if Player is ready to Level Up
	bool IsReadyToLevelUp()
	{
		return playerReadyToLevelUp;
	}

	//	Sets if Player is ready to Level Up
	void SetReadyToLevelUp(bool bReady)
	{
		playerReadyToLevelUp = bReady;
	}

	//=========================================================================================================================

	/*	Save/Load F4SE Data Stuff
	=========================================================================================================================*/

	//	Traces to Log, prefixing with "Serialization"
	void TraceSerialLog(std::string myTrace)
	{
		std::string mySerialTrace = "Serialization: ";
		mySerialTrace.append(myTrace);
		TraceLog(mySerialTrace);
	}

	void RevertCallback(const F4SESerializationInterface* f4seSerial)
	{
		//Clear Callback Stored Data here
		TraceSerialLog("Clearing Serialization Data");
		SetSkillPoints(0);
		SetReadyToLevelUp(false);
		taggedSkills.clear();
	}

	void LoadCallback(const F4SESerializationInterface* f4seSerial)
	{
		TraceSerialLog("Loading Serialization Data");
		UInt32 iType, iVersion, iLength;
		while (f4seSerial->GetNextRecordInfo(&iType, &iVersion, &iLength))
		{
			switch (iType)
			{
			case 'CAS':
				Load(f4seSerial, InternalEventVersion::kCurrentVersion);
				break;
			}
		}
	}

	bool Load(const F4SESerializationInterface* f4seSerial, UInt32 iVersion)
	{
		if (!Serialization::ReadData(f4seSerial, &playerSkillPoints))
		{
			TraceSerialLog("Unable to load Player Skill Points");
			return false;
		}
		TraceSerialLog("Loaded Player Skill Points");
		
		UInt32 taggedSkillsCount = 0;
		if (!Serialization::ReadData(f4seSerial, &taggedSkillsCount))
		{
			TraceSerialLog("Unable to load Tagged Skills Count");
			return false;
		}
		TraceSerialLog("Loaded Tagged Skills Count");

		for (UInt32 i = 0; i < taggedSkillsCount; i++)
		{
			UInt32 oldFormID = 0;
			UInt32 newFormID = 0;

			if (!Serialization::ReadData(f4seSerial, &oldFormID))
			{
				TraceSerialLog("Unable to load Tagged Skill FormID");
				return false;
			}

			if (!f4seSerial->ResolveFormId(oldFormID, &newFormID))
				continue;

			taggedSkills.insert(newFormID);
		}
		TraceSerialLog("Loaded Tagged Skills");

		if (!Serialization::ReadData(f4seSerial, &playerReadyToLevelUp))
		{
			TraceSerialLog("Unable to load Player Ready to Level Up");
			return false;
		}
		TraceSerialLog("Loaded Player Ready to Level Up");


		return true;
	}

	void SaveCallback(const F4SESerializationInterface* f4seSerial)
	{
		TraceSerialLog("Saving Serialization Data");
		Save(f4seSerial, 'CAS', InternalEventVersion::kCurrentVersion);
	}

	bool Save(const F4SESerializationInterface* f4seSerial, UInt32 iType, UInt32 iVersion)
	{
		f4seSerial->OpenRecord(iType, iVersion);

		if (!f4seSerial->WriteRecordData(&playerSkillPoints, sizeof(playerSkillPoints)))
		{
			return false;
		}
		TraceSerialLog("Saving Player Skill Points");

		UInt32 taggedSkillsCount = taggedSkills.size();
		if (!f4seSerial->WriteRecordData(&taggedSkillsCount, sizeof(taggedSkillsCount)))
		{
			return false;
		}
		TraceSerialLog("Saving Tagged Skills Count");

		for (auto& form : taggedSkills)
		{
			UInt32 formID = form;
			if (!f4seSerial->WriteRecordData(&formID, sizeof(formID)))
			{
				return false;
			}
		}
		TraceSerialLog("Saving Tagged Skills");

		if (!f4seSerial->WriteRecordData(&playerReadyToLevelUp, sizeof(playerReadyToLevelUp)))
		{
			return false;
		}
		TraceSerialLog("Saving Player Ready to level up");

		return true;
	}

	//=========================================================================================================================

}