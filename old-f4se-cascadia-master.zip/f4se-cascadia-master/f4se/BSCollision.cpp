#include "f4se/BSCollision.h"
